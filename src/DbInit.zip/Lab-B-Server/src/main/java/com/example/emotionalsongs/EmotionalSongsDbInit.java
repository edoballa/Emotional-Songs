package com.example.emotionalsongs;

import com.example.emotionalsongs.dbinit.controller.DbInitPage_Controller;
import com.example.emotionalsongs.dbinit.object.DbConnection;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * <p>This class is the main class and it contains the methods that are used to start the application, one of these is the main.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */
public class EmotionalSongsDbInit extends Application {
    /**
     * <code>dbInitScene</code>
     * A Scene object that define the dbInitScene.
     */
    private Scene dbInitScene;

    /**
     * <code>dbInitPageController</code>
     * A DbInitPage_Controller object that defines the associated controller.
     */
    private DbInitPage_Controller dbInitPageController;

    /**
     * This method start the scene.
     * @param stage A Scene object that define which scene to show.
     */
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader dbInitLoader = new FXMLLoader(EmotionalSongsDbInit.class.getResource("DbInitPage.fxml"));
        Parent serverAccessRoot = dbInitLoader.load();
        dbInitPageController = dbInitLoader.getController();
        dbInitPageController.setApplication(this);
        //prefHeight="657.0" prefWidth="877.0"
        dbInitScene = new Scene(serverAccessRoot, 877, 657);

        stage.setTitle(" DATABASE ");
        stage.setScene(dbInitScene);
        stage.show();
        stage.setResizable(false);
    }

    /**
     * This method start the application.
     */
    public static void main(String[] args) {
        DbConnection.restoreDefaultConnectionInfo();
        DbConnection.createDatabase();
        launch();
    }
}