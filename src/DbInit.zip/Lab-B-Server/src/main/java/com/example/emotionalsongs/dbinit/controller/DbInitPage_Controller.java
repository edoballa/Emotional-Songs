package com.example.emotionalsongs.dbinit.controller;

import com.example.emotionalsongs.EmotionalSongsDbInit;
import com.example.emotionalsongs.dbinit.service.DbInitializer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * <p>This class define the methods to interact with the database</p>*
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class DbInitPage_Controller {
    /**
     * <code>dbUsernameField</code>
     * A TextField that will contains the username used in database login.
     */
    @FXML private TextField dbUsernameField;
    /**
     * <code>dbNameField</code>
     * A TextField that will contains the database name used in database login.
     */
    @FXML private TextField dbNameField;
    /**
     * <code>dbHostField</code>
     * A TextField that will contains the host used in database login.
     */
    @FXML private TextField dbHostField;
    /**
     * <code>dbPortField</code>
     * A TextField that will contains the port used in database login.
     */
    @FXML private TextField dbPortField;
    /**
     * <code>passwordField</code>
     * A PasswordField that will contains the password used in database login.
     */
    @FXML private PasswordField dbPasswordField;
    /**
     * <code>operationInfoField</code>
     * A Label that will contains the info about the database login.
     */
    @FXML private Label operationInfoField;
    /**
     * <code>commandCopy</code>
     * A TextArea that will contains the command to fill the song table.
     */
    @FXML private TextArea commandCopy;
    /**
     * <code>application</code>
     * A EmotionalSongsDbInit that rappresent the application's main class.
     */
    @FXML private EmotionalSongsDbInit application;
    /**
     * <code>dbInitializer</code>
     * A DbInitializer that permit to execute operations on database.
     */
    private DbInitializer dbInitializer;

    /**
     * application setter method.
     * @param application the application to set
     */
    public void setApplication(EmotionalSongsDbInit application) {
        this.application = application;
    }

    /**
     * A method that store the database connection information.
     * @param event rappresent the event happened in graphics page
     */
     @FXML
    protected void initButton(ActionEvent event) {
        if(this.dbInitializer == null) {
            this.dbInitializer = DbInitializer.getInstance();
        }

        String operationInfo = "";
        String dbHost = dbHostField.getText();
        String dbPort = dbPortField.getText();
        String dbUsername = dbUsernameField.getText();
        String dbPassword = dbPasswordField.getText();

        if(dbHost == null || dbHost.isEmpty() || dbPort == null || dbPort.isEmpty()
                || dbUsername == null || dbUsername.isEmpty()
                || dbPassword == null || dbPassword.isEmpty()) {
            operationInfo = "One or more fields are not filled in!";
            operationInfoField.setText(operationInfo);
            return;
        }

        operationInfo = dbInitializer.setConnectionInfo(dbPort, dbHost, dbUsername, dbPassword);
        operationInfoField.setText(operationInfo);
         setUserInfoFieldVisibilty(true);
    }

    /**
     * A method that test the connection with database.
     * @param event rappresent the event happened in graphics page
     */
    @FXML
    protected void testConnectionButton(ActionEvent event) {
        System.out.println(System.getProperty("user.dir"));
        if(this.dbInitializer == null) {
            this.dbInitializer = DbInitializer.getInstance();
        }

        String operationInfo = "";
        operationInfo = this.dbInitializer.testConnection();
        operationInfoField.setText(operationInfo);
        setUserInfoFieldVisibilty(true);
    }

    /**
     * A method that create the database structure.
     * @param event rappresent the event happened in graphics page
     */
    @FXML
    protected void createDbStructureButton(ActionEvent event) {
        if(this.dbInitializer == null) {
            this.dbInitializer = DbInitializer.getInstance();
        }

        String operationInfo = "";
        operationInfo = dbInitializer.createDbStructure();
        operationInfoField.setText(operationInfo);
        setUserInfoFieldVisibilty(true);
    }

    /**
     * A method that fills the song's database table.
     * @param event rappresent the event happened in graphics page
     */
    @FXML
    protected void fillSongTableButton(ActionEvent event) {
        if(this.dbInitializer == null) {
            this.dbInitializer = DbInitializer.getInstance();
        }

        String operationInfo = "";
        operationInfo = dbInitializer.fillSongTable();
        operationInfoField.setText(operationInfo);
        setUserInfoFieldVisibilty(true);
    }
    /**
     * A method to manually fills the song's database table.
     * @param event rappresent the event happened in graphics page
     */
    @FXML
    protected void fillSongTableManuallyButton(ActionEvent event) {
        if(this.dbInitializer == null) {
            this.dbInitializer = DbInitializer.getInstance();
        }

        String operationInfo = "";
        operationInfo = dbInitializer.fillSongTableManually();
        commandCopy.clear();
        commandCopy.setText(operationInfo);
        setUserInfoFieldVisibilty(false);
    }
    /**
     * A method to manually fill any database table.
     * @param event rappresent the event happened in graphics page
     */
    @FXML
    protected void fillOtherTableButton(ActionEvent event) {
        if(this.dbInitializer == null) {
            this.dbInitializer = DbInitializer.getInstance();
        }

        String operationInfo = "";
        operationInfo = dbInitializer.fillOtherTable();
        operationInfoField.setText(operationInfo);
        setUserInfoFieldVisibilty(true);
    }

    /**
     * A method to set visible ore not the box which contains the operation feedback for the user.
     * @param visibiltyOperationInfo is a boolean and it defines the visibility level.
     */
    private void setUserInfoFieldVisibilty(boolean visibiltyOperationInfo){
        commandCopy.setVisible(!visibiltyOperationInfo);
        operationInfoField.setVisible(visibiltyOperationInfo);
    }

}
