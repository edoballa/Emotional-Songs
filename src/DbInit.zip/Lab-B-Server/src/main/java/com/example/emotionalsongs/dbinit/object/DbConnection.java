package com.example.emotionalsongs.dbinit.object;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * <p>This class define the connection with the database</p>*
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class DbConnection {
    /**
     * <code>logger</code>
     * A Logger that will contains the connection logs.
     */
    private final static Logger logger = Logger.getLogger("DbConnection");
    /**
     * <code>DB_PROPERTIES_FILE</code>
     * A String that contains the parent location path of the property file.
     */
    private final static String DB_PROPERTIES_FILE = System.getProperty("user.dir") + "\\config\\db.properties";
    /**
     * <code>DB_NAME</code>
     * A String that contains the database name.
     */
    private final static String DB_NAME = "dbes";
    /**
     * <code>dbConnection</code>
     * A DbConnection that will permit to connect the database.
     */
    private static DbConnection dbConnection = null;
    /**
     * <code>connection</code>
     * A Connection that will rappresent the connection with the database.
     */
    private Connection connection = null;
    /**
     * <code>properties</code>
     * A Properties that contains the attributes to estabilish the connection to the database.
     */
    private static Properties properties = null;
    /**
     * <code>dbPort</code>
     * A String that will contains the port used in database connection.
     */
    private String dbPort = null;
    /**
     * <code>dbHost</code>
     * A String that will contains the host used in database connection.
     */
    private String dbHost = null;
    /**
     * <code>dbUsername</code>
     * A String that will contains the username used in database connection.
     */
    private String dbUsername = null;
    /**
     * <code>dbPassword</code>
     * A String that will contains the password used in database connection.
     */
    private String dbPassword = null;

    /**
     * private DbConnection constructor
     * Read the properties from a specific file and save them in to the attribute.
     */
    private DbConnection() {
        this.dbPort = (String) properties.get("db.port");
        this.dbHost = (String) properties.get("db.host");
        this.dbUsername = (String) properties.get("db.username");
        this.dbPassword = (String) properties.get("db.password");
    }

    /**
     * <code>dbPort</code>
     * A String that will contains the dbPort used in database connection.
     */
    public static DbConnection getInstance() throws SQLException {
        if (dbConnection == null) {
            dbConnection = new DbConnection();
        }
        return dbConnection;
    }

    /**
     * A method that save the database connection info into a specific file
     * @param dbHost contains the host used in database connection.
     * @param dbPassword contains the password used in database connection.
     * @param dbPort contains the host used in database connection.
     * @param dbUsername contains the password used in database connection.
     * @return String the negative/positive response
     */
    public static String saveConnectionInfo(String dbPort, String dbHost, String dbUsername, String dbPassword){
        try {
            FileInputStream propFile = new FileInputStream(DB_PROPERTIES_FILE);
            properties = new Properties();
            properties.load(propFile);
        } catch (FileNotFoundException e) {
            logger.log(Level.SEVERE, "Something went wrong with the file ", e);
            return "Something went wrong with the file";
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Cannot read the file ", e);
            return "Cannot read the file";
        }

        //I check again that the fields are not null to make sure I am saving the data correctly
        if (dbHost != null && !dbHost.isEmpty()) {
            properties.setProperty("db.host", dbHost);
        }

        if (dbPort != null && !dbPort.isEmpty()) {
            properties.setProperty("db.port", dbPort);
        }

        properties.setProperty("db.name", DB_NAME);

        if (dbUsername != null && !dbUsername.isEmpty()) {
            properties.setProperty("db.username", dbUsername);
        }

        if (dbPassword != null && !dbPassword.isEmpty()) {
            properties.setProperty("db.password", dbPassword);
        }

        //corretto il metodo per far salvare la configurazione in config/db.properties
        try {
            properties.store(new FileOutputStream(DB_PROPERTIES_FILE), null);
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Failed to save properties to file", e);
            return "Failed to save properties to file";
        }
        return "DB connection info has been saved correctly!";

    }

    /**
     * A method that restore the default value for the connection.
     */
    public static void restoreDefaultConnectionInfo() {
        if (properties == null) {
            try {
                FileInputStream propFile = new FileInputStream(DB_PROPERTIES_FILE);
                properties = new Properties();
                properties.load(propFile);
            } catch (FileNotFoundException e) {
                logger.log(Level.SEVERE, "Something went wrong with the file ", e);
            } catch (IOException e) {
                logger.log(Level.SEVERE, "Cannot read the file ", e);
            }
        }

        properties.setProperty("db.host", "localhost");
        properties.setProperty("db.port", "5432");
        properties.setProperty("db.name", DB_NAME);
        properties.setProperty("db.username", "postgres");
        properties.setProperty("db.password", "postgres");

        //corretto il metodo per far salvare la configurazione in config/db.properties
        try {
            properties.store(new FileOutputStream(DB_PROPERTIES_FILE), null);
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Failed to save properties to file", e);
        }
    }

    /**
     * A method that return the database connection inside an object.
     * @return Connection that contains the information and methods which will be
     * used to execute operations on database.
     */
    public Connection getConnection() {
        try {
            String dbUrl = "jdbc:postgresql://" + this.dbHost + ":" + this.dbPort + "/" + DB_NAME;
            Class.forName("org.postgresql.Driver");
            this.connection = DriverManager.getConnection(dbUrl, this.dbUsername, this.dbPassword);
        } catch (ClassNotFoundException e) {
            logger.log(Level.SEVERE, "Driver not found ", e);
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Connection failed", e);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Something went wrong", e);
        }

        return connection;
    }

    /**
     * A method that try to establish the connection between application and database.
     * @return Connection that contains the information and methods which will be
     * used to execute operations on database.
     */
    public Connection testConnection() {
        if (this.connection != null) {
            try {
                this.connection.close();
            } catch (SQLException e) {
                logger.log(Level.SEVERE, "Connection failed", e);
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Something went wrong", e);
            }
            this.connection = null; //do this because the properties can be changed
        }

        return getConnection();
    }

    /**
     * A method that restore the default value for the connection.
     */
    public static void createDatabase() {
        Connection dbConn = null;
        try {
            String dbUrl = "jdbc:postgresql://" + properties.getProperty("db.host") + ":" + properties.getProperty("db.port") + "/" + "postgres";
            Class.forName("org.postgresql.Driver");
            dbConn = DriverManager.getConnection(dbUrl, properties.getProperty("db.username"), properties.getProperty("db.password"));
            Statement stm = dbConn.createStatement();
            stm.execute(" DROP DATABASE IF EXISTS dbes ");
            stm.execute(" CREATE DATABASE dbes ");
            stm.close();
            dbConn.close();
        } catch (ClassNotFoundException e) {
            logger.log(Level.SEVERE, "Driver not found ", e);
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Connection failed", e);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Something went wrong", e);
        }
    }
}
