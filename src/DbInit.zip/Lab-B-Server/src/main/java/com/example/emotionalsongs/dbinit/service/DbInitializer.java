package com.example.emotionalsongs.dbinit.service;

import com.example.emotionalsongs.dbinit.object.DbConnection;

import java.io.File;
import java.nio.file.Files;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * <p>This class initialize the database</p>*
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class DbInitializer {
    /**
     * <code>logger</code>
     * A Logger that will contains the connection logs.
     */
    private final static Logger logger = Logger.getLogger("DbInitializer");
    /**
     * <code>FILE_SQL_DB_STRUCTURE</code>
     * A String that contains the filepath of the .sql file that contains the query to build the database structure.
     */
    private static final String FILE_SQL_DB_STRUCTURE = System.getProperty("user.dir") + "\\config\\DbStructure.sql";
    /**
     * <code>FILE_SQL_USER_DATA</code>
     * A String that contains the filepath of the .sql file that contains the users data.
     */
    private static final String FILE_SQL_USER_DATA = System.getProperty("user.dir") + "\\data\\UserDataTable.sql";
    /**
     * <code>FILE_CSV_SONG_DATA</code>
     * A String that contains the filepath of the .csv file that contains the songs data.
     */
    private static final String FILE_CSV_SONG_DATA = System.getProperty("user.dir") + "\\data\\SongData.csv";
    /**
     * <code>dbInitializer</code>
     * A DbInitializer that permit to execute operations on database.
     */
    private static DbInitializer dbInitializer = null;

    /**
     * private DbInitializer constructor
     * Empty Constructor.
     */
    private DbInitializer(){

    }
    
    /**
     * This method return an instance of DbInitializer
     * @return DbInitializer
     */
    public static DbInitializer getInstance(){
        if (dbInitializer == null){
            dbInitializer = new DbInitializer();
        }

        return dbInitializer;
    }
    
    /**
     * A method that try to establish the connection between application and database.
     * @return String that rappresent the message that indicates whether the procedure was successful or not
     */
    public String testConnection(){
        try {
            logger.log(Level.INFO, "Test-Connection: start get connection");
            Connection connection = DbConnection.getInstance().testConnection();

            //if connection still null return error message
            if(connection == null) {
                logger.log(Level.SEVERE, "Test-Connection: Connection error, please retry");
                return "Test-Connection: Connection error, please retry";
            } else {
                String testQuery = "select 1 as res";
                logger.log(Level.INFO, "Test-Connection: connection request end successfully, try to launch query {}", testQuery);
                PreparedStatement pstm = connection.prepareStatement(testQuery);
                ResultSet rs = pstm.executeQuery();
                logger.log(Level.INFO, "Test-Connection: query executed successfully");

                boolean isResultOk = false;
                if(rs.next()){
                    logger.log(Level.INFO, "Test-Connection: try to get query result");
                    if(rs.getInt("res") > 0){
                        isResultOk = true;
                        logger.log(Level.INFO, "Test-Connection: result set successfully");
                    }
                }

                pstm.close();
                connection.close();

                if(isResultOk) {
                    logger.log(Level.INFO, "Test-Connection: procedure end successfully");
                    return "Test-Connection: procedure end successfully";
                } else {
                    logger.log(Level.SEVERE, "Test-Connection: procedure end not successfully");
                    return "Test-Connection: procedure end not successfully, please retry!";
                }
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Cannot execute query", e);
            return "Cannot execute query";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Something went wrong", e);
            return "Something went wrong";
        }
    }

    /**
     * A method that save the database connection info into a specific file
     * @param dbHost contains the host used in database connection.
     * @param dbPassword contains the password used in database connection.
     * @param dbPort contains the host used in database connection.
     * @param dbUsername contains the password used in database connection.
     * @return String message that rappresent negative or positive response.
     */
    public String setConnectionInfo(String dbPort, String dbHost, String dbUsername, String dbPassword){
        return DbConnection.saveConnectionInfo(dbPort, dbHost, dbUsername, dbPassword);
    }
    /**
     * A method that create the database structure using a specific file.
     * @return String message that rappresent negative or positive response.
     */
    public String createDbStructure(){
        return launchQueryUsingFile("create-db-structure", FILE_SQL_DB_STRUCTURE);
    }

    /**
     * A method that fills the song's database table.
     * @return String message that rappresent negative or positive response..
     */
    public String fillSongTable() {
        if(!checkIfTableExist("song", "emotional_songs")){
            return "KO: Song table doesn't exist, please create the database structure first!";
        }

        String copyCommandQuery = "COPY emotional_songs.song (title, author, year, album, duration) FROM '"
                + FILE_CSV_SONG_DATA + "' WITH (FORMAT csv, HEADER true, DELIMITER ';', ENCODING 'UTF-8')";

        return launchQueryUsingCopyCommand("fill-song-table", copyCommandQuery);
    }

    /**
     * A method that calculate the command psql to fill th song table from pgAdmin or another app.
     * @return String tha contains the command psql.
     */
    public String fillSongTableManually(){
        if(!checkIfTableExist("song", "emotional_songs")){
            return "KO: Song table doesn't exist, please create the database structure first!";
        }

        String manualCopyCommand = "\\copy emotional_songs.song (title, author, year, album, duration) FROM '"
                + FILE_CSV_SONG_DATA + "' WITH CSV HEADER DELIMITER ';'";

        return manualCopyCommand;
    }
    
    /**
     * A method to fill the song's database table.
     * @return String the negative/positive reponse
     */
    public String fillOtherTable(){
        String queryFunction = " CREATE OR REPLACE FUNCTION emotional_songs.random_between(low numeric, high numeric) \r\n" +
            " RETURNS INT AS \r\n" +
            " $$ \r\n" +
            " BEGIN \r\n" +
            " RETURN floor(random()* (high-low + 1) + low); \r\n" +
            " END; \r\n" +
            "  $$ language 'plpgsql' STRICT \r\n" +
            " ; ";

        try {
            Connection connection = DbConnection.getInstance().getConnection();
            PreparedStatement pstm = connection.prepareStatement(queryFunction);
            pstm.execute();
            pstm.close();
            connection.close();
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Cannot execute query", e);
            return "KO: ERROR during execute query";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Something went wrong", e);
            return "KO: ERROR something went wrong";
        }

        if(!checkIfTableExist("utenti_registrati", "emotional_songs")){
            return "KO: Song table doesn't exist, please create the database structure first!";
        }

        String checkResMessage = "";
        checkResMessage = truncateTable("utenti_registrati", "emotional_songs");
        if(checkResMessage.startsWith("KO: ERROR ")){
            return checkResMessage;
        }

        checkResMessage= launchQueryUsingFile("fill-userdata-table", FILE_SQL_USER_DATA);
        if(checkResMessage.startsWith("KO: ERROR ")){
            return checkResMessage;
        }

        if(!checkIfTableExist("emozioni", "emotional_songs")){
            return "KO: Emotion Felt table doesn't exist, please create the database structure first!";
        }

        checkResMessage = truncateTable("emozioni", "emotional_songs");
        if(checkResMessage.startsWith("KO: ERROR ")){
            return checkResMessage;
        }

        String fillEmotionFeltTableQuery = " insert into emotional_songs.emozioni (song_id, emotion_id, user_id, score, note, add_date, add_user_id) \n" +
                " select gen_song_data.song_id, gen_song_data.emotion_id, gen_user.user_id, floor(random() * 5) + 1 as score, \n" +
                "   case when gen_user.user_id::numeric % 7 = 0 then 'La canzone mi ha suscitato '||e.name \n" +
                "      when gen_song_data.song_id::numeric % 3 = 0 then 'La canzone mi ha suscitato queste emozioni '||e.description \n" +
                "      else null \n" +
                "   end as note, \n" +
                "   current_timestamp, 'auto-generate' \n" +
                " from (select generate_series(1, 400) as r_num, \n" +
                "         floor(emotional_songs.random_between(min(s.song_id), max(s.song_id))) as song_id, \n" +
                "         floor(random() * 9) + 1 as emotion_id \n" +
                "      from emotional_songs.song s) as gen_song_data \n" +
                "   join (select generate_series(1, 400) as r_num, \n" +
                "            floor(emotional_songs.random_between(min(ud.user_id), max(ud.user_id))) as user_id \n" +
                "         from emotional_songs.utenti_registrati ud )\tas gen_user on gen_song_data.r_num = gen_user.r_num \n" +
                "   left join emotional_songs.emozioni ef on gen_song_data.song_id = ef.song_id \n" +
                "      and gen_song_data.emotion_id = ef.emotion_id and gen_user.user_id = ef.user_id \n" +
                "   join emotional_songs.emotion_details e on e.emotion_id = gen_song_data.emotion_id \n" +
                " where ef.song_id is null and ef.emotion_id is null and ef.user_id is null ";

        for(int i = 0; i < 5; i++){
            try {
                Connection connection = DbConnection.getInstance().getConnection();
                PreparedStatement pstm = connection.prepareStatement(fillEmotionFeltTableQuery);
                pstm.execute();
                pstm.close();
                connection.close();
            } catch (SQLException e) {
                logger.log(Level.SEVERE, "Cannot execute query", e);
                return "KO: ERROR during execute query, please retry ";
            } catch (Exception e) {
                logger.log(Level.SEVERE, "KO: ERROR during execute query, please retry ", e);
                return "KO: ERROR something went wrong, please retry ";
            }
        }

        return "OK: procedure correctly performed, database is ready";

    }
    
    /**
     * A method that check if a table or schema exist into the database.
     * @param tableName the name of the table within the database.
     * @param schemaName the name of the schema within the database.
     * @return boolean true if table exist, false otherwise.
     */
    private boolean checkIfTableExist(String tableName, String schemaName){
        boolean tableExist = false;
        try {
            String checkQuery = " select count(*) as res from pg_catalog.pg_stat_all_tables where schemaname = ?  and relname = ? ";
            Connection connection = DbConnection.getInstance().getConnection();
            PreparedStatement pstm = connection.prepareStatement(checkQuery);
            pstm.setString(1, schemaName);
            pstm.setString(2, tableName);
            ResultSet rs = pstm.executeQuery();

            if(rs.next()){
                if(rs.getInt("res") > 0){
                    tableExist = true;
                }
            }

            pstm.close();
            connection.close();

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Cannot execute query", e);
            return tableExist;
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Something went wrong", e);
            return tableExist;
        }

        return tableExist;
    }
    
    /**
     * A method that delete a table from the database.
     * @param tableName the name of the table within the database
     * @param schemaName the name of the schema within the database
     * @return String message that rappresent negative or positive response.
     */
    private String truncateTable(String tableName, String schemaName){
        try {
            String truncateQuery = " truncate table " + schemaName + "." + tableName + " cascade ";
            Connection connection = DbConnection.getInstance().getConnection();
            PreparedStatement pstm = connection.prepareStatement(truncateQuery);
            pstm.execute();
            pstm.close();
            connection.close();
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Cannot execute query", e);
            return "KO: ERROR during execute query, please retry ";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "KO: ERROR during execute query, please retry ", e);
            return "KO: ERROR something went wrong";
        }

        return "OK: procedure correctly performed on table " + schemaName + "." + tableName;
    }
    
    /**
     * A generic method that execute all the queries which are contained into a specific file .sql.
     * @param configPhase is used during the log phase and specific in which configuration the program is.
     * @param filename is the file that contains the queries to execute.
     * @return String message that rappresent negative or positive response.
     */
    private String launchQueryUsingFile(String configPhase, String filename){
        logger.log(Level.INFO, "DB-Init: Starting {}", configPhase);
        List<String> lines = null;
        try {
            logger.log(Level.INFO, "Starting read file {}", filename);
            lines = Files.readAllLines(new File(filename).toPath());
            logger.log(Level.INFO, "End read file");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Something went wrong during reading file", e);
            return "KO: ERROR Something went wrong during reading file";
        }

        if(lines == null){
            logger.log(Level.SEVERE, "Something went wrong during reading file, maybe {} is empty", filename);
            return "KO: ERROR Something went wrong during reading file, maybe " + filename + " is empty";
        }

        List<String> queries = new ArrayList<>();
        String query = "";
        logger.log(Level.INFO, "Build every single query");
        for(String line : lines){
            query += line;
            if(line.endsWith(";")) {
                queries.add(query);
                query = "";
            }
        }
        logger.log(Level.INFO, "I found {} query to launch", queries.size());

        try {
            Connection connection = DbConnection.getInstance().getConnection();
            logger.log(Level.INFO, "Starting launch query");
            for(String q : queries){
                PreparedStatement pstm = connection.prepareStatement(q);
                pstm.execute();
                pstm.close();
            }
            connection.close();
            logger.log(Level.INFO, "End launch query");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Cannot execute query", e);
            return "KO: ERROR Cannot execute query";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Something went wrong", e);
            return "KO: ERROR Something went wrong";
        }

        logger.log(Level.INFO, "DB-Init: End {}", configPhase);
        return "OK: procedure correctly performed on file ";
    }
    
    /**
     * A generic method that execute all the queries which are contained into a specific file .sql.
     * @param configPhase is used during the log phase and specific in which configuration the program is.
     * @param copyCommandQuery is the command SQL to copy the values from a .csv file to a specific database table.
     * @return String message that rappresent negative or positive response.
     */
    private String launchQueryUsingCopyCommand(String configPhase, String copyCommandQuery){
        logger.log(Level.INFO, "DB-Init: Starting {}", configPhase);

        try {
            //icacls "C:\Users\Diana\Desktop\Univeristà\Laboratorio_B\Lab-B-Server\data\SongData.csv" /grant Everyone:(RX)
            Connection connection = DbConnection.getInstance().getConnection();
            Statement stm = connection.createStatement();

            logger.log(Level.INFO, "Starting execute query");

            stm.execute(copyCommandQuery);
            stm.close();
            connection.close();

            logger.log(Level.INFO, "Finish execute query");

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Cannot execute query", e);
            return "Cannot execute query";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Something went wrong", e);
            return "Something went wrong";
        }

        logger.log(Level.INFO, "DB-Init: End {}", configPhase);
        return "OK " + configPhase + ": table filled successfully";
    }

}
