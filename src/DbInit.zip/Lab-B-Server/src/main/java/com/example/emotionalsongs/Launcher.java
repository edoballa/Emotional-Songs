package com.example.emotionalsongs;

public class Launcher {
    public static void main(String[] args) {
        EmotionalSongsDbInit.main(args);
    }
}
