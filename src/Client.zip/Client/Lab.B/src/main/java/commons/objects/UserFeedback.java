package commons.objects;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>This class define what is an user feedback</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */
public class UserFeedback implements Serializable {
    /**
     * <code>song</code>
     * A Song object that is the song the feedback refers to
     */
    private Song song;
    /**
     * <code>userId</code>
     * A Long to store the user's id
     */
    private Long userId;
    /**
     * <code>emotion</code>
     * A Emotion object that is the emotion the feedback refers
     */
    private Emotion emotion;
    /**
     * <code>note</code>
     * A String to store the feedback's note
     */
    private String note;
    /**
     * <code>score</code>
     * An int to store the feedback's score
     */
    private int score;
    /**
     * <code>addDate</code>
     * A Date object representing the date when the feedback was added.
     */
    private Date addDate;
    /**
     * <code>addUserId</code>
     * A String representing the user ID of the user who added the feedback.
     */
    private String addUserId;
    /**
     * <code>modDate</code>
     * A Date object representing the date when the feedback was last modified.
     */
    private Date modDate;
    /**
     * <code>modUserId</code>
     * A String representing the user ID of the user who last modified the feedback.
     */
    private String modUserId;

    /**
     * UserFeedback default constructor
     */
    public UserFeedback() {
        this.emotion = new Emotion();
        this.song = new Song();
    }

    /**
     * UserFeedback constructor with a part of fields as parameters
     *
     *
     * @param song The song the feedback refers to
     * @param userId The user's id
     * @param emotion The emotion the feedback refers to
     * @param note The feedback's note
     * @param score The feedback's score
     */
    public UserFeedback(Song song, Long userId, Emotion emotion, String note, int score) {
        this.song = song;
        this.userId = userId;
        this.emotion = emotion;
        this.note = note;
        this.score = score;
    }

    /**
     * Constructs a new UserFeedback object with specified values for all fields.
     *
     * @param song The song the feedback refers to.
     * @param userId The user's ID.
     * @param emotion The emotion associated with the feedback.
     * @param note A note provided with the feedback.
     * @param score The score given in the feedback.
     * @param addDate The date when the feedback was added.
     * @param addUserId The user ID of the user who added the feedback.
     * @param modDate The date when the feedback was last modified.
     * @param modUserId The user ID of the user who last modified the feedback.
     */
    public UserFeedback(Song song, Long userId, Emotion emotion, String note, int score, Date addDate, String addUserId, Date modDate, String modUserId) {
        this.song = song;
        this.userId = userId;
        this.emotion = emotion;
        this.note = note;
        this.score = score;
        this.addDate = addDate;
        this.addUserId = addUserId;
        this.modDate = modDate;
        this.modUserId = modUserId;
    }

    /**
     * This method return the song field.
     * @return Song the song.
     */
    public Song getSong() {
        return song;
    }

    /**
     * song setter method.
     * @param song The song to set.
     */
    public void setSong(Song song) {
        this.song = song;
    }

    /**
     * This method return the userId field.
     * @return Long the userId.
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * userId setter method.
     * @param userId The userId to set.
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * This method return the emotion field.
     * @return Emotion the emotion.
     */
    public Emotion getEmotion() {
        return emotion;
    }

    /**
     * emotion setter method.
     * @param emotion The emotion to set.
     */
    public void setEmotion(Emotion emotion) {
        this.emotion = emotion;
    }


    /**
     * This method return the note field.
     * @return String the note.
     */
    public String getNote() {
        return note;
    }

    /**
     * note setter method
     * @param note The note to set.
     */
    public void setNote(String note) {
        this.note = note;
    }

    /**
     * This method return the score field.
     * @return int the score.
     */
    public int getScore() {
        return score;
    }

    /**
     * score setter method
     * @param score The score to set.
     */
    public void setScore(int score) {
        this.score = score;
    }

    /**
     * This method return the addDate field.
     * @return Date the addDate.
     */
    public Date getAddDate() {
        return addDate;
    }

    /**
     * addDate setter method
     * @param addDate The addDate to set.
     */
    public void setAddDate(Date addDate) {
        this.addDate = addDate;
    }

    /**
     * This method return the addUserId field.
     * @return String the addUserId.
     */
    public String getAddUserId() {
        return addUserId;
    }

    /**
     * addUserId setter method
     * @param addUserId The addUserId to set.
     */
    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    /**
     * This method return the modDate field.
     * @return Date the modDate.
     */
    public Date getModDate() {
        return modDate;
    }

    /**
     * modDate setter method
     * @param modDate The modDate to set.
     */
    public void setModDate(Date modDate) {
        this.modDate = modDate;
    }

    /**
     * This method return the modUserId field.
     * @return String the modUserId.
     */
    public String getModUserId() {
        return modUserId;
    }

    /**
     * modUserId setter method
     * @param modUserId The modUserId to set.
     */
    public void setModUserId(String modUserId) {
        this.modUserId = modUserId;
    }
}
