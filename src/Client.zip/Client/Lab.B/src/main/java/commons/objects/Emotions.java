package commons.objects;


import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>This class define all the possible emotion</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */
public class Emotions implements Serializable {
    /**
     * This method initializes the map to store emotions.
     */
    private static Map<Long, Emotion> emotionMap = new HashMap<>();

    /**
     * This method returns the map containing emotions.
     *
     * @return The map containing emotions.
     */

    public static Map<Long, Emotion> getEmotionMap() {
        return emotionMap;
    }

    /**
     * This method sets the map containing emotions.
     *
     * @param emotionMap The map containing emotions to set.
     */

    public static void setEmotionMap(Map<Long, Emotion> emotionMap) {
        Emotions.emotionMap = emotionMap;
    }
}

