package commons.objects;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * <p>This class define what is a playlist</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */
public class Playlist implements Serializable {
    /**
     * <code>playlistId</code>
     * A Long to keep track of the playlist's id.
     */
    private Long playlistId;
    /**
     * <code>userId</code>
     * A Long to keep track of the user's id.
     */
    private Long userId;
    /**
     * <code>name</code>
     * A String to store the playlist's name.
     */
    private String name;
    /**
     * <code>description</code>
     * A String to store the playlist's description.
     */
    private String description;
    /**
     * <code>numberOfSongs</code>
     * A Long which rappresents the number of songs inside the playlist.
     */
    private Long numberOfSongs;
    /**
     * <code>addDate</code>
     * A Date to store the playlist's add date.
     */
    private Date addDate;
    /**
     * <code>playlistDuration</code>
     * A String which rappresents the playlist duration.
     */
    private String playlistDuration;
    /**
     * <code>songs</code>
     * A List of Song to store the song of a playlist.
     */
    private List<Song> songs;

    /**
     * Playlist default constructor.
     */
    public Playlist() {
        this.songs = new ArrayList<>();
    }

    /**
     * Playlist constructor with name field as parameters.
     * @param name The playlist's name.
     */
    public Playlist(String name) {
        this.name = name;
    }

    /**
     * Playlist constructor with all fields as parameters.
     *
     * @param playlistId The playlist's id.
     * @param userId The user's id.
     * @param name The playlist's name.
     * @param description The playlist's description.
     * @param songs The playlist's songs.
     */
    public Playlist(Long playlistId, Long userId, String name, String description, List<Song> songs) {
        this.playlistId = playlistId;
        this.userId = userId;
        this.name = name;
        this.description = description;
        this.songs = songs;
    }

    /**
     * Playlist constructor with all fields as parameters.
     *
     * @param playlistId The playlist's id.
     * @param userId The user's id.
     * @param name The playlist's name.
     * @param description The playlist's description.
     * @param songs The playlist's songs.
     * @param numberOfSongs The playlist's number of songs
     * @param playlistDuration The playlist's duration
     */
    public Playlist(Long playlistId, Long userId, String name, String description,
                    Long numberOfSongs, String playlistDuration, List<Song> songs) {
        this.playlistId = playlistId;
        this.userId = userId;
        this.name = name;
        this.description = description;
        this.numberOfSongs = numberOfSongs;
        this.playlistDuration = playlistDuration;
        this.songs = songs;
    }

    /**
     * This method return the playlistId field.
     * @return Long the playlistId.
     */
    public Long getPlaylistId() {
        return playlistId;
    }

    /**
     * playlistId setter method.
     * @param playlistId The playlistId to set.
     */
    public void setPlaylistId(Long playlistId) {
        this.playlistId = playlistId;
    }

    /**
     * This method return the userId field.
     * @return Long the userId.
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * userId setter method.
     * @param userId The userId to set.
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * This method return the playlist's name field.
     * @return String the name.
     */
    public String getName() {
        return name;
    }

    /**
     * name setter method.
     * @param name The playlist's name to set.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * This method return the playlist's description field.
     * @return String the description.
     */
    public String getDescription() {
        return description;
    }

    /**
     * name setter method.
     * @param description The playlist's name to set.
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * This method return a Map of Song.
     * @return The map of Songs.
     */
    public List<Song> getSongs() {
        return songs;
    }

    /**
     * songs setter method.
     * @param songs The playlist's songs to set.
     */
    public void setSongs(List<Song> songs) {
        this.songs = songs;
    }

    /**
     * This method return a Long.
     * @return The number of songs inside the playlist.
     */
    public Long getNumberOfSongs() {
        return numberOfSongs;
    }

    /**
     * songs setter method.
     * @param numberOfSongs The playlist's number of songs to set.
     */
    public void setNumberOfSongs(Long numberOfSongs) {
        this.numberOfSongs = numberOfSongs;
    }

    /**
     * This method return a String.
     * @return The playlist's duration.
     */
    public String getPlaylistDuration() {
        return playlistDuration;
    }

    /**
     * songs setter method.
     * @param playlistDuration The playlist's duration to set.
     */
    public void setPlaylistDuration(String playlistDuration) {
        this.playlistDuration = playlistDuration;
    }

    /**
     * This method return a Date.
     * @return The playlist's add date.
     */
    public Date getAddDate() {
        return addDate;
    }

    /**
     * This method return a String.
     * @return The playlist's add date to string.
     */
    public String getAddDateStr() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
        String addDate = sdf.format(this.addDate);
        return addDate;
    }

    /**
     * songs setter method.
     * @param addDate The playlist's add date to set.
     */
    public void setAddDate(Date addDate) {
        this.addDate = addDate;
    }
}
