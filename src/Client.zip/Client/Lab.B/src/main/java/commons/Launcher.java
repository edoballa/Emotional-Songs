package commons;

import clientES.ClientES;

public class Launcher {
    public static void main(String[] args) {
        ClientES.main(args);
    }
}
