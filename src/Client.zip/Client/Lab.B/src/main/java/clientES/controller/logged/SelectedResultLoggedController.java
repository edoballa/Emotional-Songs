package clientES.controller.logged;

import clientES.ClientES;
import clientES.services.SongDetail_Service;
import clientES.services.UserInfo_Service;
import commons.objects.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;

import java.net.URL;
import java.util.ResourceBundle;
/**
 * <p>This class manages the graphical interface that shows details of a selected song.
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class SelectedResultLoggedController implements Initializable {
    /**
     * <code>application</code>
     * A reference to the main application instance, responsible for managing navigation between screens and user interactions.
     */
    @FXML
    private ClientES application;
    /**
     * <code>reservedAreaChoiceBox</code>
     * A ChoiceBox used for selecting options related to the user's reserved area.
     */
    @FXML
    private ChoiceBox<String> reservedAreaChoiceBox;
    /**
     * <code>usernameLabel</code>
     * A Label used for displaying the username of the currently logged-in user.
     */
    @FXML
    private Label usernameLabel;
    /**
     * <code>backButton</code>
     * A Button used for navigating back to the previous screen or view..
     */
    @FXML
    private Button backButton;
    /**
     * <code>addSongInPlaylistButton</code>
     * A Button used for adding the current song to a playlist.
     */
    @FXML
    private Button addSongInPlaylistButton;
    /**
     * <code>imageView</code>
     * An ImageView object used for displaying an image, such as an arrow icon indicating navigation direction.
     */
    @FXML
    private ImageView imageView;
    /**
     * <code>imageLeftArrow</code>
     * An Image object representing the left arrow icon used for navigation.
     */
    private Image imageLeftArrow;
    /**
     * <code>songTitleLabel</code>
     * A Label used for displaying the title of the current song.
     */
    @FXML
    private Label songTitleLabel;
    /**
     * <code>songAuthorLabel</code>
     * A Label used for displaying the author of the current song.
     */
    @FXML
    private Label songAuthorLabel;
    /**
     * <code>songAlbumLabel</code>
     * A Label used for displaying the album of the current song.
     */
    @FXML
    private Label songAlbumLabel;
    /**
     * <code>songYearLabel</code>
     * A Label used for displaying the year of the current song.
     */
    @FXML
    private Label songYearLabel;
    /**
     * <code>songDurationLabel</code>
     * A Label used for displaying the duration of the current song.
     */
    @FXML
    private Label songDurationLabel;
    /**
     * <code>statisticsTable</code>
     * A TableView used for displaying statistics related to emotion feedback.
     */
    @FXML
    private TableView<EmotionFeedbackStatistics> statisticsTable;
    /**
     * <code>commentsTable</code>
     * A TableView used for displaying comments related to the current song.
     */
    @FXML
    private TableView<CommentLineData> commentsTable;
    /**
     * <code>playlistList</code>
     * A ChoiceBox used for displaying playlists available for adding the current song.
     */
    @FXML
    private ChoiceBox<String> playlistList;
    /**
     * <code>dismissErrorButton</code>
     * A Button used for dismissing error messages or notifications.
     */
    @FXML
    private Button dismissErrorButton;
    /**
     * <code>errorLabel</code>
     * A Label used for displaying error messages or notifications.
     */
    @FXML
    private Label errorLabel;
    /**
     * <code>errorRectangle</code>
     * A Rectangle used for displaying a visual indication of errors or notifications.
     */
    @FXML
    private Rectangle errorRectangle;
    /**
     * <code>song</code>
     * The currently selected Song object.
     */
    private Song song;
    /**
     * <code>previusPage</code>
     * The previous page or view from which the user navigated to the current page.
     */
    private String previusPage = "";
    /**
     * <code>userInfoService</code>
     * Service class for managing user information.
     */
    private UserInfo_Service userInfoService;
    /**
     * <code>songDetailService</code>
     * Service class for managing song details.
     */
    private SongDetail_Service songDetailService;

    /**
     * Inner class representing a single line of comment data.
     */
    private class CommentLineData {
        public String emotionName;
        public String comment;
    }

    /**
     * Initializes the controller after its root element has been completely processed.
     * This method is called once all FXML elements have been loaded and their associated controllers initialized.
     *
     * @param location The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param rb The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL location, ResourceBundle rb) {
        if(userInfoService == null){
            userInfoService =  new UserInfo_Service();
        }

        if(songDetailService == null){
            songDetailService = new SongDetail_Service();
        }

        imageLeftArrow = new Image(getClass().getResource("/clientES/images/leftArrow.png").toExternalForm());
        imageView.setImage(imageLeftArrow);

        imageView.setFitHeight(20);
        imageView.setFitWidth(20);

        backButton.setGraphic(imageView);

        backButton.setOnMouseEntered(event -> {
            backButton.setTooltip(new Tooltip("Torna indietro"));
        });

        backButton.setOnMouseExited(event -> {
            backButton.setTooltip(null);
        });

        if(application != null && application.getUser() != null) {
            if(usernameLabel == null){
                usernameLabel = new Label();
            }

            usernameLabel.setText(application.getUser().getUsername());
        }

        if(song == null){
            song = new Song();
        }

        playlistList.setMaxHeight(100);

        setLabelsValue();
        configureTablesColumns();
    }
    /**
     * This method configures the columns of the table view to display song information.
     */
    private void configureTablesColumns() {
        // Populate statisticsTable
        TableColumn<EmotionFeedbackStatistics, String> emotionCol = new TableColumn<>("EMOZIONE");
        TableColumn<EmotionFeedbackStatistics, String> averageScoreCol = new TableColumn<>("MEDIA PUNTEGGIO");
        TableColumn<EmotionFeedbackStatistics, String> numberOfVotesCol = new TableColumn<>("NUMERO DI VOTI");

        emotionCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getEmotion().getName()));
        averageScoreCol.setCellValueFactory(cellData -> new SimpleStringProperty("" + cellData.getValue().getAverageOfRatings().doubleValue()));
        numberOfVotesCol.setCellValueFactory(cellData -> new SimpleStringProperty("" + cellData.getValue().getNumberOfRatings()));

        emotionCol.setPrefWidth(200);
        averageScoreCol.setPrefWidth(200);
        numberOfVotesCol.setPrefWidth(200);

        statisticsTable.getColumns().addAll(emotionCol, averageScoreCol, numberOfVotesCol);
        refreshStatisticsTable();

        // Populate commentsTable
        TableColumn<CommentLineData, String> emotionCommentCol = new TableColumn<>("EMOZIONE");
        TableColumn<CommentLineData, String> commentCol = new TableColumn<>("COMMENTO");

        emotionCommentCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().emotionName));
        commentCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().comment));

        emotionCommentCol.setPrefWidth(150);
        commentCol.setPrefWidth(450);

        commentsTable.getColumns().addAll(emotionCommentCol, commentCol);
        refreshCommentsTable();
    }
    /**
     * This method populates the ChoiceBox with playlists available for the current user.
     * @throws Exception if there is an error while loading or setting up playlists.
     */
    private void playlistList() throws Exception {
        if(application != null && application.getUser() != null){
            if(application.getUser().getPlaylists() == null
                    || application.getUser().getPlaylists().isEmpty()
                    || application.getUser().getPlaylists().size() == 0) {
                userInfoService.loadUserPlaylist(application.getUser());
            }

            if(application.getUser().getPlaylists().size() == 0){
                playlistList.setVisible(false);
                addSongInPlaylistButton.setVisible(false);
            } else {
                playlistList.setVisible(true);
                addSongInPlaylistButton.setVisible(true);
            }

            ObservableList<String> playlists = FXCollections.observableArrayList();
            for(Playlist p : application.getUser().getPlaylists()){
                String pName = p.getPlaylistId() + " - " + p.getName();
                playlists.add(pName);
            }

            playlistList.setItems(playlists);

        } else {
            playlistList.setVisible(false);
            addSongInPlaylistButton.setVisible(false);
        }
    }
    /**
     * This method updates the text of labels displaying song information.
     */
    public void setLabelsValue(){
        // Set values for labels
        if(songTitleLabel != null) {
            songTitleLabel.setText(song.getTitle());
        }
        if(songAuthorLabel != null) {
            songAuthorLabel.setText(song.getAuthor());
        }
        if(songAlbumLabel != null) {
            songAlbumLabel.setText(song.getAlbum());
        }
        if(songYearLabel != null) {
            songYearLabel.setText(song.getYear());
        }
        if(songDurationLabel != null) {
            songDurationLabel.setText(song.getDuration() + "");
        }
    }
    /**
     * This method updates the content of the statistics table with the latest data.
     */
    public void refreshStatisticsTable() {
        statisticsTable.getItems().clear();
        ObservableList<EmotionFeedbackStatistics> statisticsData = FXCollections.observableArrayList();
        statisticsData.addAll(song.getEmotionList());
        statisticsTable.setItems(statisticsData);
    }
    /**
     * This method updates the content of the comments table with the latest data.
     */
    public void refreshCommentsTable() {
        commentsTable.getItems().clear();
        ObservableList<CommentLineData> commentData = FXCollections.observableArrayList();
        for (EmotionFeedbackStatistics efd : song.getEmotionList()) {
            String emotionName = efd.getEmotion().getName();

            for (String comment : efd.getComments()) {
                CommentLineData lineData = new CommentLineData();
                lineData.emotionName = emotionName;
                lineData.comment = comment;
                commentData.add(lineData);
            }

        }

        commentsTable.setItems(commentData);
    }
    /**
     * This method navigates the user to the previous screen or view.
     * @param event The ActionEvent triggered by clicking the back button.
     */
    @FXML
    protected void onBackButtonClick(ActionEvent event) {
        if(application != null && previusPage.equals("SEARCH")) {
            application.switchToSearchResultsLogged();
        } else if(application != null && previusPage.equals("PLAYLIST")) {
            application.switchToUserPlaylistDetails();
        }
    }
    /**
     * This method adds the current song to the selected playlist.
     * If no playlist is selected, it displays an error message.
     * @param event The ActionEvent triggered by clicking the "Add Song to Playlist" button.
     * @throws Exception if there is an error while adding the song to the playlist.
     */
    @FXML
    protected void onAddSongInPlaylistButton(ActionEvent event) throws Exception {
        resetMessageInitConfig();
        if(playlistList.getValue() == null || playlistList.getValue().isEmpty()){
            errorLabel.setText("Devi selezionare una playlist per poter aggiungere la canzone.");
            errorRectangle.setVisible(true);
            dismissErrorButton.setVisible(true);
            errorLabel.setVisible(true);
            return;
        }

        boolean isAdded = songDetailService.addSongInPlaylist(song.getSongId(), playlistList.getValue(), application.getUser().getUserId());
        if(isAdded) {
            errorRectangle.setFill(Paint.valueOf("#80FF7C"));
            dismissErrorButton.setTextFill(Paint.valueOf("#2ECC1C"));
            errorLabel.setText("La canzone è stata aggiunta alla playlist con successo!");
        } else {
            errorLabel.setText("Qualcosa è andato storto. Potrebbe essere che hai già questa canzone nella playlist, si prega di riprovare.");
        }

        errorRectangle.setVisible(true);
        dismissErrorButton.setVisible(true);
        errorLabel.setVisible(true);
    }
    /**
     * This method navigates the user to the page for adding feedback for the current song.
     * @param event The ActionEvent triggered by clicking the "Add Feedback" button.
     */
    @FXML
    protected void addFeedbackButton(ActionEvent event) {
        if(application != null) {
            application.switchToNewUserFeedback(this.song, previusPage);
        }
    }
    /**
     * This method sets the application instance for this controller.
     * @param application The ClientES instance representing the application.
     */
    public void setApplication(ClientES application) {
        this.application = application;
    }
    /**
     * This method retrieves the currently selected song.
     * @return The currently selected Song object.
     */

    public Song getSong() {
        return song;
    }
    /**
     * This method sets the currently selected song.
     * @param song The Song object to be set as the currently selected song.
     * @throws Exception if there is an error while setting the song.
     */
    public void setSong(Song song) throws Exception {
        this.song = song;
        resetMessageInitConfig();
        setLabelsValue();
        refreshStatisticsTable();
        refreshCommentsTable();
        playlistList();
    }
    /**
     * This method sets the text of the username label.
     * @param text The text to be set for the username label.
     */
    public void setUsernameLabelText(String text){
        if(usernameLabel == null){
            usernameLabel = new Label();
        }
        usernameLabel.setText(text);
    }
    /**
     * This method handles the selection of options in the reserved area ChoiceBox.
     * It performs different actions based on the selected option.
     * @param event The ActionEvent triggered by selecting an option in the ChoiceBox.
     */
    @FXML
    protected void reservedAreaOptions(ActionEvent event) {
        String selectedOption = reservedAreaChoiceBox.getValue();
        clearChoiceBoxSelection();
        
        if(selectedOption == null){
            return;
        } else if(application != null && selectedOption.equals("Il mio profilo")){
            application.switchToUserProfile();
        } else if(application != null && selectedOption.equals("Modifica password")){
            application.switchToChangePassword();
        } else if(application != null && selectedOption.equals("Le mie playlist")){
            application.switchToUserPlaylist();
        } else if(application != null && selectedOption.equals("Le mie valutazioni")){
            application.switchToUserFeedback();
        } else if(application != null && selectedOption.equals("Logout")){
            application.logout();
        }
    }
    /**
     * This method clears the selection of the reserved area ChoiceBox.
     * It deselects any currently selected option.
     */
    public void clearChoiceBoxSelection() {
        if (reservedAreaChoiceBox != null) {
            reservedAreaChoiceBox.getSelectionModel().clearSelection();
        }
    }
    /**
     * This method sets the previous page or view from which the user navigated to the current page.
     * @param previusPage The name of the previous page or view.
     */
    public void setPreviusPage(String previusPage) {
        this.previusPage = previusPage;
    }

    /**
     * This method handles the action event when the dismiss error button is clicked.
     * It resets the error message configuration and hides the error message.
     * @param event The ActionEvent triggered by clicking the dismiss error button.
     */
    @FXML
    protected void onDismissErrorButtonClick(ActionEvent event) {
        resetMessageInitConfig();
    }
    /**
     * This method resets the initial configuration of the error message display.
     * It hides the error message and resets the error message color.
     */
    public void resetMessageInitConfig(){
        errorRectangle.setFill(Paint.valueOf("#ff9393"));
        dismissErrorButton.setTextFill(Paint.valueOf("#cc0000"));

        dismissErrorButton.setVisible(false);
        errorLabel.setText("");
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }
}
