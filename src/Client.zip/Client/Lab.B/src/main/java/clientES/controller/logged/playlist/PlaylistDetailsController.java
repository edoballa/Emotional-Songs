package clientES.controller.logged.playlist;

import clientES.ClientES;
import clientES.services.Playlist_Service;
import commons.objects.Playlist;
import commons.objects.Song;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.function.UnaryOperator;
import java.util.regex.Pattern;

/**
 * <p>This class define the methods to interact with playlists details</p>*
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class PlaylistDetailsController implements Initializable {
    /**
     * <code>application</code>
     * An ClientES object that manages the navigation between different screens and provides functionality for user interactions.
     */
    @FXML private ClientES application;
    /**
     * <code>reservedAreaChoiceBox</code>
     * A ChoiceBox used for selecting options related to the user's reserved area.
     */
    @FXML private ChoiceBox<String> reservedAreaChoiceBox;
    /**
     * <code>usernameLabel</code>
     * A Label used for displaying the username of the currently logged-in user.
     */
    @FXML private Label usernameLabel;
    /**
     * <code>backButton</code>
     * A Button used for navigating back to the previous screen or view..
     */
    @FXML private Button backButton;
    /**
     * <code>imageView</code>
     * An ImageView object used for displaying an image, such as an arrow icon indicating navigation direction.
     */
    @FXML private ImageView imageView;
    /**
     * <code>imageLeftArrow</code>
     * An Image object representing a left arrow icon.
     */
    @FXML private Image imageLeftArrow;
    /**
     * <code>plNameLabel</code>
     * A Label used for displaying the name of a playlist.
     */
    @FXML private Label plNameLabel;
    /**
     * <code>plNumSongsLabel</code>
     * A Label used for displaying the number of songs in a playlist.
     */
    @FXML private Label plNumSongsLabel;
    /**
     * <code>plDurationLabel</code>
     * A Label used for displaying the total duration of a playlist.
     */
    @FXML private Label plDurationLabel;
    /**
     * <code>plDescrLabel</code>
     * A Label used for displaying the description of a playlist.
     */
    @FXML private Label plDescrLabel;
    /**
     * <code>songIdToRemove</code>
     * A TextField used for inputting the ID of a song to be removed from the playlist.
     */
    @FXML private TextField songIdToRemove;
    /**
     * <code>songsTable</code>
     * A TableView used for displaying the list of songs in the playlist.
     */
    @FXML public TableView<Song> songsTable;
    /**
     * <code>dismissErrorButton</code>
     * A Button used for dismissing error messages or notifications.
     */
    @FXML private Button dismissErrorButton;
    /**
     * <code>errorLabel</code>
     * A Label used for displaying error messages to the user.
     */
    @FXML private Label errorLabel;
    /**
     * <code>errorRectangle</code>
     * A Rectangle used for visually indicating errors.
     */
    @FXML private Rectangle errorRectangle;

    /**
     * <code>needReloadSongs</code>
     * A boolean indicating whether the songs in the playlist need to be reloaded.
     */
    private boolean needReloadSongs = true;
    /**
     * <code>playlist</code>
     * A Playlist object representing the currently selected playlist.
     */
    private Playlist playlist;
    /**
     * <code>playlistService</code>
     * A Playlist_Service object responsible for handling operations related to playlists.
     */
    private Playlist_Service playlistService;

    /**
     * This method initializes the controller.
     * It configures the user interface, sets initial values for GUI components, and sets up necessary events.
     * @param location The location relative to the root object of the FXML file used to initialize the controller.
     * @param rb The ResourceBundle that can be used to localize the FXML file used to initialize the controller.
     */
    @Override
    public void initialize(URL location, ResourceBundle rb) {
        if(playlistService == null){
            playlistService =  new Playlist_Service();
        }
        imageLeftArrow = new Image(getClass().getResource("/clientES/images/leftArrow.png").toExternalForm());
        imageView.setImage(imageLeftArrow);
        imageView.setFitHeight(20);
        imageView.setFitWidth(20);

        backButton.setGraphic(imageView);
        backButton.setOnMouseEntered(event -> {
            backButton.setTooltip(new Tooltip("Torna indietro"));
        });
        backButton.setOnMouseExited(event -> {
            backButton.setTooltip(null);
        });

        if(application != null && application.getUser() != null) {
            usernameLabel.setText(application.getUser().getUsername());
        }

        if(playlist == null){
            playlist = new Playlist();
        }

        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (newText.isEmpty()) {
                return change;
            }
            if (Pattern.matches("\\d*", newText)) {
                return change;
            }
            return null; // Rejected
        };

        // Applica il filtro al TextFormatter
        TextFormatter<String> textFormatter = new TextFormatter<>(filter);
        songIdToRemove.setTextFormatter(textFormatter);

        setLabelsValue();
        configureTableColumns();
        refreshTableData();
        configureTableEvents();

    }

    /**
     * This method configures the columns for the TableView displaying the songs in the playlist.
     */
    private void configureTableColumns() {
        TableColumn<Song, String> idCol = new TableColumn<>("ID");
        TableColumn<Song, String> titleCol = new TableColumn<>("TITOLO");
        TableColumn<Song, String> authorCol = new TableColumn<>("AUTORE");
        TableColumn<Song, String> yearCol = new TableColumn<>("ANNO");
        TableColumn<Song, String> albumCol = new TableColumn<>("ALBUM");
        TableColumn<Song, String> timeCol = new TableColumn<>("DURATA");

        idCol.setCellValueFactory(cellData -> new SimpleStringProperty("" + cellData.getValue().getSongId()));
        titleCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getTitle()));
        authorCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getAuthor()));
        yearCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getYear()));
        albumCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getAlbum()));
        timeCol.setCellValueFactory(cellData -> new SimpleStringProperty("" + cellData.getValue().getDuration()));

        idCol.setPrefWidth(75);
        titleCol.setPrefWidth(200);
        authorCol.setPrefWidth(150);
        yearCol.setPrefWidth(50);
        albumCol.setPrefWidth(200);
        timeCol.setPrefWidth(75);

        songsTable.getColumns().addAll(idCol, titleCol, authorCol, yearCol, albumCol, timeCol);
    }

    /**
     * This method sets the values for the labels displaying information about the playlist.
     */
    public void setLabelsValue(){
        // Set values for labels
        plDescrLabel.setText(playlist.getDescription());
        plNameLabel.setText(playlist.getName());
        plDurationLabel.setText(playlist.getPlaylistDuration());
        plNumSongsLabel.setText("" + playlist.getNumberOfSongs());
    }

    /**
     * This method refreshes the data displayed in the TableView.
     */
    public void refreshTableData() {
        List<Song> plSongs = new ArrayList<>();

        if(playlist != null && playlist.getPlaylistId() != null
                && (playlist.getSongs() == null || playlist.getSongs().isEmpty() || needReloadSongs)) {
            try {
                playlistService.loadPlaylistSongs(playlist);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

            needReloadSongs = false;
        }

        plSongs = playlist.getSongs();

        ObservableList<Song> resultsData = FXCollections.observableArrayList(plSongs);
        songsTable.setItems(resultsData);
    }

    /**
     * This method configures the events for the TableView.
     */
    private void configureTableEvents() {
        songsTable.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2 && songsTable.getSelectionModel().getSelectedItem() != null) {
                handleTableDoubleClick(songsTable.getSelectionModel().getSelectedItem());
            }
        });
    }

    /**
     * This method handles the double-click event on a song in the TableView.*
     * @param selectedSong The song that was double-clicked in the TableView.
     */
    private void handleTableDoubleClick(Song selectedSong) {
        if (application != null) {
            try {
                application.visualizzaEmozioneBrano(selectedSong, "PLAYLIST");
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * This method handles the action event when the back button is clicked.
     * @param event The action event triggered by clicking the back button.
     */
    @FXML
    protected void onBackButtonClick(ActionEvent event) {
        if(application != null) {
            application.switchToUserPlaylist();
        }
    }

    /**
     * This method sets the application instance for this controller.
     * @param application The instance of the main application.
     */
    public void setApplication(ClientES application) {
        this.application = application;
    }

    /**
     * This method retrieves the currently selected playlist.
     * @return The currently selected playlist.
     */
    public Playlist getPlaylist() {
        return playlist;
    }

    /**
     * This method sets the currently selected playlist.
     * @param playlist The playlist to be set as currently selected.
     */
    public void setPlaylist(Playlist playlist) {
        this.playlist = playlist;
        setLabelsValue();
        resetPreviusError();
        refreshTableData();
    }

    /**
     * This method sets the text for the username label.
     * @param text The text to be set for the username label.
     */
    public void setUsernameLabelText(String text){
        if(usernameLabel == null){
            usernameLabel = new Label();
        }
        usernameLabel.setText(text);
    }

    /**
     * This method handles the selection of options in the reserved area ChoiceBox.
     * @param event The action event triggered by selecting an option in the reserved area ChoiceBox.
     */
    @FXML
    protected void reservedAreaOptions(ActionEvent event) {
        String selectedOption = reservedAreaChoiceBox.getValue();
        clearChoiceBoxSelection();
        
        if(selectedOption == null){
            return;
        } else if(application != null && selectedOption.equals("Il mio profilo")){
            application.switchToUserProfile();
        } else if(application != null && selectedOption.equals("Modifica password")){
            application.switchToChangePassword();
        } else if(application != null && selectedOption.equals("Le mie playlist")){
            application.switchToUserPlaylist();
        } else if(application != null && selectedOption.equals("Le mie valutazioni")){
            application.switchToUserFeedback();
        } else if(application != null && selectedOption.equals("Logout")){
            application.logout();
        }
    }

    /**
     * This method handles the action event when the delete playlist button is clicked.
     */
    @FXML
    public void deletePlaylistButton(){
        boolean isDeleted = false;
        try {
            isDeleted = playlistService.deletePlaylistSongs(playlist.getPlaylistId());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        if(isDeleted){
            application.switchToUserPlaylist();
        } else {
            errorLabel.setText("Si è verificato un errore durante la cancellazione, riprovare.");
            errorLabel.setVisible(true);
            errorRectangle.setVisible(true);
            dismissErrorButton.setVisible(true);
        }

    }

    /**
     * This method handles the action event when the remove song from playlist button is clicked.
     * It removes the specified song from the current playlist, if valid, and updates the playlist accordingly.
     * If the song removal is successful, it provides visual feedback to the user.
     */
    @FXML
    public void removeSongFromPlaylistButton(){
        if(songIdToRemove.getText() == null || songIdToRemove.getText().isEmpty()){
            errorLabel.setText("Compilare il campo per procedere alla rimozione.");
            dismissErrorButton.setVisible(true);
            errorLabel.setVisible(true);
            errorRectangle.setVisible(true);
            return;
        }

        Long songId = Long.valueOf(songIdToRemove.getText());

        boolean existsSong = false;
        for(Song song : playlist.getSongs()){
            if(songId.equals(song.getSongId())){
                existsSong = true;
                break;
            }
        }

        if(existsSong){
            boolean isDeleted = false;
            try {
                isDeleted = playlistService.removeSongFromPlaylistSongs(playlist.getPlaylistId(), songId);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

            if(isDeleted) {
                errorRectangle.setFill(Paint.valueOf("#80FF7C"));
                dismissErrorButton.setTextFill(Paint.valueOf("#2ECC1C"));
                errorLabel.setText("La canzone è stata rimossa con successo!");
                songIdToRemove.setText("");
                needReloadSongs = true;
                refreshTableData();
            } else {
                errorLabel.setText("Qualcosa è andato storto, si prega di riprovare.");
            }
        } else {
            errorLabel.setText("Il numero inserito non corrisponde a nessuna canzone della playlist.");
        }

        dismissErrorButton.setVisible(true);
        errorLabel.setVisible(true);
        errorRectangle.setVisible(true);

    }

    /**
     * This method handles the action event when the dismiss error button is clicked.
     * @param event The action event triggered by clicking the dismiss error button.
     */
    @FXML
    protected void onDismissErrorButtonClick(ActionEvent event) {
        errorRectangle.setFill(Paint.valueOf("#ff9393"));
        dismissErrorButton.setTextFill(Paint.valueOf("#cc0000"));

        dismissErrorButton.setVisible(false);
        errorLabel.setText("");
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }

    /**
     * Resets any previously displayed error messages or notifications.
     */
    public void resetPreviusError(){
        dismissErrorButton.setVisible(false);
        errorLabel.setText("");
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }

    /**
     * Clears the current selection in the reserved area ChoiceBox.
     */
    public void clearChoiceBoxSelection() {
        if (reservedAreaChoiceBox != null) {
            reservedAreaChoiceBox.getSelectionModel().clearSelection();
        }
    }
}
