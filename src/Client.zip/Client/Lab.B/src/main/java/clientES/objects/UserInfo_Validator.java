package clientES.objects;

/**
 * <p>This class provides methods to validate user information fields such as email, password, and address.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class UserInfo_Validator {
    /**
     * <code>addressCalculator</code>
     * An Address_Calculator instance used for address validation.
     */
    private Address_Calculator addressCalculator;

    /**
     * This Constructs a new UserInfo_Validator object and initializes the Address_Calculator instance.
     */
    public UserInfo_Validator(){
        addressCalculator = new Address_Calculator();
    }

    /**
     * This method checks if the given field is valid based on the specified conditions.
     *
     * @param field the field value to validate
     * @param checkStrLength a flag indicating whether to check the length of the string
     * @param length the expected length of the string (if checkStrLength is true)
     * @return true if the field is valid, false otherwise
     */
    public boolean isFieldValid(String field, boolean checkStrLength, int length){
        if(field == null || field.isEmpty()){
            return false;
        }

        if(checkStrLength && field.length() != length){
            return false;
        }

        return true;
    }

    /**
     * This method checks if the given email address is valid.
     *
     * @param email the email address to validate
     * @return true if the email address is valid, false otherwise
     */
    public boolean isEmailValid(String email) {
        boolean containsAtChar = email.contains("@");

        if(email == null || email.isEmpty()){
            return false;
        } else if (!containsAtChar) {
            return false;
        } else {
            String[] emailSplitUsingAt = email.split("@");
            if(emailSplitUsingAt.length == 2){
                String[] emailDomain = emailSplitUsingAt[1].split("\\.");
                if(emailDomain.length != 2){
                    return false;
                }
            } else {
               return false;
            }
        }

        return true;
    }

    /**
     * This method checks if the given password meets the required criteria.
     *
     * @param password the password to validate
     * @return true if the password is valid, false otherwise
     */
    public boolean isPasswordValid(String password){
        if(password == null || password.isEmpty() || password.length() < 8){
            return false;
        }

        if(!(password.contains("0") || password.contains("1") || password.contains("2") || password.contains("3")
                || password.contains("4") || password.contains("5") || password.contains("6") || password.contains("7")
                || password.contains("8") || password.contains("9"))){
            return false;
        }

        return true;
    }

    /**
     * This method validates the user information fields such as fiscal code, email, first name, last name, and address.
     *
     * @param fiscalCode the fiscal code to validate
     * @param email the email address to validate
     * @param firstName the first name to validate
     * @param lastName the last name to validate
     * @param address the address to validate
     * @return a validation error message if any, or null if all fields are valid
     */
    public String validateUserInfo(String fiscalCode, String email, String firstName, String lastName, String address) {
        boolean isFirstNameValid = this.isFieldValid(firstName, false, firstName.length());
        if(!isFirstNameValid){
            return "Compilare il campo nome";
        }

        boolean isLastNameValid = this.isFieldValid(lastName, false, lastName.length());
        if(!isLastNameValid){
            return "Compilare il campo cognome";
        }

        boolean isFiscalCodeValid = this.isFieldValid(fiscalCode, true, 16);
        if(!isFiscalCodeValid){
            return "Codice fiscale non valido";
        }

        boolean isEmailValid = this.isEmailValid(email);
        if(!isEmailValid){
            return "Compilare correttamente il campo indirizzo email";
        }

        boolean isAddressValid = addressCalculator.isValidAddress(address);
        if (!isAddressValid){
            return "Compilare correttamente il campo indirizzo ";
        }

        return null;
    }


}
