package clientES.controller.notlogged;

import clientES.ClientES;
import commons.objects.Song;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import java.net.URL;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
/**
 * <p> This class represents the controller for the search results screen. It implements the Initializable interface to initialize the controller.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class SearchResultsController implements Initializable {
    /**
     * <code>application</code>
     * A reference to the main application instance, responsible for managing navigation between screens and user interactions.
     */
    @FXML
    private ClientES application;
    /**
     * <code>subscribeButton</code>
     * A Button used for initiating the registration process.
     */
    @FXML
    private Button subscribeButton;
    /**
     * <code>loginButton</code>
     * A Button used for navigating to the login page.
     */
    @FXML
    private Button loginButton;
    /**
     * Represents a Button used for navigating back to the previous screen.
     * <code>backButton</code>
     */
    @FXML
    private Button backButton;
    /**
     * Represents a Label used for displaying the last search term.
     * <code>lastSearchLabel</code>
     */
    @FXML
    private Label lastSearchLabel;
    /**
     * Represents an ImageView used for displaying an image, such as an arrow icon indicating navigation direction.
     * <code>imageView</code>
     */
    @FXML
    private ImageView imageView;
    /**
     * Represents an Image object representing the left arrow icon used for navigation.
     * <code>imageLeftArrow</code>
     */
    private Image imageLeftArrow;
    /**
     * Represents a TableView used for displaying search results of type Song.
     * <code>resultsTable</code>
     */
    @FXML
    public TableView<Song> resultsTable;
    /**
     * Represents the search term used for the search operation.
     * <code>searchTerm</code>
     */
    private static String searchTerm = "";
    /**
     * Represents the list of search results of type Song.
     * <code>searchResult</code>
     */
    private static List<Song> searchResult = null;
    /**
     * This method initializes the SearchResultsController.
     * It configures the appearance and behavior of the search results table and sets up the navigation buttons.
     *
     * @param location  The location used for resolving relative paths for resources.
     * @param rb        The resource bundle containing locale-specific objects.
     */
    @Override
    public void initialize(URL location, ResourceBundle rb) {
        Font defaultFont = new Font(22.0);

        subscribeButton.setOnMouseEntered(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                subscribeButton.setTextFill(Color.WHITE);
                subscribeButton.setFont(new Font(23.0));
                subscribeButton.setPrefHeight(43.0);
                subscribeButton.setPrefWidth(97.0);
            }
        });

        loginButton.setOnMouseEntered(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                loginButton.setFont(new Font(23.0));
                loginButton.setPrefHeight(43.0);
                loginButton.setPrefWidth(97.0);
            }
        });

        subscribeButton.setOnMouseExited(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                subscribeButton.setTextFill(Color.web("#d2d2d2"));
                subscribeButton.setFont(defaultFont);
                subscribeButton.setPrefHeight(41.0);
                subscribeButton.setPrefWidth(95.0);
            }
        });

        loginButton.setOnMouseExited(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                loginButton.setFont(defaultFont);
                loginButton.setPrefHeight(41.0);
                loginButton.setPrefWidth(95.0);
            }
        });

        if(lastSearchLabel == null){
            lastSearchLabel = new Label();
        }

        imageLeftArrow = new Image(getClass().getResource("/clientES/images/leftArrow.png").toExternalForm());
        imageView.setImage(imageLeftArrow);
        imageView.setFitHeight(20);
        imageView.setFitWidth(20);

        backButton.setGraphic(imageView);
        backButton.setOnMouseEntered(event -> backButton.setTooltip(new Tooltip("Torna indietro")));
        backButton.setOnMouseExited(event -> backButton.setTooltip(null));

        configureTableColumns();
        refreshTableData();
        configureTableEvents();
    }
    /**
     * Configures the columns of the results table.
     * This method creates and sets up the columns for the song title, author, year, album, and duration.
     */
    private void configureTableColumns() {
        TableColumn<Song, String> titleCol = new TableColumn<>("TITOLO");
        TableColumn<Song, String> authorCol = new TableColumn<>("AUTORE");
        TableColumn<Song, String> yearCol = new TableColumn<>("ANNO");
        TableColumn<Song, String> albumCol = new TableColumn<>("ALBUM");
        TableColumn<Song, String> timeCol = new TableColumn<>("DURATA");

        titleCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getTitle()));
        authorCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getAuthor()));
        yearCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getYear()));
        albumCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getAlbum()));
        timeCol.setCellValueFactory(cellData -> new SimpleStringProperty("" + cellData.getValue().getDuration()));

        titleCol.setPrefWidth(200);
        authorCol.setPrefWidth(200);
        yearCol.setPrefWidth(50);
        albumCol.setPrefWidth(200);
        timeCol.setPrefWidth(75);

        resultsTable.getColumns().addAll(titleCol, authorCol, yearCol, albumCol, timeCol);
    }
    /**
     * This method refreshes the data displayed in the search results table.
     * It updates the table with the latest search results.
     */
    public void refreshTableData() {
        if(searchResult == null){
            searchResult = new ArrayList<>();
        }

        ObservableList<Song> resultsData = FXCollections.observableArrayList(searchResult);
        resultsTable.setItems(resultsData);
    }
    /**
     * This method configures the event handler for the search results table.
     * It sets up an event listener to handle double-click events on table rows.
     */
    private void configureTableEvents() {
        resultsTable.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2 && resultsTable.getSelectionModel().getSelectedItem() != null) {
                try {
                    handleTableDoubleClick(resultsTable.getSelectionModel().getSelectedItem());
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }
    /**
     * This method handles the action to be performed when a row in the search results table is double-clicked.
     * It retrieves the selected song from the table and triggers the visualization of its emotion.
     *
     * @param selectedSong The song selected by the user in the table.
     * @throws SQLException   If an SQL exception occurs while retrieving data.
     * @throws RemoteException If a remote exception occurs.
     */
    private void handleTableDoubleClick(Song selectedSong) throws SQLException, RemoteException {
        if (application != null) {
            application.visualizzaEmozioneBrano(selectedSong);
        }
    }
    /**
     * This method handles the action event when the user clicks on the subscribe button.
     * It switches the application to the registration page.
     *
     * @param event The action event triggered by clicking the subscribe button.
     */
    @FXML
    protected void onSubscribeButtonClick(ActionEvent event) {
        if(application != null) {
            application.switchToRegistration1();
        }
    }
    /**
     * This method handles the action event when the user clicks on the login button.
     * It switches the application to the login page.
     *
     * @param event The action event triggered by clicking the login button.
     */
    @FXML
    protected void onLoginButtonClick(ActionEvent event) {
        if(application != null) {
            application.switchToLogin();
        }
    }
    /**
     * This method handles the action event when the user clicks on the back button.
     * It switches the application to the home page.
     *
     * @param event The action event triggered by clicking the back button.
     */
    @FXML
    protected void onBackButtonClick(ActionEvent event) {
        if(application != null) {
            application.switchToHome();
        }
    }
    /**
     * This method sets the main application instance, responsible for managing navigation between screens and user interactions.
     *
     * @param application The main application instance to be set.
     */

    public void setApplication(ClientES application) {
        this.application = application;
    }
    /**
     * This method sets the search result list to be displayed in the search results table.
     *
     * @param searchResult The list of songs to be set as search result.
     */

    public void setSearchResult(List<Song> searchResult) {
        this.searchResult = searchResult;
        refreshTableData();
    }
    /**
     * This method retrieves the search result list currently displayed in the search results table.
     *
     * @return The list of songs currently displayed as search result.
     */
    public List<Song> getSearchResult() {
        return this.searchResult;
    }
    /**
     * This method retrieves the search term used to perform the search.
     *
     * @return The search term.
     */
    public String getSearchTerm() {
        return searchTerm;
    }
    /**
     * This method sets the search term used to perform the search.
     *
     * @param searchTerm The search term to be set.
     */
    public void setSearchTerm(String searchTerm) {
        this.searchTerm = searchTerm;
        lastSearchLabel.setText(searchTerm);
    }
}
