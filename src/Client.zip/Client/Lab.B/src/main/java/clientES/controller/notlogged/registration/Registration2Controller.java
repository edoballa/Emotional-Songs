package clientES.controller.notlogged.registration;

import clientES.ClientES;
import clientES.services.Registration_Service;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;

import java.io.IOException;
import java.rmi.NotBoundException;
import java.sql.SQLException;
/**
 * <p>This class represents the controller for the second step of the registration process.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class Registration2Controller {
    /**
     * <code>application</code>
     * A reference to the main application instance, responsible for managing navigation between screens and user interactions.
     */
    @FXML
    private ClientES application;
    /**
     * <code>backButton</code>
     * A Button used for navigating back to the previous screen or view..
     */
    @FXML
    private Button backButton;
    /**
     * <code>imageView</code>
     * An ImageView object used for displaying an image, such as an arrow icon indicating navigation direction.
     */
    @FXML
    private ImageView imageView;
    /**
     * <code>imageLeftArrow</code>
     * An Image object representing the left arrow icon used for navigation.
     */
    private Image imageLeftArrow;
    /**
     * <code>subscribeButton</code>
     * A Button used for initiating the registration process.
     */
    @FXML
    private Button subscribeButton;
    /**
     * <code>loginButton</code>
     * A Button used for navigating to the login page.
     */
    @FXML
    private Button loginButton;
    /**
     * <code>fiscalCodeField</code>
     * A TextField for entering the fiscal code during registration.
     */
    @FXML
    private TextField fiscalCodeField;
    /**
     * <code>emailField</code>
     * A TextField for entering the email address during registration.
     */
    @FXML
    private TextField emailField;
    /**
     * <code>firstNameField</code>
     * A TextField for entering the first name during registration.
     */
    @FXML
    private TextField firstNameField;
    /**
     * <code>surnameField</code>
     * A TextField for entering the last name during registration.
     */
    @FXML
    private TextField surnameField;
    /**
     * <code>addressField</code>
     * A TextField for entering the address during registration.
     */
    @FXML
    private TextField addressField;
    /**
     * <code>dismissErrorButton</code>
     * A Button used for dismissing error messages or notifications.
     */
    @FXML
    private Button dismissErrorButton;
    /**
     * <code>errorLabel</code>
     * A Label used for displaying error messages to the user.
     */
    @FXML
    private Label errorLabel;
    /**
     * <code>errorRectangle</code>
     * A Rectangle used for displaying an error indicator.
     */
    @FXML
    private Rectangle errorRectangle;
    /**
     * <code>username</code>
     * The username entered during the registration process.
     */
    private String username;
    /**
     * <code>password</code>
     * The password entered during the registration process.
     */
    private String password;
    /**
     * <code>registrationService</code>
     * The service responsible for handling registration operations.
     */
    private Registration_Service registrationService;

    /**
     * This method initializes the controller by setting up event handlers and initializing UI components.
     */
    public void initialize() {
        if(registrationService == null){
            registrationService =  new Registration_Service();
        }
        Font defaultFont = new Font(18.0);

        imageLeftArrow = new Image(getClass().getResource("/clientES/images/leftArrow.png").toExternalForm());
        if(imageView == null){
            imageView = new ImageView();
        }
        imageView.setImage(imageLeftArrow);
        imageView.setFitHeight(20);
        imageView.setFitWidth(20);

        backButton.setGraphic(imageView);
        backButton.setOnMouseEntered(event -> {
            backButton.setTooltip(new Tooltip("Torna indietro"));
        });
        backButton.setOnMouseExited(event -> {
            backButton.setTooltip(null);
        });

        subscribeButton.setOnMouseEntered(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                subscribeButton.setFont(new Font(19.0));
            }
        });
        subscribeButton.setOnMouseExited(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                subscribeButton.setFont(defaultFont);
            }
        });

        loginButton.setOnMouseEntered(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                loginButton.setFont(new Font(19.0));
            }
        });
        loginButton.setOnMouseExited(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                loginButton.setFont(defaultFont);
            }
        });
    }
    /**
     * This method sets the application instance for this controller.
     * @param application The ClientES instance representing the application.
     */
    public void setApplication(ClientES application) {
        this.application = application;
    }
    /**
     * This method handles the action event triggered when the back button is clicked.
     * It switches the application view to the home screen.
     *
     * @param event The action event triggered by clicking the back button.
     */
    @FXML
    protected void onBackButtonClick(ActionEvent event) {
        if(application != null) {
            application.switchToRegistration1();
        }
    }

    /**
     * This method performs the registration process by validating user information and attempting to register the user.
     * If successful, it displays a success message and provides an option to log in.
     * If unsuccessful, it displays an error message.
     *
     * @param event The ActionEvent triggered by clicking the subscribe button.
     * @throws SQLException     If a database access error occurs.
     * @throws NotBoundException If the registry could not be found or accessed.
     * @throws IOException      If an I/O error occurs.
     */
    @FXML
    protected void onSubscribeButtonClick(ActionEvent event) throws SQLException, NotBoundException, IOException {
        String fiscalCode = fiscalCodeField.getText();
        String email = emailField.getText();
        String firstName = firstNameField.getText();
        String lastName = surnameField.getText();
        String address = addressField.getText();

        String registerError = registrationService.validateUserInfo(fiscalCode, email, firstName, lastName, address);
        Paint rectangleColor = Paint.valueOf("#ff9393");
        Paint dismissButtonColor = Paint.valueOf("#cc0000");

        if(registerError == null){
            boolean isRegistrationOk = registrationService.registrazione(username, password, fiscalCode, email, firstName, lastName, address);
            if(isRegistrationOk){
                rectangleColor = Paint.valueOf("#80FF7C");
                dismissButtonColor = Paint.valueOf("#2ECC1C");
                errorLabel.setText("Registrazione avvenuta con successo! Effettua il login.");
                loginButton.setVisible(true);
                subscribeButton.setVisible(false);

                application.cleanRegistration1Field();

            } else {
                loginButton.setVisible(false);
                errorLabel.setText("C'è stato un errore durante la registrazione, riprova.");
            }
        } else {
            loginButton.setVisible(false);
            errorLabel.setText(registerError);
        }

        errorRectangle.setFill(rectangleColor);
        dismissErrorButton.setTextFill(dismissButtonColor);

        errorLabel.setVisible(true);
        dismissErrorButton.setVisible(true);
        errorRectangle.setVisible(true);
    }
    /**
     * This method handles the action event when the user clicks on the login button.
     * It switches the application view to the login screen.
     *
     * @param event The ActionEvent triggered by clicking the login button.
     * @throws NotBoundException If the registry could not be found or accessed.
     * @throws IOException      If an I/O error occurs.
     */
    @FXML
    protected void onLoginButtonClick(ActionEvent event) throws NotBoundException, IOException {
        if(application != null) {
            application.switchToLogin();
        }
    }
    /**
     * This method handles the action event when the user dismisses the error message.
     * It hides the error message, dismisses the error button, and hides the error rectangle.
     *
     * @param event The ActionEvent triggered by dismissing the error message.
     */
    @FXML
    protected void onDismissErrorButtonClick(ActionEvent event) {
        dismissErrorButton.setVisible(false);
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }
    /**
     * This method resets the initial configuration of the registration screen.
     * It hides the login button, shows the subscribe button, clears error messages,
     * sets the default colors for the error rectangle and dismiss error button, and hides them.
     */
    public void resetInitConfiguration(){
        loginButton.setVisible(false);
        subscribeButton.setVisible(true);

        errorRectangle.setFill(Paint.valueOf("#ff9393"));
        dismissErrorButton.setTextFill(Paint.valueOf("#cc0000"));

        dismissErrorButton.setVisible(false);
        errorLabel.setText("");
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }
    /**
     * This method retrieves the username associated with this registration process.
     *
     * @return The username.
     */
    public String getUsername() {
        return username;
    }
    /**
     * This method sets the username for this registration process.
     *
     * @param username The username to be set.
     */
    public void setUsername(String username) {
        this.username = username;
    }
    /**
     * This method retrieves the password associated with this registration process.
     *
     * @return The password.
     */
    public String getPassword() {
        return password;
    }
    /**
     * This method sets the password for this registration process.
     *
     * @param password The password to be set.
     */
    public void setPassword(String password) {
        this.password = password;
    }
}
