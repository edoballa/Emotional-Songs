package clientES.controller.logged;

import clientES.ClientES;
import clientES.services.UserInfo_Service;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;

import java.io.IOException;
import java.rmi.NotBoundException;
import java.sql.SQLException;
/**
 * <p>This class is responsible for managing the change password functionality in the logged user interface.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class ChangePasswordController {
    /**
     * <code>application</code>
     * An ClientES object that manages the navigation between different screens and provides functionality for user interactions.
     */
    @FXML private ClientES application;
    /**
     * <code>reservedAreaChoiceBox</code>
     * A ChoiceBox used for selecting options related to the user's reserved area.
     */
    @FXML private ChoiceBox<String> reservedAreaChoiceBox;
    /**
     * <code>backButton</code>
     * A Button used for navigating back to the previous screen or view..
     */
    @FXML private Button backButton;
    /**
     * <code>imageView</code>
     * An ImageView object used for displaying an image, such as an arrow icon indicating navigation direction.
     */
    @FXML private ImageView imageView;
    /**
     * An Image object representing the left arrow icon used for navigation.
     * <code>imageLeftArrow</code>
     */
    @FXML private Image imageLeftArrow;
    /**
     * A PasswordField used for entering the confirmed password during the password change process.
     * <code>confirmedPasswordField</code>
     */
    @FXML private PasswordField confirmedPasswordField;
    /**
     * A PasswordField used for entering the new password during the password change process.
     * <code>newPasswordField</code>
     */
    @FXML private PasswordField newPasswordField;
    /**
     * A PasswordField used for entering the old password during the password change process.
     * <code>oldPasswordField</code>
     */
    @FXML private PasswordField oldPasswordField;
    /**
     * <code>dismissErrorButton</code>
     * A Button used for dismissing error messages or notifications.
     */
    @FXML private Button dismissErrorButton;
    /**
     * <code>errorLabel</code>
     * A Label used for displaying error messages to the user.
     */
    @FXML private Label errorLabel;
    /**
     * A Rectangle object used for displaying an error indication.
     * <code>errorRectangle</code>
     */
    @FXML private Rectangle errorRectangle;
    /**
     * An instance of UserInfo_Service class used for managing user information and operations related to user accounts.
     * <code>userInfoService</code>
     */
    private UserInfo_Service userInfoService;
    /**
     * This method initializes the controller, setting up initial configurations and bindings.
     */
    public void initialize() {
        if(userInfoService == null){
            userInfoService = new UserInfo_Service();
        }

        resetInitConfiguration();

        imageLeftArrow = new Image(getClass().getResource("/clientES/images/leftArrow.png").toExternalForm());
        if(imageView == null){
            imageView = new ImageView();
        }
        imageView.setImage(imageLeftArrow);
        imageView.setFitHeight(20);
        imageView.setFitWidth(20);

        backButton.setGraphic(imageView);
        backButton.setOnMouseEntered(event -> {
            backButton.setTooltip(new Tooltip("Torna indietro"));
        });
        backButton.setOnMouseExited(event -> {
            backButton.setTooltip(null);
        });
    }
    /**
     * This method sets the ClientES application for this controller.
     *
     * @param application The ClientES object managing navigation and user interactions.
     */
    public void setApplication(ClientES application) {
        this.application = application;
    }
    /**
     * This method handles the action event triggered when the back button is clicked.
     * It switches the application view back to the home page for logged users.
     *
     * @param event The ActionEvent representing the button click event.
     */
    @FXML
    protected void onBackButtonClick(ActionEvent event) {
        if(application != null) {
            application.switchToHomeLogged();
        }
    }
    /**
     * This method handles the action event triggered when the change password button is clicked.
     * It performs the logic to change the user's password.
     *
     * @param event The ActionEvent representing the button click event.
     * @throws SQLException       If a SQL exception occurs.
     * @throws NotBoundException  If a remote exception occurs.
     * @throws IOException        If an IO exception occurs.
     */
    @FXML
    protected void changePassword(ActionEvent event) throws SQLException, NotBoundException, IOException {
        Paint rectangleColor = Paint.valueOf("#ff9393"); //red
        Paint dismissButtonColor = Paint.valueOf("#cc0000"); //red

        String newPassword = newPasswordField.getText();
        String oldPassword = oldPasswordField.getText();
        String confirmedPassword = confirmedPasswordField.getText();


        Long userId = application.getUser().getUserId();

        if (oldPassword == null || oldPassword.isEmpty() || confirmedPassword == null || confirmedPassword.isEmpty()
            || newPassword == null || newPassword.isEmpty()) {
            errorLabel.setText("Uno o più campi sono vuoti");
        } else if (!userInfoService.isNewPasswordValid(newPassword)) {
            errorLabel.setText("La nuova password non rispetta i requisiti minimi");
        } else if(!userInfoService.areNewPasswordsEquals(newPassword, confirmedPassword)) {
            errorLabel.setText("I campi 'NUOVA PASSWORD' e 'CONFERMA PASSWORD' non sono uguali");
        } else if (!userInfoService.isPasswordOldCorrect(userId, oldPassword)) {
            errorLabel.setText("La password attuale non è corretta");
        } else if (userInfoService.areNewAndOldPasswordsEquals(userId, newPassword)) {
            errorLabel.setText("La nuova password non può essere uguale a quella attuale");
        }  else {
            boolean isTheChangeWentOk = userInfoService.changePassword(userId, oldPassword, newPassword);
            if(isTheChangeWentOk){
                rectangleColor = Paint.valueOf("#80FF7C"); //green
                dismissButtonColor = Paint.valueOf("#2ECC1C"); //green
                errorLabel.setText("Aggiornamento dei dati avvenuto con successo!");
            } else {
                errorLabel.setText("C'è stato un errore durante l'aggiornamento, riprova.");
            }
        }

        errorRectangle.setFill(rectangleColor);
        dismissErrorButton.setTextFill(dismissButtonColor);

        errorLabel.setVisible(true);
        dismissErrorButton.setVisible(true);
        errorRectangle.setVisible(true);
    }
    /**
     * This method clears the selection of the choice box.
     */
    public void clearChoiceBoxSelection() {
        if (reservedAreaChoiceBox != null) {
            reservedAreaChoiceBox.getSelectionModel().clearSelection();
        }
    }
    /**
     * This method handles the action event triggered when an option is selected from the choice box.
     * It switches the application view based on the selected option.
     *
     * @param event The ActionEvent representing the option selection event.
     */
    @FXML
    protected void reservedAreaOptions(ActionEvent event) {
        String selectedOption = reservedAreaChoiceBox.getValue();
        clearChoiceBoxSelection();
        
        if(selectedOption == null){
            return;
        } else if(application != null && selectedOption.equals("Il mio profilo")){
            application.switchToUserProfile();
        } else if(application != null && selectedOption.equals("Modifica password")){
            application.switchToChangePassword();
        } else if(application != null && selectedOption.equals("Le mie playlist")){
            application.switchToUserPlaylist();
        } else if(application != null && selectedOption.equals("Le mie valutazioni")){
            application.switchToUserFeedback();
        } else if(application != null && selectedOption.equals("Logout")){
            application.logout();
        }
    }
    /**
     * This method handles the action event triggered when the dismiss error button is clicked.
     * It hides the error message.
     *
     * @param event The ActionEvent representing the button click event.
     */
    @FXML
    protected void onDismissErrorButtonClick(ActionEvent event) {
        dismissErrorButton.setVisible(false);
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }
    /**
     * This method resets the initial configuration of error messages and their display.
     */
    public void resetInitConfiguration(){
        errorRectangle.setFill(Paint.valueOf("#ff9393"));
        dismissErrorButton.setTextFill(Paint.valueOf("#cc0000"));

        dismissErrorButton.setVisible(false);
        errorLabel.setText("");
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }

}
