package clientES.services;

import commons.objects.User;
/**
 * <p>This class provides services related to user login functionality.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class Login_Service {
    /**
     * <code>clientHandler</code>
     * An instance of ClientHandler used for managing communication with the server.
     */
    private ClientHandler clientHandler;

    /**
     * Constructs a new Login_Service instance and initializes the ClientHandler for server communication.
     */
    public Login_Service(){
        try {
            clientHandler = ClientHandler.getInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * This method logs in a user with the provided username and password.
     *
     * @param username The username of the user.
     * @param password The password of the user.
     * @return The User object representing the logged-in user.
     * @throws RuntimeException If an exception occurs during the login process.
     */

    public User login (String username, String password){
        User userLogged = null;
        try {
            userLogged = clientHandler.login(username, password);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return userLogged;
    }

}
