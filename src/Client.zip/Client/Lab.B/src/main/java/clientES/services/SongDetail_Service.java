package clientES.services;

import commons.objects.EmotionFeedbackStatistics;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.List;

/**
 * <p>This class provides services related to song details, such as loading emotion feedback statistics for a song and adding a song to a playlist.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class SongDetail_Service {
    /**
     * <code>clientHandler</code>
     * An instance of ClientHandler used for communication with the server.
     */
    private ClientHandler clientHandler;

    /**
     * Constructs a new SongDetail_Service instance and initializes the client handler for server communication.
     */
    public SongDetail_Service(){
        try {
            clientHandler = ClientHandler.getInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * This method loads the emotion feedback statistics for a song based on its ID.
     *
     * @param songId The ID of the song.
     * @return A list of EmotionFeedbackStatistics objects representing the emotion feedback statistics for the song.
     * @throws SQLException    If a database access error occurs.
     * @throws RemoteException If an error occurs during remote method invocation.
     */

    public List<EmotionFeedbackStatistics> loadSongFeelingsBySongId(Long songId) throws SQLException, RemoteException {
        return clientHandler.loadFeelingsDetail(songId);
    }

    /**
     * This method adds a song to a playlist for a specific user.
     *
     * @param songId    The ID of the song to add.
     * @param playlist  The name of the playlist.
     * @param userId    The ID of the user.
     * @return true if the song is successfully added to the playlist, false otherwise.
     * @throws Exception If an error occurs during the process.
     */
    public boolean addSongInPlaylist(Long songId, String playlist, Long userId) throws Exception {
        String playlistListValue = playlist.split(" - ")[0];
        Long playlistId = Long.valueOf(playlistListValue);

        return clientHandler.addSongInPlaylist(songId, playlistId, userId);
    }
}
