package clientES.controller.logged;

import clientES.ClientES;
import clientES.services.UserInfo_Service;
import commons.objects.Emotion;
import commons.objects.Emotions;
import commons.objects.Song;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;

import java.io.IOException;
import java.net.URL;
import java.rmi.NotBoundException;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.function.UnaryOperator;
import java.util.regex.Pattern;

/**
 * <p>This class represents the controller for the feedback creation view. It implements the Initializable interface to initialize the view components.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */
public class FeedbackNewController implements Initializable {
    /**
     * <code>application</code>
     * A reference to the main application instance, responsible for managing navigation between screens and user interactions.
     */
    @FXML
    private ClientES application;
    /**
     * <code>reservedAreaChoiceBox</code>
     * A ChoiceBox used for selecting options related to the user's reserved area.
     */
    @FXML private ChoiceBox<String> reservedAreaChoiceBox;
    /**
     * <code>usernameLabel</code>
     * A Label used for displaying the username of the currently logged-in user.
     */
    @FXML private Label usernameLabel;
    /**
     * <code>backButton</code>
     * A Button used for navigating back to the previous screen or view..
     */
    @FXML private Button backButton;
     /**
     * <code>imageView</code>
     * An ImageView object used for displaying an image, such as an arrow icon indicating navigation direction.
     */
    @FXML private ImageView imageView;
    /**
     * <code>imageLeftArrow</code>
     * An Image object representing the left arrow icon used in the user interface.
     */
    @FXML private Image imageLeftArrow;
    /**
     * <code>songField</code>
     * A TextField used for displaying and entering information about the song related to the user feedback.
     */
    @FXML private TextField songField;
    /**
     * <code>scoreField</code>
     * A TextField used for displaying and entering the score of the user feedback.
     */
    @FXML private TextField scoreField;
    /**
     * <code>noteField</code>
     * A TextArea used for displaying and entering additional notes related to the user feedback.
     */
    @FXML private TextArea noteField;
    /**
     * <code>emotionListChoiceBox</code>
     * A ChoiceBox used for selecting the emotion associated with the user feedback.
     */
    @FXML private ChoiceBox<String> emotionListChoiceBox;

    /**
     * <code>dismissErrorButton</code>
     * A Button used for dismissing error messages or notifications.
     */
    @FXML private Button dismissErrorButton;
    /**
     * <code>errorLabel</code>
     * A Label used for displaying error messages to the user.
     */
    @FXML private Label errorLabel;
    /**
     * <code>errorRectangle</code>
     * A Rectangle used for displaying error messages or notifications in the user interface.
     */
    @FXML private Rectangle errorRectangle;
    /**
     * <code>previusPage</code>
     * A String variable representing the previous page or view before the current one.
     */
    private String previusPage;
    /**
     * <code>selectedSong</code>
     * A Song object representing the song selected for feedback creation.
     */
    private Song selectedSong;
    /**
     * <code>userInfoService</code>
     * A service class for managing user information and interactions.
     */
    private UserInfo_Service userInfoService;
    /**
     * Initializes the controller after its root element has been completely processed.
     * This method is called once all FXML elements have been loaded and their associated controllers initialized.
     *
     * @param location The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param rb The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL location, ResourceBundle rb) {
        if(userInfoService == null){
            userInfoService = new UserInfo_Service();
        }

        imageLeftArrow = new Image(getClass().getResource("/clientES/images/leftArrow.png").toExternalForm());
        imageView.setImage(imageLeftArrow);
        imageView.setFitHeight(20);
        imageView.setFitWidth(20);

        backButton.setGraphic(imageView);
        backButton.setOnMouseEntered(event -> {
            backButton.setTooltip(new Tooltip("Torna indietro"));
        });
        backButton.setOnMouseExited(event -> {
            backButton.setTooltip(null);
        });

        if(application != null && application.getUser() != null) {
            usernameLabel.setText(application.getUser().getUsername());
        }

        ObservableList<String> emotionList = FXCollections.observableArrayList();
        for(Emotion emotion : Emotions.getEmotionMap().values()){
            String eName = emotion.getEmotionId() + " - " + emotion.getName()
                    + "(" + emotion.getDescription() + ")";
            emotionList.add(eName);
        }
        emotionListChoiceBox.setItems(emotionList);

        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (newText.isEmpty()) {
                return change;
            }
            if (Pattern.matches("\\d*", newText)) {
                return change;
            }
            return null; // Rejected
        };

        // Applica il filtro al TextFormatter
        TextFormatter<String> textFormatter = new TextFormatter<>(filter);
        scoreField.setTextFormatter(textFormatter);

        resetMessageInitConfig();
    }
    /**
     * This method inserts the emotions related to a song into the database, including the user's evaluation and optional notes.
     *
     * @throws SQLException       if a database access error occurs.
     * @throws NotBoundException  if the service is not bound.
     * @throws IOException        if an I/O error occurs.
     */
    @FXML
    private void inserisciEmozioniBrano() throws SQLException, NotBoundException, IOException {
        resetMessageInitConfig();

        boolean infosAreCorrect = true;
        if (scoreField.getText() == null || scoreField.getText().isEmpty()
                || Integer.valueOf(scoreField.getText()) < 1 ||  Integer.valueOf(scoreField.getText()) > 5 ) {
            errorLabel.setText("La valutazione deve essere un valore compreso tra 1 e 5.");
            infosAreCorrect = false;
        } else if(emotionListChoiceBox.getValue() == null || emotionListChoiceBox.getValue().isEmpty()){
            errorLabel.setText("É necessario selezionare l'emozione provata.");
            infosAreCorrect = false;
        }

        if(!infosAreCorrect){
            errorLabel.setVisible(true);
            dismissErrorButton.setVisible(true);
            errorRectangle.setVisible(true);
            return;
        }

        Long userId = application.getUser().getUserId();
        Long emotionId = Long.valueOf(emotionListChoiceBox.getValue().split(" - ")[0]);
        Emotion emotion = Emotions.getEmotionMap().get(emotionId);
        int score = Integer.valueOf(scoreField.getText());
        String note = noteField.getText();
        if(noteField.getText().length() > 256){
            note = note.substring(0, 255);
        }

        boolean isAdded = userInfoService.inserisciEmozioniBrano(selectedSong, userId, emotion, score, note);
        if(isAdded) {
            errorRectangle.setFill(Paint.valueOf("#80FF7C"));
            dismissErrorButton.setTextFill(Paint.valueOf("#2ECC1C"));
            errorLabel.setText("Inserimento avvenuto con successo!");
        } else {
            errorLabel.setText("Qualcosa è andato storto, potrebbe essere che hai già inserito un feedback per questa canzone, controlla nell'apposita area e riprova.");
        }

        errorLabel.setVisible(true);
        dismissErrorButton.setVisible(true);
        errorRectangle.setVisible(true);

    }
    /**
     * This method handles the event when the back button is clicked, navigating the user to the previous page.
     *
     * @param event The ActionEvent representing the button click event.
     * @throws Exception If an exception occurs during the navigation process.
     */
    @FXML
    protected void onBackButtonClick(ActionEvent event) throws Exception {
        if(application != null) {
            application.visualizzaEmozioneBrano(selectedSong, previusPage);
        }
    }
    /**
     * This method sets the ClientES application instance for this controller.
     *
     * @param application The ClientES application instance.
     */
    public void setApplication(ClientES application) {
        this.application = application;
    }

    public void setUsernameLabelText(String text){
        if(usernameLabel == null){
            usernameLabel = new Label();
        }
        usernameLabel.setText(text);
    }
    /**
     * This method handles the action event when an option is selected from the reserved area choice box.
     * It switches to different screens based on the selected option.
     *
     * @param event The ActionEvent representing the selection event.
     */
    @FXML
    protected void reservedAreaOptions(ActionEvent event) {
        String selectedOption = reservedAreaChoiceBox.getValue();
        clearChoiceBoxSelection();

        if(selectedOption == null){
            return;
        } else if(application != null && selectedOption.equals("Il mio profilo")){
            application.switchToUserProfile();
        } else if(application != null && selectedOption.equals("Modifica password")){
            application.switchToChangePassword();
        } else if(application != null && selectedOption.equals("Le mie playlist")){
            application.switchToUserPlaylist();
        } else if(application != null && selectedOption.equals("Le mie valutazioni")){
            application.switchToUserFeedback();
        } else if(application != null && selectedOption.equals("Logout")){
            application.logout();
        }
    }
    /**
     * This method handles the action event when the dismiss error button is clicked.
     * It resets the error message configuration.
     *
     * @param event The ActionEvent representing the button click event.
     */
    @FXML
    protected void onDismissErrorButtonClick(ActionEvent event) {
        resetMessageInitConfig();
    }
    /**
     * This method resets the error message configuration to its initial state.
     */
    public void resetMessageInitConfig() {
        errorRectangle.setFill(Paint.valueOf("#ff9393"));
        dismissErrorButton.setTextFill(Paint.valueOf("#cc0000"));

        dismissErrorButton.setVisible(false);
        errorLabel.setText("");
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }
    /**
     * This method resets the field values of the song, emotion, and score.
     */
    public void resetFieldValue() {
        noteField.setText("");
        emotionListChoiceBox.setValue("");
        scoreField.setText("");
    }
    /**
     * This method clears the selection of the reserved area choice box.
     */
    public void clearChoiceBoxSelection() {
        if (reservedAreaChoiceBox != null) {
            reservedAreaChoiceBox.getSelectionModel().clearSelection();
        }
    }
    /**
     * Sets the selected song for which the user is providing feedback.
     *
     * @param selectedSong The Song object representing the selected song.
     */
    public void setSelectedSong(Song selectedSong) {
        this.selectedSong = selectedSong;
        songField.setText(selectedSong.getTitle() + "(" + selectedSong.getAuthor()  + ")");
        usernameLabel.setText(application.getUser().getUsername());
        resetFieldValue();
        resetMessageInitConfig();
    }
    /**
     * Sets the previous page from which the user navigated to the feedback form.
     *
     * @param previusPage The String representing the previous page.
     */
    public void setPreviusPage(String previusPage) {
        this.previusPage = previusPage;
    }
}
