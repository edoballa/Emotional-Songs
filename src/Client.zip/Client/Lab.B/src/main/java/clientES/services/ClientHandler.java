package clientES.services;

import commons.objects.*;
import serverES.rmi.ServerHandler;

import java.io.IOException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
/**
 * <p>This class provides methods for interacting with the server through RMI.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */
public class ClientHandler {
    /**
     * <code>server</code>
     * An instance of ServerHandler used for communication with the server.
     */
    private static ServerHandler server = null;
    /**
     * <code>clientHandler</code>
     * An instance of ClientHandler used for managing client-server communication.
     */
    private static ClientHandler clientHandler = null;

    /**
     * This method returns an instance of ClientHandler to manage client-server communication.
     *
     * @return An instance of ClientHandler.
     * @throws IOException       If an I/O error occurs.
     * @throws NotBoundException If the object with the specified name is not bound in the registry.
     * @throws SQLException      If a database access error occurs.
     */
    public static ClientHandler getInstance() throws IOException, NotBoundException, SQLException {
        if(clientHandler == null){
            clientHandler = new ClientHandler();
        }
        return clientHandler;
    }

    /**
     * This constructs a new ClientHandler instance and initializes the server connection.
     *
     * @throws IOException       If an I/O error occurs.
     * @throws NotBoundException If the object with the specified name is not bound in the registry.
     * @throws SQLException      If a database access error occurs.
     */
    private ClientHandler() throws IOException, NotBoundException, SQLException {
        if(server == null) {
            server = (ServerHandler) Naming.lookup("rmi://localhost:5099/ServerService");
            Map<Long, Emotion> emotionMap = server.loadEmotionMap();
            Emotions.setEmotionMap(emotionMap);
        }
    }

    /**
     * Logs in the user with the provided username and password.
     *
     * @param username The username of the user.
     * @param password The password of the user.
     * @return The User object representing the logged-in user.
     * @throws IOException  If an I/O error occurs.
     * @throws SQLException If a database access error occurs.
     */

    public User login(String username, String password) throws IOException, SQLException {
        return server.actionLogin(username, password);
    }
    /**
     * This method searches for songs based on the specified query and search type.
     *
     * @param q          The search query.
     * @param searchType The type of search (e.g., title, artist).
     * @return A list of Song objects matching the search criteria.
     * @throws RemoteException If a remote communication-related error occurs.
     * @throws SQLException    If a database access error occurs.
     */

    public List<Song> cercaBranoMusicale(String q, String searchType) throws RemoteException, SQLException {
        return server.cercaBranoMusicale(q, searchType);
    }

    /**
     * This method loads detailed emotion feedback statistics for a specific song.
     *
     * @param songId The ID of the song for which to load emotion feedback statistics.
     * @return A list of EmotionFeedbackStatistics objects representing the detailed emotion feedback statistics for the song.
     * @throws RemoteException If a remote communication-related error occurs.
     * @throws SQLException    If a database access error occurs.
     */

    public List<EmotionFeedbackStatistics> loadFeelingsDetail(Long songId) throws RemoteException, SQLException {
        return server.loadFeelingsDetail(songId);
    }

    /**
     * This method checks if a given username can be registered.
     *
     * @param username The username to check.
     * @return true if the username can be registered, false otherwise.
     * @throws IOException  If an I/O error occurs.
     * @throws SQLException If a database access error occurs.
     */

    public boolean canRegister(String username) throws IOException, SQLException{
        return server.canRegister(username);
    }

    /**
     * This method attempts to register a new user with the provided information.
     *
     * @param paramUser The user object containing registration information.
     * @return true if the registration is successful, false otherwise.
     * @throws IOException  If an I/O error occurs.
     * @throws SQLException If a database access error occurs.
     */

    public boolean registrazione(User paramUser) throws IOException, SQLException{
        return server.registrazione(paramUser);
    }

    /**
     * This method updates the user's information with the provided data.
     *
     * @param user       The user object to be updated.
     * @param address    The user's address.
     * @param firstName  The user's first name.
     * @param lastName   The user's last name.
     * @param fiscalCode The user's fiscal code.
     * @param email      The user's email address.
     * @return true if the update is successful, false otherwise.
     * @throws IOException  If an I/O error occurs.
     * @throws SQLException If a database access error occurs.
     */

    public boolean actionUpdateUser(User user, Address address, String firstName, String lastName, String fiscalCode, String email)
            throws IOException, SQLException{
        return server.actionUpdateUser(user, address, firstName, lastName, fiscalCode, email);
    }

    /**
     * This method loads the user information from the server based on the provided user ID.
     *
     * @param userId The ID of the user to load.
     * @return The User object containing the user information.
     * @throws IOException    If an I/O error occurs.
     * @throws SQLException   If a database access error occurs.
     */

    public User loadUser(Long userId) throws IOException, SQLException{
        return server.loadUser(userId);
    }

    /**
     * This method checks whether the provided password matches the password of the user with the given user ID.
     *
     * @param userId    The ID of the user whose password is to be checked.
     * @param password  The password to be checked.
     * @return True if the password matches, false otherwise.
     * @throws IOException            If an I/O error occurs.
     * @throws NotBoundException      If the server is not bound.
     * @throws SQLException           If a database access error occurs.
     */

    public boolean checkPassword(Long userId, String password) throws IOException, NotBoundException, SQLException {
        return server.checkPassword(userId, password);
    }

    /**
     * This method changes the password of the user with the specified user ID.
     *
     * @param userId       The ID of the user whose password is to be changed.
     * @param oldPassword The old password to be replaced.
     * @param newPassword The new password to be set.
     * @return True if the password is changed successfully, false otherwise.
     * @throws IOException            If an I/O error occurs.
     * @throws NotBoundException      If the server is not bound.
     * @throws SQLException           If a database access error occurs.
     */

    public boolean changePassword(Long userId, String oldPassword, String newPassword) throws IOException, NotBoundException, SQLException {
        return server.changePassword(userId, oldPassword, newPassword);
    }

    /**
     * This method loads the playlists associated with the specified user ID.
     *
     * @param userId The ID of the user whose playlists are to be loaded.
     * @return A list of playlists associated with the specified user ID.
     * @throws IOException        If an I/O error occurs.
     * @throws NotBoundException  If the server is not bound.
     * @throws SQLException       If a database access error occurs.
     */

    public List<Playlist> loadUserPlaylist(Long userId) throws IOException, NotBoundException, SQLException {
        return server.loadUserPlaylist(userId);
    }

    /**
     * This method loads the songs associated with the specified playlist ID.
     *
     * @param playlistId The ID of the playlist whose songs are to be loaded.
     * @return A list of songs associated with the specified playlist ID.
     * @throws IOException        If an I/O error occurs.
     * @throws NotBoundException  If the server is not bound.
     * @throws SQLException       If a database access error occurs.
     */

    public List<Song> loadPlaylistSongs(Long playlistId) throws IOException, NotBoundException, SQLException {
        return server.loadPlaylistSongs(playlistId);
    }

    /**
     * This method deletes all the songs associated with the specified playlist ID.
     *
     * @param playlistId The ID of the playlist from which songs are to be deleted.
     * @return True if the songs are successfully deleted, false otherwise.
     * @throws Exception If an error occurs while deleting the songs.
     */

    public boolean deletePlaylistSongs(Long playlistId) throws Exception{
        return server.deletePlaylistSongs(playlistId);
    }

    /**
     * This method removes a specific song from the specified playlist.
     *
     * @param playlistId The ID of the playlist from which the song is to be removed.
     * @param songId The ID of the song to be removed.
     * @return True if the song is successfully removed from the playlist, false otherwise.
     * @throws Exception If an error occurs while removing the song from the playlist.
     */

    public boolean removeSongFromPlaylistSongs(Long playlistId, Long songId) throws Exception{
        return server.removeSongFromPlaylistSongs(playlistId, songId);
    }

    /**
     * This method adds a new playlist with the given name and description for the specified user.
     *
     * @param name The name of the new playlist.
     * @param descr The description of the new playlist.
     * @param userId The ID of the user for whom the playlist is created.
     * @return True if the playlist is successfully added, false otherwise.
     * @throws Exception If an error occurs while adding the new playlist.
     */

    public boolean registraPlaylist(String name, String descr, Long userId) throws Exception{
        return server.registraPlaylist(name, descr, userId);
    }

    /**
     * This method adds a song to a playlist.
     *
     * @param songId The ID of the song to be added to the playlist.
     * @param playlistId The ID of the playlist to which the song will be added.
     * @param userId The ID of the user performing the action.
     * @return True if the song is successfully added to the playlist, false otherwise.
     * @throws Exception If an error occurs while adding the song to the playlist.
     */

    public boolean addSongInPlaylist(Long songId, Long playlistId, Long userId) throws Exception{
        return server.addSongInPlaylist(songId, playlistId, userId);
    }

    /**
     * This method loads user feedback for a specific user.
     *
     * @param userId The ID of the user for whom the feedback is being loaded.
     * @return A list of UserFeedback objects containing the feedback provided by the user.
     * @throws Exception If an error occurs while loading the user feedback.
     */

    public List<UserFeedback> loadUserFeedback(Long userId) throws Exception {
        return server.loadUserFeedback(userId);
    }

    /**
     * This method updates the user feedback with new information.
     *
     * @param userFeedback The UserFeedback object containing the updated feedback.
     * @return True if the update was successful, false otherwise.
     * @throws IOException        If an I/O error occurs.
     * @throws NotBoundException  If the server is not bound.
     * @throws SQLException       If an SQL exception occurs.
     */

    public boolean updateUserFeedback(UserFeedback userFeedback) throws IOException, NotBoundException, SQLException{
        return server.updateUserFeedback(userFeedback);
    }

    /**
     * This method adds new user feedback.
     *
     * @param userFeedback The UserFeedback object containing the feedback to be added.
     * @return True if the addition was successful, false otherwise.
     * @throws IOException        If an I/O error occurs.
     * @throws NotBoundException  If the server is not bound.
     * @throws SQLException       If an SQL exception occurs.
     */

    public boolean inserisciEmozioniBrano(UserFeedback userFeedback) throws IOException, NotBoundException, SQLException{
        return server.inserisciEmozioniBrano(userFeedback);
    }

    /**
     * This method deletes user feedback.
     *
     * @param userFeedback The UserFeedback object containing the feedback to be deleted.
     * @return True if the deletion was successful, false otherwise.
     * @throws IOException        If an I/O error occurs.
     * @throws NotBoundException  If the server is not bound.
     * @throws SQLException       If an SQL exception occurs.
     */

    public boolean deleteUserFeedback(UserFeedback userFeedback) throws IOException, NotBoundException, SQLException{
        return server.deleteUserFeedback(userFeedback);
    }

}
