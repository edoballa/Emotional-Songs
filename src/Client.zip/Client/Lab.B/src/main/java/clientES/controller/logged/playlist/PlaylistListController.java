package clientES.controller.logged.playlist;

import clientES.ClientES;
import clientES.services.Playlist_Service;
import clientES.services.UserInfo_Service;
import commons.objects.Playlist;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;

import java.net.URL;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

/**
 * <p>This class manages the playlist list view, allowing users to interact with playlists.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class PlaylistListController implements Initializable {
    /**
     * <code>application</code>
     * An ClientES object that manages the navigation between different screens and provides functionality for user interactions.
     */
    @FXML
    private ClientES application;
    /**
     * <code>reservedAreaChoiceBox</code>
     * A ChoiceBox used for selecting options related to the user's reserved area.
     */
    @FXML
    private ChoiceBox<String> reservedAreaChoiceBox;
    /**
     * <code>backButton</code>
     * A Button used for navigating back to the previous screen or view.
     */
    @FXML
    private Button backButton;
    /**
     * <code>usernameLabel</code>
     * A Label used for displaying the username of the currently logged-in user.
     */
    @FXML
    private Label usernameLabel;
    /**
     * <code>nameField</code>
     * A TextField component used for inputting the name of a playlist.
     */
    @FXML
    protected TextField nameField;
    /**
     * <code>descrField</code>
     * A TextField component used for inputting the description of a playlist.
     */
    @FXML
    protected TextField descrField;
    /**
     * <code>imageView</code>
     * An ImageView used for displaying an image, such as an arrow icon indicating navigation direction.
     */
    @FXML
    private ImageView imageView;
    /**
     * <code>imageLeftArrow</code>
     * An Image object representing a left arrow icon.
     */
    private Image imageLeftArrow;
    /**
     * <code>playlistTable</code>
     * A TableView used for displaying the list of playlists.
     */
    public TableView<Playlist> playlistTable;
    /**
     * <code>dismissErrorButton</code>
     * A TableView used for displaying the list of playlists.
     */
    @FXML
    private Button dismissErrorButton;
    /**
     * <code>errorLabel</code>
     * A Label used for displaying error messages to the user.
     */
    @FXML
    private Label errorLabel;
    /**
     * <code>errorRectangle</code>
     * A Rectangle used for visually indicating errors.
     */
    @FXML
    private Rectangle errorRectangle;
    /**
     * <code>userInfoService</code>
     * A Service responsible for managing user information.
     */
    private UserInfo_Service userInfoService;
    /**
     * <code>playlistService</code>
     * A Service responsible for managing playlists.
     */
    private Playlist_Service playlistService;

    /**
     * This method initializes the controller.
     * It configures the user interface, sets initial values for GUI components, and sets up necessary events.
     * @param location The location relative to the root object of the FXML file used to initialize the controller.
     * @param rb The ResourceBundle that can be used to localize the FXML file used to initialize the controller.
     */
    @Override
    public void initialize(URL location, ResourceBundle rb) {
        if(playlistService == null){
            playlistService =  new Playlist_Service();
        }

        if(userInfoService == null){
            userInfoService =  new UserInfo_Service();
        }

        imageLeftArrow = new Image(getClass().getResource("/clientES/images/leftArrow.png").toExternalForm());
        imageView.setImage(imageLeftArrow);
        imageView.setFitHeight(20);
        imageView.setFitWidth(20);

        backButton.setGraphic(imageView);
        backButton.setOnMouseEntered(event -> {
            backButton.setTooltip(new Tooltip("Torna indietro"));
        });
        backButton.setOnMouseExited(event -> {
            backButton.setTooltip(null);
        });

        if(application != null && application.getUser() != null) {
            if(usernameLabel == null){
                usernameLabel = new Label();
            }

            usernameLabel.setText(application.getUser().getUsername());
        }

        configureTableColumns();
        refreshTableData();
        configureTableEvents();
    }

    /**
     * This method configures the columns for the TableView displaying the songs in the playlist.
     */
    private void configureTableColumns() {
        TableColumn<Playlist, String> nameCol = new TableColumn<>("NOME");
        TableColumn<Playlist, String> descriptionCol = new TableColumn<>("DESCRIZIONE");
        TableColumn<Playlist, String> numOfSongsCol = new TableColumn<>("NUMERO CANZONI");
        TableColumn<Playlist, String> playlistDurationCol = new TableColumn<>("DURATA PLAYLIST");
        TableColumn<Playlist, String> playlistAddDateCol = new TableColumn<>("DATA DI AGGIUNTA");

        nameCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        descriptionCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDescription()));
        numOfSongsCol.setCellValueFactory(cellData -> new SimpleStringProperty("" + cellData.getValue().getNumberOfSongs()));
        playlistDurationCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getPlaylistDuration()));
        playlistAddDateCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getAddDateStr()));

        nameCol.setPrefWidth(200);
        descriptionCol.setPrefWidth(200);
        numOfSongsCol.setPrefWidth(125);
        playlistDurationCol.setPrefWidth(150);
        playlistAddDateCol.setPrefWidth(150);

        playlistTable.getColumns().addAll(nameCol, descriptionCol, numOfSongsCol, playlistDurationCol, playlistAddDateCol);
    }

    /**
     * This method configures the events for the TableView.
     */
    private void configureTableEvents() {
        playlistTable.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2 && playlistTable.getSelectionModel().getSelectedItem() != null) {
                try {
                    handleTableDoubleClick(playlistTable.getSelectionModel().getSelectedItem());
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    /**
     * Handles the double-click event on a playlist in the table, allowing users to perform actions when double-clicking on a playlist.
     *
     * @param selectedPlaylist The playlist that was double-clicked in the table.
     * @throws SQLException    If an SQL exception occurs.
     * @throws RemoteException If a remote exception occurs.
     */
    private void handleTableDoubleClick(Playlist selectedPlaylist) throws SQLException, RemoteException {
        if (application != null) {
            application.switchToUserPlaylistDetails(selectedPlaylist);
        }
    }

    /**
     * Refreshes the data displayed in the playlist table, updating it with the latest user playlists.
     */
    public void refreshTableData() {
        List<Playlist> userPlaylist = new ArrayList<>();
        if(application != null && application.getUser() != null) {
            try {
                userInfoService.loadUserPlaylist(application.getUser());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

            userPlaylist = application.getUser().getPlaylists();
        }

        ObservableList<Playlist> resultsData = FXCollections.observableArrayList(userPlaylist);
        playlistTable.setItems(resultsData);
    }

    /**
     * Handles the selection of options in the reserved area ChoiceBox, triggering corresponding actions based on the selected option.
     *
     * @param event The ActionEvent representing the selection of an option.
     */
    @FXML
    protected void reservedAreaOptions(ActionEvent event) {
        String selectedOption = reservedAreaChoiceBox.getValue();
        clearChoiceBoxSelection();
        
        if(selectedOption == null){
            return;
        } else if(application != null && selectedOption.equals("Il mio profilo")){
            application.switchToUserProfile();
        } else if(application != null && selectedOption.equals("Modifica password")){
            application.switchToChangePassword();
        } else if(application != null && selectedOption.equals("Le mie playlist")){
            application.switchToUserPlaylist();
        } else if(application != null && selectedOption.equals("Le mie valutazioni")){
            application.switchToUserFeedback();
        } else if(application != null && selectedOption.equals("Logout")){
            application.logout();
        }
    }

    /**
     * Clears the current selection in the reserved area ChoiceBox.
     */
    public void clearChoiceBoxSelection() {
        if (reservedAreaChoiceBox != null) {
            reservedAreaChoiceBox.getSelectionModel().clearSelection();
        }
    }

    /**
     * Sets the ClientES object for managing user interactions and screen navigation.
     *
     * @param application The ClientES object to be set.
     */
    public void setApplication(ClientES application) {
        this.application = application;
    }

    /**
     * This method handles the action event when the back button is clicked.
     * @param event The action event triggered by clicking the back button.
     */
    @FXML
    protected void onBackButtonClick(ActionEvent event) {
        nameField.clear();
        descrField.clear();

        if(application != null) {
            application.switchToHomeLogged();
        }
    }

    /**
     * This method sets the text for the username label.
     * @param text The text to be set for the username label.
     */
    public void setUsernameLabelText(String text){
        if(usernameLabel == null){
            usernameLabel = new Label();
        }
        usernameLabel.setText(text);
    }

    /**
     * This method handles the action event when the dismiss error button is clicked.
     * @param event The action event triggered by clicking the dismiss error button.
     */
    @FXML
    protected void onDismissErrorButtonClick(ActionEvent event) {
        errorRectangle.setFill(Paint.valueOf("#ff9393"));
        dismissErrorButton.setTextFill(Paint.valueOf("#cc0000"));

        dismissErrorButton.setVisible(false);
        errorLabel.setText("");
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }

    /**
     * Handles the action event when the "Add New Playlist" button is clicked.
     * @param event The action event triggered by clicking the "Add New Playlist" button.
     */
    @FXML
    protected void registraPlaylist(ActionEvent event) {
        String namePlaylist = nameField.getText();
        String descrPlaylist = descrField.getText();

        if(namePlaylist == null || namePlaylist.isEmpty()){
            errorLabel.setText("Compilare il campo nome, il campo descrizione è facolativo.");
        } else {
            boolean isAdded = false;
            try {
                isAdded = playlistService.registraPlaylist(namePlaylist, descrPlaylist, application.getUser().getUserId());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

            if (isAdded) {
                errorRectangle.setFill(Paint.valueOf("#80FF7C"));
                dismissErrorButton.setTextFill(Paint.valueOf("#2ECC1C"));
                errorLabel.setText("Aggiunta avvenuta con successo!");

                refreshTableData();
            } else {
                errorLabel.setText("Qualcosa è andato storto");
            }
        }

        dismissErrorButton.setVisible(true);
        errorLabel.setVisible(true);
        errorRectangle.setVisible(true);
    }
}
