package clientES.services;

import commons.objects.Playlist;
import commons.objects.Song;

import java.util.List;
/**
 * <p>This class provides services related to playlists.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */
public class Playlist_Service {
    /**
     * <code>clientHandler</code>
     * An instance of ClientHandler used for handling client-server communication and performing operations related to playlists.
     */
    private ClientHandler clientHandler;

    /**
     * Constructs a new Playlist_Service instance and initializes the client handler for communication with the server.
     */
    public Playlist_Service(){
        try {
            clientHandler = ClientHandler.getInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * This method loads the songs associated with the given playlist from the server.
     *
     * @param playlist The playlist for which to load the songs.
     * @throws Exception If an error occurs while loading the playlist songs.
     */

    public void loadPlaylistSongs(Playlist playlist) throws Exception{
        List<Song> songs = clientHandler.loadPlaylistSongs(playlist.getPlaylistId());
        playlist.setSongs(songs);
    }

    /**
     * This method deletes all songs from the specified playlist.
     *
     * @param playlistId The ID of the playlist from which to delete songs.
     * @return true if the songs are successfully deleted, false otherwise.
     * @throws Exception If an error occurs while deleting the playlist songs.
     */

    public boolean deletePlaylistSongs(Long playlistId) throws Exception{
        return clientHandler.deletePlaylistSongs(playlistId);
    }

    /**
     * This method removes a specific song from the specified playlist.
     *
     * @param playlistId The ID of the playlist from which to remove the song.
     * @param songId     The ID of the song to remove from the playlist.
     * @return true if the song is successfully removed from the playlist, false otherwise.
     * @throws Exception If an error occurs while removing the song from the playlist.
     */

    public boolean removeSongFromPlaylistSongs(Long playlistId, Long songId) throws Exception{
        return clientHandler.removeSongFromPlaylistSongs(playlistId, songId);
    }

    /**
     * This method registers a new playlist with the given name, description, and user ID.
     *
     * @param name     The name of the playlist to register.
     * @param descr    The description of the playlist.
     * @param userId   The ID of the user who owns the playlist.
     * @return true if the playlist is successfully registered, false otherwise.
     * @throws Exception If an error occurs while registering the playlist.
     */
    public boolean registraPlaylist(String name, String descr, Long userId) throws Exception{
        return clientHandler.registraPlaylist(name, descr, userId);
    }
}
