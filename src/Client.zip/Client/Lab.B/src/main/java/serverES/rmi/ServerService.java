package serverES.rmi;

import commons.objects.*;
import serverES.services.*;

import java.io.IOException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.*;
import java.util.List;
import java.util.Map;
/**
 * <p>This class represents the implementation of the remote interface {@link ServerHandler}</p>*
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */
public class ServerService extends UnicastRemoteObject implements ServerHandler {
    /**
     * <code>authenticator</code>
     * The Authenticator instance used for user authentication.
     */
    private Authenticator authenticator;
    /**
     * <code>registrationService</code>
     * The RegistrationEngine_Service instance used for user registration operations.
     */
    private RegistrationEngine_Service registrationService;
    /**
     * <code>searchEngineService</code>
     * The SearchEngine_Service instance used for searching songs.
     */

    private SearchEngine_Service searchEngineService;
    /**
     * <code>feelingsEngineService</code>
     * The FeelingsEngine_Service instance used for managing emotion feedback.
     */
    private FeelingsEngine_Service feelingsEngineService;
    /**
     * <code>userInfoEngineService</code>
     * The UserInfoEngine_Service instance used for managing user information.
     */
    private UserInfoEngine_Service userInfoEngineService;
    /**
     * <code>playlistService</code>
     * The PlaylistEngine_Service instance used for managing playlists.
     */
    private PlaylistEngine_Service playlistService;

    /**
     * Constructs a new ServerService object and initializes the various service instances used by the server.
     *
     * @throws RemoteException if there is an issue with the remote operation.
     */
    public ServerService() throws RemoteException {
        super();
        authenticator = new Authenticator();
        registrationService = new RegistrationEngine_Service();
        searchEngineService = new SearchEngine_Service();
        feelingsEngineService = new FeelingsEngine_Service();
        userInfoEngineService = new UserInfoEngine_Service();
        playlistService = new PlaylistEngine_Service();
    }

    /**
     * This method handles the user login action.
     *
     * @param username The username of the user trying to login.
     * @param password The password of the user trying to login.
     * @return The User object representing the logged-in user, or null if the login attempt fails.
     * @throws RemoteException If a remote communication error occurs.
     * @throws IOException     If an I/O error occurs.
     * @throws SQLException    If a database access error occurs.
     */
    public User actionLogin(String username, String password) throws RemoteException, IOException, SQLException {
        Boolean canLogin = authenticator.canLogin(username, password);
        if(canLogin){
            return userInfoEngineService.loadUserByUsername(username);
        } else {
            return null;
        }
    }

    /**
     * This method searches for music tracks based on the specified query and search type.
     *
     * @param q          The query string used for searching.
     * @param searchType The type of search to be performed (e.g., by title, artist, etc.).
     * @return A list of Song objects matching the search criteria.
     * @throws RemoteException If a remote communication error occurs.
     * @throws SQLException    If a database access error occurs.
     */
    @Override
    public List<Song> cercaBranoMusicale(String q, String searchType) throws RemoteException, SQLException {
        return searchEngineService.cercaBranoMusicale(q, searchType);
    }
    /**
     * This method loads the detailed emotion feedback statistics for a given song.
     *
     * @param songId The ID of the song.
     * @return A list of EmotionFeedbackStatistics objects representing the detailed emotion feedback statistics.
     * @throws RemoteException If a remote communication error occurs.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public List<EmotionFeedbackStatistics> loadFeelingsDetail(Long songId) throws RemoteException, SQLException {
        return feelingsEngineService.getFeelingsBySongId(songId);
    }

    /**
     * This method registers a new user.
     *
     * @param paramUser The User object representing the user to be registered.
     * @return true if the registration is successful, false otherwise.
     * @throws RemoteException If a remote communication error occurs.
     * @throws IOException If an I/O error occurs.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public boolean registrazione(User paramUser) throws SQLException {
        return registrationService.registrazione(paramUser);
    }
    /**
     * This method checks if a username is available for registration.
     *
     * @param username The username to be checked.
     * @return true if the username is available for registration, false otherwise.
     * @throws RemoteException If a remote communication error occurs.
     * @throws IOException If an I/O error occurs.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public boolean canRegister(String username) throws RemoteException, IOException, SQLException {
        return registrationService.canRegister(username);
    }
    /**
     * This method updates the user information.
     *
     * @param user The User object representing the user to be updated.
     * @param address The Address object representing the user's address.
     * @param firstName The updated first name of the user.
     * @param lastName The updated last name of the user.
     * @param fiscalCode The updated fiscal code of the user.
     * @param email The updated email address of the user.
     * @return true if the user information is successfully updated, false otherwise.
     * @throws RemoteException If a remote communication error occurs.
     * @throws IOException If an I/O error occurs.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public boolean actionUpdateUser(User user, Address address, String firstName, String lastName, String fiscalCode, String email)
            throws RemoteException, IOException, SQLException {
        return userInfoEngineService.updateUser(user, address, firstName, lastName, fiscalCode, email);
    }
    /**
     * This method loads the emotion map.
     *
     * @return A map containing emotion IDs mapped to Emotion objects.
     * @throws RemoteException If a remote communication error occurs.
     * @throws IOException If an I/O error occurs.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public Map<Long, Emotion> loadEmotionMap() throws RemoteException, IOException, SQLException {
        return feelingsEngineService.loadEmotionMap();
    }
    /**
     * This method loads the user with the specified ID.
     *
     * @param userId The ID of the user to load.
     * @return The User object representing the loaded user.
     * @throws RemoteException If a remote communication error occurs.
     * @throws IOException If an I/O error occurs.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public User loadUser(Long userId) throws RemoteException, IOException, SQLException {
        return userInfoEngineService.loadUserByUserId(userId);
    }
    /**
     * This method checks if the provided password matches the user's password.
     *
     * @param userId The ID of the user whose password is to be checked.
     * @param password The password to be checked.
     * @return true if the password matches, false otherwise.
     * @throws IOException If an I/O error occurs.
     * @throws NotBoundException If a remote object is not bound.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public boolean checkPassword(Long userId, String password) throws IOException, NotBoundException, SQLException {
        return userInfoEngineService.checkPassword(userId, password);
    }
    /**
     * This method changes the user's password.
     *
     * @param userId The ID of the user whose password is to be changed.
     * @param oldPassword The old password.
     * @param newPassword The new password.
     * @return true if the password is successfully changed, false otherwise.
     * @throws IOException If an I/O error occurs.
     * @throws NotBoundException If a remote object is not bound.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public boolean changePassword(Long userId, String oldPassword, String newPassword) throws IOException, NotBoundException, SQLException {
        return userInfoEngineService.changePassword(userId, oldPassword, newPassword);
    }
    /**
     * This method loads the playlists of a specific user.
     *
     * @param userId The ID of the user whose playlists are to be loaded.
     * @return A list of Playlist objects representing the user's playlists.
     * @throws IOException If an I/O error occurs.
     * @throws NotBoundException If a remote object is not bound.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public List<Playlist> loadUserPlaylist(Long userId) throws IOException, NotBoundException, SQLException {
        return userInfoEngineService.loadUserPlaylist(userId);
    }
    /**
     * This method loads the songs of a specific playlist.
     *
     * @param playlistId The ID of the playlist whose songs are to be loaded.
     * @return A list of Song objects representing the songs in the playlist.
     * @throws IOException If an I/O error occurs.
     * @throws NotBoundException If a remote object is not bound.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public List<Song> loadPlaylistSongs(Long playlistId) throws IOException, NotBoundException, SQLException {
        return playlistService.loadPlaylistSongs(playlistId);
    }
    /**
     * This method deletes all songs from a specific playlist.
     *
     * @param playlistId The ID of the playlist from which songs are to be deleted.
     * @return true if the songs are successfully deleted, false otherwise.
     * @throws IOException If an I/O error occurs.
     * @throws NotBoundException If a remote object is not bound.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public boolean deletePlaylistSongs(Long playlistId) throws IOException, NotBoundException, SQLException{
        return playlistService.deletePlaylistSongs(playlistId);
    }
    /**
     * This method removes a specific song from a playlist.
     *
     * @param playlistId The ID of the playlist from which the song is to be removed.
     * @param songId The ID of the song to be removed.
     * @return true if the song is successfully removed from the playlist, false otherwise.
     * @throws IOException If an I/O error occurs.
     * @throws NotBoundException If a remote object is not bound.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public boolean removeSongFromPlaylistSongs(Long playlistId, Long songId) throws IOException, NotBoundException, SQLException {
        return playlistService.removeSongFromPlaylistSongs(playlistId, songId);
    }
    /**
     * This method registers a new playlist for a user.
     *
     * @param name The name of the playlist to be registered.
     * @param descr The description of the playlist.
     * @param userId The ID of the user for whom the playlist is registered.
     * @return true if the playlist is successfully registered, false otherwise.
     * @throws IOException If an I/O error occurs.
     * @throws NotBoundException If a remote object is not bound.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public boolean registraPlaylist(String name, String descr, Long userId) throws IOException, NotBoundException, SQLException{
        return playlistService.addNewPlaylist(name, descr, userId);
    }
    /**
     * This method adds a song to a playlist.
     *
     * @param songId The ID of the song to be added to the playlist.
     * @param playlistId The ID of the playlist to which the song is added.
     * @param userId The ID of the user performing the action.
     * @return true if the song is successfully added to the playlist, false otherwise.
     * @throws IOException If an I/O error occurs.
     * @throws NotBoundException If a remote object is not bound.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public boolean addSongInPlaylist(Long songId, Long playlistId, Long userId) throws IOException, NotBoundException, SQLException {
        return playlistService.addSongInPlaylist(songId, playlistId, userId);
    }
    /**
     * This method loads the feedback provided by a specific user.
     *
     * @param userId The ID of the user whose feedback is to be loaded.
     * @return A list of UserFeedback objects representing the feedback provided by the user.
     * @throws IOException If an I/O error occurs.
     * @throws NotBoundException If a remote object is not bound.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public List<UserFeedback> loadUserFeedback(Long userId) throws IOException, NotBoundException, SQLException{
        return userInfoEngineService.loadUserFeedback(userId);
    }
    /**
     * This method updates the feedback provided by a user.
     *
     * @param userFeedback The UserFeedback object containing the updated feedback.
     * @return true if the feedback is successfully updated, false otherwise.
     * @throws IOException If an I/O error occurs.
     * @throws NotBoundException If a remote object is not bound.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public boolean updateUserFeedback(UserFeedback userFeedback) throws IOException, NotBoundException, SQLException{
        return feelingsEngineService.updateUserFeedback(userFeedback);
    }
    /**
     * This method inserts emotions for a song feedback into the database.
     *
     * @param userFeedback The UserFeedback object containing the emotions to be inserted.
     * @return true if the emotions are successfully inserted, false otherwise.
     * @throws IOException If an I/O error occurs.
     * @throws NotBoundException If a remote object is not bound.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public boolean inserisciEmozioniBrano(UserFeedback userFeedback) throws IOException, NotBoundException, SQLException{
        return feelingsEngineService.inserisciEmozioniBrano(userFeedback);
    }
    /**
     * This method deletes the feedback provided by a user.
     *
     * @param userFeedback The UserFeedback object containing the feedback to be deleted.
     * @return true if the feedback is successfully deleted, false otherwise.
     * @throws IOException If an I/O error occurs.
     * @throws NotBoundException If a remote object is not bound.
     * @throws SQLException If a database access error occurs.
     */
    @Override
    public boolean deleteUserFeedback(UserFeedback userFeedback) throws IOException, NotBoundException, SQLException{
        return feelingsEngineService.deleteUserFeedback(userFeedback);
    }

}


