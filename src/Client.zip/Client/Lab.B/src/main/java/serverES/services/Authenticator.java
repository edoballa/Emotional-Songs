package serverES.services;

import serverES.objects.dbconnection.DbConnection;
import serverES.rmi.ServerHandler;

import java.sql.*;
/**
 * <p>This class provides methods for authenticating users.</p>*
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class Authenticator {
    /**
     * <code>SELECT_FIND_USER_QUERY </code>
     * SQL query to check the existence of a user based on the provided username and password.
     */
    private static final String SELECT_FIND_USER_QUERY = " select count(username) as user_exists " +
            " from emotional_songs.utenti_registrati where username = ? and password = md5(?) " +
            " group by username ";

    /**
     * Default constructor for the Authenticator class.
     */
    public Authenticator(){

    }
    /**
     * This method checks if a user can log in with the provided username and password.
     *
     * @param username The username of the user trying to log in.
     * @param password The password of the user trying to log in.
     * @return True if the user can log in, false otherwise.
     * @throws SQLException If a database access error occurs.
     */
    public boolean canLogin(String username, String password) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(SELECT_FIND_USER_QUERY);
        pstm.setString(1, username);
        pstm.setString(2, password);
        ResultSet rs = pstm.executeQuery();

        int userExist = 0;
        if(rs.next()){
            userExist = rs.getInt("user_exists");
        }

        pstm.close();
        connection.close();

        if(userExist > 0){
            return true;
        } else {
            return false;
        }
    }

}
