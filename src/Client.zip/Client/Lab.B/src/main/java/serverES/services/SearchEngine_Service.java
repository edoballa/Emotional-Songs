package serverES.services;

import commons.objects.Song;
import serverES.objects.dbconnection.DbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>This class provides functionalities for searching musical tracks in the database.</p>*
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */
public class SearchEngine_Service {

    /**
     * Default constructor for the SearchEngine_Service class.
     */
    public SearchEngine_Service(){

    }
    /**
     * This method searches for musical tracks in the database based on the provided query and search type.
     *
     * @param q          The search query, which can be a title, author, year, or a combination thereof.
     * @param searchType The type of search to perform (e.g., "Titolo", "Autore", "Anno", etc.).
     * @return A list of Song objects matching the search criteria.
     * @throws SQLException If an SQL exception occurs while executing the query.
     */
    public List<Song> cercaBranoMusicale(String q, String searchType) throws SQLException {
        String whereClause = defineWhereClauseForSearch(searchType);
        String searchQuery = "select * from emotional_songs.song s " + whereClause + " order by s.title asc, s.author asc";

        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(searchQuery);

        String[] paramQuery = q.split(",");
        for(int i = 0; i < paramQuery.length; i++) {
            pstm.setString(i + 1, paramQuery[i]);
        }

        ResultSet rs = pstm.executeQuery();

        List<Song> searchResult = new ArrayList<>();
        while(rs.next()){
            Song result = fillSong(rs);
            searchResult.add(result);
        }

        pstm.close();
        connection.close();

        return searchResult;
    }
    /**
     * This method fills a Song object with data retrieved from the ResultSet.
     *
     * @param rs The ResultSet containing song data.
     * @return A Song object populated with data from the ResultSet.
     * @throws SQLException If a SQL exception occurs while retrieving data from the ResultSet.
     */
    private Song fillSong(ResultSet rs) throws SQLException {
        Song s = new Song();
        s.setSongId(rs.getLong("song_id"));
        s.setTitle(rs.getString("title"));
        s.setAuthor(rs.getString("author"));
        s.setAlbum(rs.getString("album"));
        s.setYear(rs.getString("year"));
        s.setDuration(rs.getDouble("duration"));

        return s;
    }
    /**
     * This method defines the WHERE clause for the search query based on the search type.
     *
     * @param searchType The type of search to perform.
     * @return The WHERE clause string for the search query.
     */
    private String defineWhereClauseForSearch(String searchType){
        String whereClause = " where ";

        if(searchType.equals("Titolo")){
            whereClause += " title ilike '%'|| ? ||'%' ";
        } else if(searchType.equals("Autore")){
            whereClause += " author ilike '%'|| ? ||'%' ";
        } else if(searchType.equals("Anno")){
            whereClause += " year ilike '%'|| trim( ? ) ||'%' ";
        } else if(searchType.equals("Titolo, Autore")){
            whereClause += " title ilike '%'|| ? ||'%' and author ilike '%'|| ? ||'%' ";
        } else if(searchType.equals("Titolo, Anno")){
            whereClause += " title ilike '%'|| ? ||'%' and year ilike '%'|| trim( ? ) ||'%' ";
        } else if(searchType.equals("Autore, Anno")){
            whereClause += " author ilike '%'|| ? ||'%' and year ilike '%'|| trim( ? ) ||'%' ";
        } else if(searchType.equals("Titolo, Autore, Anno")){
            whereClause += " title ilike '%'|| ? ||'%' and author ilike '%'|| ? ||'%' and year ilike '%'|| trim( ? ) ||'%' ";
        }

        return whereClause;
    }

}
