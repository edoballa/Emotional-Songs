package serverES.services;

import commons.objects.Emotions;
import commons.objects.*;
import serverES.objects.dbconnection.DbConnection;

import java.io.IOException;
import java.rmi.NotBoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 * <p>This class provides methods related to user information management, such as updating user details,loading user information, changing passwords, and retrieving user playlists and feedback.</p>*
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class UserInfoEngine_Service {
    /**
     * <code>SELECT_USER_PLAYLIST_QUERY</code>
     * SQL query to retrieve user playlists along with the number of songs and total duration for each playlist.
     */
    private static final String SELECT_USER_PLAYLIST_QUERY = " select p.playlist_id, p.name, p.description, p.add_date, " +
            "   coalesce(count(s.song_id), 0) as num_of_songs, " +
            "   coalesce(sum(s.duration), 0) as playlist_duration " +
            " from emotional_songs.playlist p  " +
            "   left join emotional_songs.playlist_song ps on p.playlist_id = ps.playlist_id " +
            "   left join emotional_songs.song s on ps.song_id = s.song_id  " +
            " where p.user_id = ? " +
            " group by p.playlist_id, p.name, p.description, p.add_date ";
    /**
     * <code>CHECK_PASSWORD_QUERY</code>
     * SQL query to check if the provided password matches the password stored in the database for a specific user.
     */
    private static final String CHECK_PASSWORD_QUERY = " select (md5( ? ) = password)::boolean as are_passwords_equals " +
            " from emotional_songs.utenti_registrati where user_id = ? ";
    /**
     * <code>UPDATE_USER_PASSWORD_QUERY</code>
     * SQL query to update the password for a specific user in the database.
     */

    private static final String UPDATE_USER_PASSWORD_QUERY = " UPDATE emotional_songs.utenti_registrati "
            + " SET password = md5( ? ) "
            + " WHERE user_id = ? and password = md5( ? ) ";
    /**
     * <code>SELECT_LOAD_USER_BY_USER_ID_QUERY</code>
     * SQL query to load user information from the database based on the user ID.
     */

    private static final String SELECT_LOAD_USER_BY_USER_ID_QUERY = "select * from emotional_songs.utenti_registrati where user_id = ?";
    /**
     * <code>UPDATE_USER_INFO_QUERY</code>
     * SQL query to update user information in the database.
     */

    private static final String UPDATE_USER_INFO_QUERY = " UPDATE emotional_songs.utenti_registrati "
            + " SET email = ?, name = ?, last_name = ?, fiscal_code = ?, address = ?, address_no = ?, city = ?, province = ?, postcode = ?, country = ? "
            + " WHERE user_id = ? ";
    /**
     * <code>SELECT_LOAD_USER_BY_USERNAME_QUERY</code>
     * SQL query to load user information from the database based on the username.
     */

    private static final String SELECT_LOAD_USER_BY_USERNAME_QUERY = "select * from emotional_songs.utenti_registrati where username = ?";
    /**
     * <code>SELECT_USER_FEEDBACK_QUERY</code>
     * SQL query to retrieve user feedback along with the associated song details for a specific user.
     */

    private static final String SELECT_USER_FEEDBACK_QUERY = " select ef.emotion_id, ef.score, ef.note, ef.add_date, " +
            "   ef.add_user_id, ef.mod_date, ef.mod_user_id, s.* " +
            " from emotional_songs.emozioni ef " +
            "   join emotional_songs.song s on ef.song_id = s.song_id " +
            " where ef.user_id = ? ";
    /**
     * Default constructor for the UserInfoEngine_Service class.
     */
    public UserInfoEngine_Service(){

    }
    /**
     * This method updates the user information in the database.
     *
     * @param user      The user object containing updated information.
     * @param address   The user's address object.
     * @param firstName The user's first name.
     * @param lastName  The user's last name.
     * @param fiscalCode The user's fiscal code.
     * @param email     The user's email address.
     * @return true if the update operation is successful, false otherwise.
     * @throws SQLException If a SQL exception occurs.
     */
    public boolean updateUser(User user, Address address, String firstName, String lastName, String fiscalCode, String email) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(UPDATE_USER_INFO_QUERY);
        pstm.setString(1, email);
        pstm.setString(2, firstName);
        pstm.setString(3, lastName);
        pstm.setString(4, fiscalCode);
        pstm.setString(5, address.getAddress());
        pstm.setString(6, address.getAddressNumber());
        pstm.setString(7, address.getCity());
        pstm.setString(8, address.getProvince());
        pstm.setString(9, address.getPostcode());
        pstm.setString(10, address.getCountry());
        pstm.setLong(11, user.getUserId());

        int updatedLine = pstm.executeUpdate();

        pstm.close();
        connection.close();

        if(updatedLine > 0){
            return true;
        } else {
            return false;
        }
    }
    /**
     * This method loads a user by username from the database.
     *
     * @param username The username of the user to load.
     * @return The user object.
     * @throws SQLException If a SQL exception occurs.
     */
    public User loadUserByUsername(String username) throws SQLException {
        User user = new User();

        Connection connection = (Connection) DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(SELECT_LOAD_USER_BY_USERNAME_QUERY);
        pstm.setString(1, username);
        ResultSet rs = pstm.executeQuery();

        if(rs.next()){
            user = fillUser(rs);
        }

        pstm.close();
        connection.close();

        return user;
    }
    /**
     * This method loads a user by user ID from the database.
     *
     * @param userId The user ID of the user to load.
     * @return The user object.
     * @throws SQLException If a SQL exception occurs.
     */
    public User loadUserByUserId(Long userId) throws SQLException {
        User user = new User();

        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(SELECT_LOAD_USER_BY_USER_ID_QUERY);
        pstm.setLong(1, userId);
        ResultSet rs = pstm.executeQuery();

        if(rs.next()){
            user = fillUser(rs);
        }

        pstm.close();
        connection.close();

        return user;
    }
    /**
     * This method changes the password for a user.
     *
     * @param userId      The user ID of the user whose password is being changed.
     * @param oldPassword The old password.
     * @param newPassword The new password.
     * @return true if the password is successfully changed, false otherwise.
     * @throws IOException If an I/O exception occurs.
     * @throws NotBoundException If the specified name is not currently bound to an object in the registry.
     * @throws SQLException If a SQL exception occurs.
     */
    public boolean changePassword(Long userId, String oldPassword, String newPassword) throws IOException, NotBoundException, SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(UPDATE_USER_PASSWORD_QUERY);
        pstm.setString(1, newPassword);
        pstm.setLong(2, userId);
        pstm.setString(3, oldPassword);

        int updatedLine = pstm.executeUpdate();

        pstm.close();
        connection.close();

        if(updatedLine > 0){
            return true;
        } else {
            return false;
        }
    }
    /**
     * This method checks if the provided password matches the password stored in the database for the specified user.
     *
     * @param userId   The user ID.
     * @param password The password to check.
     * @return true if the passwords match, false otherwise.
     * @throws SQLException If a SQL exception occurs.
     */
    public boolean checkPassword(Long userId, String password) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(CHECK_PASSWORD_QUERY);

        pstm.setString(1, password);
        pstm.setLong(2, userId);

        boolean arePasswordsEquals = false;
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            arePasswordsEquals = rs.getBoolean("are_passwords_equals");
        }

        pstm.close();
        connection.close();

        return arePasswordsEquals;
    }
    /**
     * This method loads playlists belonging to a user.
     *
     * @param userId The ID of the user.
     * @return A list of playlists belonging to the user.
     * @throws SQLException If a SQL exception occurs.
     */
    public List<Playlist> loadUserPlaylist(Long userId)throws SQLException {
        List<Playlist> userPlaylist = new ArrayList<>();

        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(SELECT_USER_PLAYLIST_QUERY);
        pstm.setLong(1, userId);

        ResultSet rs = pstm.executeQuery();
        while(rs.next()){
            Playlist p = fillPlaylist(rs);
            p.setUserId(userId);

            userPlaylist.add(p);
        }

        pstm.close();
        connection.close();

        return userPlaylist;
    }
    /**
     * This method loads user feedback entries from the database.
     *
     * @param userId The ID of the user.
     * @return A list of user feedback entries.
     * @throws SQLException If a SQL exception occurs.
     */
    public List<UserFeedback> loadUserFeedback(Long userId) throws SQLException{
        List<UserFeedback> userFeedbacks = new ArrayList<>();

        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(SELECT_USER_FEEDBACK_QUERY);
        pstm.setLong(1, userId);

        ResultSet rs = pstm.executeQuery();
        while(rs.next()){
            UserFeedback uf = fillUserFeedback(rs);
            uf.setUserId(userId);

            userFeedbacks.add(uf);
        }

        pstm.close();
        connection.close();

        return userFeedbacks;
    }
    /**
     * This method fills a UserFeedback object with data from the provided ResultSet.
     *
     * @param rs The ResultSet containing the user feedback data.
     * @return A UserFeedback object.
     * @throws SQLException If a SQL exception occurs.
     */
    private UserFeedback fillUserFeedback(ResultSet rs) throws SQLException {
        UserFeedback uf = new UserFeedback();
        uf.setScore(rs.getInt("score"));
        uf.setNote(rs.getString("note"));
        uf.setAddDate(rs.getDate("add_date"));
        uf.setAddUserId(rs.getString("add_user_id"));
        uf.setModDate(rs.getDate("mod_date"));
        uf.setModUserId(rs.getString("mod_user_id"));

        Long emotionId = rs.getLong("emotion_id");
        Emotion em = Emotions.getEmotionMap().get(emotionId);
        uf.setEmotion(em);

        Song s = fillSong(rs);
        uf.setSong(s);

        return uf;
    }
    /**
     * This method fills a Song object with data from the provided ResultSet.
     *
     * @param rs The ResultSet containing the song data.
     * @return A Song object.
     * @throws SQLException If a SQL exception occurs.
     */
    private Song fillSong(ResultSet rs) throws SQLException {
        Song s = new Song();
        s.setSongId(rs.getLong("song_id"));
        s.setTitle(rs.getString("title"));
        s.setAuthor(rs.getString("author"));
        s.setAlbum(rs.getString("album"));
        s.setYear(rs.getString("year"));
        s.setDuration(rs.getDouble("duration"));

        return s;
    }
    /**
     * This method fills a Playlist object with data from the provided ResultSet.
     *
     * @param rs The ResultSet containing the playlist data.
     * @return A Playlist object.
     * @throws SQLException If a SQL exception occurs.
     */
    private Playlist fillPlaylist(ResultSet rs) throws SQLException{
        Playlist playlist = new Playlist();

        playlist.setPlaylistId(rs.getLong("playlist_id"));
        playlist.setName(rs.getString("name"));
        playlist.setDescription(rs.getString("description"));
        playlist.setAddDate(rs.getDate("add_date"));
        playlist.setNumberOfSongs(rs.getLong("num_of_songs"));

        long duration = rs.getLong("playlist_duration");
        long hours = duration / 3600;
        long minutes = (duration % 3600) / 60;
        long seconds = duration % 60;
        String durationStr = hours + " h " + minutes + " min " + seconds + " sec";
        playlist.setPlaylistDuration(durationStr);

        return playlist;
    }
    /**
     * This method fills a User object with data from the provided ResultSet.
     *
     * @param rs The ResultSet containing the user data.
     * @return A User object.
     * @throws SQLException If a SQL exception occurs.
     */
    private User fillUser(ResultSet rs) throws SQLException{
        User user = new User();
        user.setUserId(rs.getLong("user_id"));
        user.setEmail(rs.getString("email"));
        user.setUsername(rs.getString("username"));
        user.setFirstName(rs.getString("name"));
        user.setLastName(rs.getString("last_name"));
        user.setFiscalCode(rs.getString("fiscal_code"));

        user.setAddress(new Address());
        user.getAddress().setAddress(rs.getString("address"));
        user.getAddress().setAddressNumber(rs.getString("address_no"));
        user.getAddress().setCity(rs.getString("city"));
        user.getAddress().setProvince(rs.getString("province"));
        user.getAddress().setPostcode(rs.getString("postcode"));
        user.getAddress().setCountry(rs.getString("country"));

        return user;
    }

}
