package serverES.services;

import commons.objects.Song;
import serverES.objects.dbconnection.DbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 * <p>This class provides methods to manage playlists in the system.</p>*
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class PlaylistEngine_Service {
    /**
     * <code>SELECT_PLAYLIST_SONGS</code>
     * SQL query to retrieve songs belonging to a playlist.
     */
    private static final String SELECT_PLAYLIST_SONGS = " select s.song_id, s.title, s.author, s.year, s.album, s.duration  " +
            " from emotional_songs.song s " +
            "   join emotional_songs.playlist_song ps on ps.song_id = s.song_id  " +
            " where ps.playlist_id  = ? ";
    /**
     * <code>DELETE_PLAYLIST_SONGS</code>
     * SQL query to delete all songs from a specific playlist.
     */
    private static final String DELETE_PLAYLIST_SONGS = " delete from emotional_songs.playlist_song where playlist_id  = ? ";
    /**
     * <code>DELETE_PLAYLIST</code>
     * SQL query to delete a specific playlist.
     */
    private static final String DELETE_PLAYLIST = " delete from emotional_songs.playlist where playlist_id  = ? ";
    /**
     * <code>DELETE_SONG_FROM_PLAYLIST</code>
     * SQL query to delete a specific song from a playlist.
     */
    private static final String DELETE_SONG_FROM_PLAYLIST = " delete from emotional_songs.playlist_song where playlist_id  = ? and song_id = ?";
    /**
     * <code>INSERT_PLAYLIST</code>
     * SQL query to insert a new playlist into the database.
     */
    private static final String INSERT_PLAYLIST = " insert into emotional_songs.playlist (name, description, user_id, add_date) " +
            " values (?, ?, ?, current_timestamp); ";
    /**
     * <code>INSERT_SONG_IN_PLAYLIST</code>
     * SQL query to insert a song into a playlist in the database.
     */
    private static final String INSERT_SONG_IN_PLAYLIST = "insert into emotional_songs.playlist_song " +
            " (playlist_id, song_id, add_date, mod_date) " +
            " values (?, ?, current_timestamp, current_timestamp);";
    /**
     * <code>SELECT_EXIST_SONG_IN_PLAYLIST_QUERY</code>
     * SQL query to check if a song already exists in a playlist for a specific user.
     */
    private static final String SELECT_EXIST_SONG_IN_PLAYLIST_QUERY = "select count(ps.*) as exist_song " +
            " from emotional_songs.playlist p " +
            "    join emotional_songs.playlist_song ps on ps.playlist_id = p.playlist_id " +
            " where p.user_id = ? and p.playlist_id = ? and ps.song_id = ? " +
            " group by p.user_id, p.playlist_id, song_id ";

    /**
     * Constructs a new PlaylistEngine_Service object.
     */
    public PlaylistEngine_Service() {
    }
    /**
     * This method retrieves songs belonging to a playlist.
     *
     * @param playlistId The ID of the playlist for which songs are to be retrieved.
     * @return A list of songs belonging to the specified playlist.
     * @throws SQLException If a database access error occurs.
     */
    public List<Song> loadPlaylistSongs(Long playlistId) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(SELECT_PLAYLIST_SONGS);
        pstm.setLong(1, playlistId);

        ResultSet rs = pstm.executeQuery();

        List<Song> playlistSongs = new ArrayList<>();
        while(rs.next()){
            Song result = fillSong(rs);
            playlistSongs.add(result);
        }

        pstm.close();
        connection.close();

        return playlistSongs;
    }
    /**
     * This method deletes all songs from a playlist.
     *
     * @param playlistId The ID of the playlist from which songs are to be deleted.
     * @return True if the songs were successfully deleted, false otherwise.
     * @throws SQLException If a database access error occurs.
     */
    public boolean deletePlaylistSongs(Long playlistId) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(DELETE_PLAYLIST_SONGS);
        pstm.setLong(1, playlistId);
        pstm.executeUpdate();

        pstm = connection.prepareStatement(DELETE_PLAYLIST);
        pstm.setLong(1, playlistId);
        int deletedTotal = pstm.executeUpdate();

        pstm.close();
        connection.close();

        if(deletedTotal > 0){
            return true;
        } else {
            return false;
        }
    }
    /**
     * This method adds a new playlist to the database.
     *
     * @param name    The name of the new playlist.
     * @param descr   The description of the new playlist.
     * @param userId  The ID of the user creating the playlist.
     * @return True if the playlist was successfully added, false otherwise.
     * @throws SQLException If a database access error occurs.
     */
    public boolean addNewPlaylist(String name, String descr, Long userId) throws SQLException{
        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(INSERT_PLAYLIST);
        pstm.setString(1, name);
        pstm.setString(2, descr);
        pstm.setLong(3, userId);
        int insertTotal = pstm.executeUpdate();

        pstm.close();
        connection.close();

        if(insertTotal > 0){
            return true;
        } else {
            return false;
        }
    }
    /**
     * This method removes a song from a playlist.
     *
     * @param playlistId The ID of the playlist from which the song will be removed.
     * @param songId     The ID of the song to be removed.
     * @return True if the song was successfully removed from the playlist, false otherwise.
     * @throws SQLException If a database access error occurs.
     */
    public boolean removeSongFromPlaylistSongs(Long playlistId, Long songId) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(DELETE_SONG_FROM_PLAYLIST);
        pstm.setLong(1, playlistId);
        pstm.setLong(2, songId);
        int deleteTotal = pstm.executeUpdate();

        pstm.close();
        connection.close();

        if(deleteTotal > 0){
            return true;
        } else {
            return false;
        }
    }

    /**
     * This method adds a song to a playlist.
     *
     * @param songId     The ID of the song to add to the playlist.
     * @param playlistId The ID of the playlist to which the song will be added.
     * @param userId     The ID of the user adding the song to the playlist.
     * @return True if the song was successfully added to the playlist, false otherwise.
     * @throws SQLException If a database access error occurs.
     */
    public boolean addSongInPlaylist(Long songId, Long playlistId, Long userId) throws SQLException {
        if(checkIfAlreadyExistSongInPlaylist(playlistId, songId, userId)){
            return false;
        }

        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(INSERT_SONG_IN_PLAYLIST);
        pstm.setLong(1, playlistId);
        pstm.setLong(2, songId);
        int insertTotal = pstm.executeUpdate();

        pstm.close();
        connection.close();

        if(insertTotal > 0){
            return true;
        } else {
            return false;
        }
    }

    /**
     * This method checks if a song already exists in a playlist.
     *
     * @param playlistId The ID of the playlist to check.
     * @param songId     The ID of the song to check.
     * @param userId     The ID of the user who owns the playlist.
     * @return True if the song already exists in the playlist, false otherwise.
     * @throws SQLException If a database access error occurs.
     */
    private boolean checkIfAlreadyExistSongInPlaylist(Long playlistId, Long songId, Long userId) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(SELECT_EXIST_SONG_IN_PLAYLIST_QUERY);
        pstm.setLong(1, userId);
        pstm.setLong(2, playlistId);
        pstm.setLong(3, songId);
        ResultSet rs = pstm.executeQuery();

        int existSong = 0;
        if(rs.next()){
            existSong = rs.getInt("exist_song");
        }

        pstm.close();
        connection.close();

        if(existSong > 0){
            return true;
        } else {
            return false;
        }
    }

    /**
     * This method fills a Song object with data from a ResultSet.
     *
     * @param rs The ResultSet containing song data.
     * @return A Song object filled with data from the ResultSet.
     * @throws SQLException If a database access error occurs.
     */
    private Song fillSong(ResultSet rs) throws SQLException {
        Song s = new Song();
        s.setSongId(rs.getLong("song_id"));
        s.setTitle(rs.getString("title"));
        s.setAuthor(rs.getString("author"));
        s.setAlbum(rs.getString("album"));
        s.setYear(rs.getString("year"));
        s.setDuration(rs.getDouble("duration"));

        return s;
    }
}
