package serverES;

import javafx.application.Platform;
import javafx.stage.WindowEvent;
import serverES.controller.dbconnection.DbConnectionPage_Controller;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import serverES.controller.ServerWindow_Controller;
import serverES.objects.dbconnection.DbConnection;

import java.io.IOException;
/**
 * <p>This is the main class for the ServerES application.</p>*
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */
public class ServerES extends Application {
    /**
     * <code>primaryStage</code>
     * The primary stage of the application.
     */
    private Stage primaryStage;
    /**
     * <code>dbConnectionPageScene</code>
     * The scene for the database connection page.
     */

    private Scene dbConnectionPageScene;
    /**
     * <code>dbConnectionPageController</code>
     * The controller for the database connection page.
     */
    private DbConnectionPage_Controller dbConnectionPageController;
    /**
     * <code>serverWindowController</code>
     * The controller for the server window.
     */
    private ServerWindow_Controller serverWindowController;
    /**
     * <code>serverWindowScene</code>
     * The scene for the server window.
     */
    private Scene serverWindowScene;

    /**
     * This method start the scene.
     *
     * @param stage A Scene object that define which scene to show.
     */
    @Override
    public void start(Stage stage) throws IOException {
        this.primaryStage = stage;

        FXMLLoader dbInitLoader = new FXMLLoader(ServerES.class.getResource("DbConnectionPage.fxml"));
        Parent serverAccessRoot = dbInitLoader.load();
        dbConnectionPageController = dbInitLoader.getController();
        dbConnectionPageController.setApplication(this);
        dbConnectionPageScene = new Scene(serverAccessRoot, 824, 544);

        FXMLLoader serverWindowLoader = new FXMLLoader(ServerES.class.getResource("ServerWindow.fxml"));
        Parent serverWindowRoot = serverWindowLoader.load();
        serverWindowController = serverWindowLoader.getController();
        serverWindowController.setApplication(this);
        serverWindowScene = new Scene(serverWindowRoot, 303, 144);
        //prefHeight="144.0" prefWidth="303.0"  prefHeight="544.0" prefWidth="824.0"
        primaryStage.setOnCloseRequest((WindowEvent event) -> {
            onCloseAction();
        });

        stage.setTitle(" DATABASE ");
        stage.setScene(dbConnectionPageScene);
        stage.show();
    }
    /**
     * This method switches the primary stage scene to the server window scene.
     */
    public void switchToServerPage(){
        primaryStage.setScene(serverWindowScene);
        primaryStage.setTitle("SERVER");
    }

    /**
     * This method start the application.
     */
    public static void main(String[] args) {
        DbConnection.restoreDefaultConnectionInfo();
        launch();
    }
    /**
     * This method performs actions when the application is closed.
     */
    private void onCloseAction() {
        serverWindowController.stopServer();
        Platform.exit();
        System.exit(0);
    }
}
