package serverES.controller.dbconnection;

import serverES.ServerES;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import serverES.objects.dbconnection.DbConnection;

import java.sql.SQLException;

/**
 * <p>This class defines a controller for the database connection configuration page.</p>*
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class DbConnectionPage_Controller {
    /**
     * <code>dbUsernameField</code>
     * A TextField used for entering the database username.
     */
    @FXML
    private TextField dbUsernameField;
    /**
     * <code>dbHostField</code>
     * A TextField used for entering the database host address.
     */
    @FXML
    private TextField dbHostField;
    /**
     * <code>dbPortField</code>
     * A TextField used for entering the database port number.
     */
    @FXML
    private TextField dbPortField;

    /**
     * <code>dbPasswordField</code>
     * A PasswordField used for entering the database password.
     */
    @FXML
    private PasswordField dbPasswordField;

    /**
     * <code>operationInfoField</code>
     * A Label used for displaying operation information or messages.
     */
    @FXML
    private Label operationInfoField;

    /**
     * <code>application</code>
     * A ServerES object that manages the navigation between different screens and provides functionality for user interactions.
     */
    @FXML
    private ServerES application;

    /**
     * This method sets the ServerES application instance.
     *
     * @param application The ServerES object that manages the navigation between different screens and provides functionality for user interactions.
     */
    public void setApplication(ServerES application) {
        this.application = application;
    }

    /**
     * This method handles the configuration button action.
     *
     * @param event The ActionEvent triggered by clicking the configuration button.
     */
    @FXML
    protected void configButton(ActionEvent event) {
        String operationInfo = "";
        String dbHost = dbHostField.getText();
        String dbPort = dbPortField.getText();
        String dbUsername = dbUsernameField.getText();
        String dbPassword = dbPasswordField.getText();

        if(dbHost == null || dbHost.isEmpty() || dbPort == null || dbPort.isEmpty()
                || dbUsername == null || dbUsername.isEmpty()
                || dbPassword == null || dbPassword.isEmpty()) {
            DbConnection.restoreDefaultConnectionInfo();
            operationInfo = "Use default configuration";
            operationInfoField.setText(operationInfo);
        } else {
            operationInfo = DbConnection.saveConnectionInfo(dbPort, dbHost, dbUsername, dbPassword);
            operationInfoField.setText(operationInfo);
        }
    }

    /**
     * This method handles the test connection button action.
     *
     * @param event The ActionEvent triggered by clicking the test connection button.
     */
    @FXML
    protected void testConnectionButton(ActionEvent event) {
        String operationInfo = "";
        try {
            operationInfo = DbConnection.getInstance().testConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        operationInfoField.setText(operationInfo);
    }

    /**
     * This method handles the action when the "Go to Server" button is clicked.*
     * @param event The ActionEvent triggered by clicking the "Go to Server" button.
     */
    @FXML
    protected void goToServerButton(ActionEvent event) {
        application.switchToServerPage();
    }
}
