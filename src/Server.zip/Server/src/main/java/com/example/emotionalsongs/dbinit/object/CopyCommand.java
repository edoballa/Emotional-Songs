package com.example.emotionalsongs.dbinit.object;

public class CopyCommand {
}
