package com.example.emotionalsongs.dbinit.controller;

import com.example.emotionalsongs.EmotionalSongsApplication;
import com.example.emotionalsongs.dbinit.service.DbInitializer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class DbInitPage_Controller {
    @FXML
    private TextField dbUsernameField;
    @FXML
    private TextField dbNameField;
    @FXML
    private TextField dbHostField;
    @FXML
    private TextField dbPortField;
    @FXML
    private PasswordField dbPasswordField;
    @FXML
    private Label operationInfoField;
    @FXML
    private EmotionalSongsApplication application;
    private DbInitializer dbInitializer;

    public void setApplication(EmotionalSongsApplication application) {
        this.application = application;
    }

    @FXML
    protected void configButton(ActionEvent event) {
        if(this.dbInitializer == null) {
            this.dbInitializer = DbInitializer.getInstance();
        }

        String operationInfo = "";
        operationInfo += dbInitializer.createDbStructure();
        operationInfo += "\n" + dbInitializer.fillSongTable();
        operationInfoField.setText(operationInfo);
    }

    @FXML
    protected void initButton(ActionEvent event) {
        if(this.dbInitializer == null) {
            this.dbInitializer = DbInitializer.getInstance();
        }

        String operationInfo = "";
        String dbHost = dbHostField.getText();
        String dbPort = dbPortField.getText();
        String dbName = dbNameField.getText();
        String dbUsername = dbUsernameField.getText();
        String dbPassword = dbPasswordField.getText();

        if(dbHost == null || dbHost.isEmpty() || dbPort == null || dbPort.isEmpty()
                || dbName == null || dbName.isEmpty() || dbUsername == null || dbUsername.isEmpty()
                || dbPassword == null || dbPassword.isEmpty()) {
            operationInfo = "One or more fields are not filled in!";
            operationInfoField.setText(operationInfo);
            return;
        }

        operationInfo = dbInitializer.setConnectionInfo(dbPort, dbHost, dbName, dbUsername, dbPassword);
        operationInfoField.setText(operationInfo);
    }


    @FXML
    protected void testConnectionButton(ActionEvent event) {
        System.out.println(System.getProperty("user.dir"));
        if(this.dbInitializer == null) {
            this.dbInitializer = DbInitializer.getInstance();
        }

        String operationInfo = "";
        operationInfo = this.dbInitializer.testConnection();
        operationInfoField.setText(operationInfo);
    }

}
