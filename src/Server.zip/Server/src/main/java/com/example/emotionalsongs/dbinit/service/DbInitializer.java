package com.example.emotionalsongs.dbinit.service;

import com.example.emotionalsongs.dbinit.object.DbConnection;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DbInitializer {
    private final static Logger logger = Logger.getLogger("DbInitializer");

    private static final String FILE_SQL_DB_STRUCTURE = System.getProperty("user.dir") + "\\config\\DbStructure.sql";
    private static final String FILE_SQL_SONG_DATA = System.getProperty("user.dir") + "\\data\\UserDataTable.sql";
    private static final String FILE_CSV_SONG_DATA = System.getProperty("user.dir") + "\\data\\SongData.csv";

    private static DbInitializer dbInitializer = null;
    private DbInitializer(){

    }

    public static DbInitializer getInstance(){
        if (dbInitializer == null){
            dbInitializer = new DbInitializer();
        }

        return dbInitializer;
    }

    public String testConnection(){
        try {
            logger.log(Level.INFO, "Test-Connection: start get connection");
            Connection connection = DbConnection.getInstance().testConnection();

            //if connection still null return error message
            if(connection == null) {
                logger.log(Level.SEVERE, "Test-Connection: Connection error, please retry");
                return "Test-Connection: Connection error, please retry";
            } else {
                String testQuery = "select 1 as res";
                logger.log(Level.INFO, "Test-Connection: connection request end successfully, try to launch query {}", testQuery);
                PreparedStatement pstm = connection.prepareStatement(testQuery);
                ResultSet rs = pstm.executeQuery();
                logger.log(Level.INFO, "Test-Connection: query executed successfully");

                boolean isResultOk = false;
                if(rs.next()){
                    logger.log(Level.INFO, "Test-Connection: try to get query result");
                    if(rs.getInt("res") > 0){
                        isResultOk = true;
                        logger.log(Level.INFO, "Test-Connection: result set successfully");
                    }
                }

                pstm.close();
                connection.close();

                if(isResultOk) {
                    logger.log(Level.INFO, "Test-Connection: procedure end successfully");
                    return "Test-Connection: procedure end successfully";
                } else {
                    logger.log(Level.SEVERE, "Test-Connection: procedure end not successfully");
                    return "Test-Connection: procedure end not successfully, please retry!";
                }
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Cannot execute query", e);
            return "Cannot execute query";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Something went wrong", e);
            return "Something went wrong";
        }
    }

    public String setConnectionInfo(String dbPort, String dbHost, String dbName, String dbUsername, String dbPassword){
        return DbConnection.saveConnectionInfo(dbPort, dbHost, dbName, dbUsername, dbPassword);
    }

    public String createDbStructure(){
        return launchQueryUsingFile("create-db-structure", FILE_SQL_DB_STRUCTURE);
    }

    public String fillSongTable(){
        String copyCommandQuery = "COPY emotional_songs.song (title, author, year, album, duration) FROM '"
                + FILE_CSV_SONG_DATA + "' WITH (FORMAT csv, HEADER true, DELIMITER ';', ENCODING 'UTF-8')";

        return launchQueryUsingCopyCommand("fill-song-table", copyCommandQuery);
    }

    private String launchQueryUsingFile(String configPhase, String filename){
        logger.log(Level.INFO, "DB-Init: Starting {}", configPhase);
        List<String> lines = null;
        try {
            logger.log(Level.INFO, "Starting read file {}", filename);
            lines = Files.readAllLines(new File(filename).toPath());
            logger.log(Level.INFO, "End read file");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Something went wrong during reading file", e);
            return "Something went wrong during reading file";
        }

        if(lines == null){
            logger.log(Level.SEVERE, "Something went wrong during reading file, maybe {} is empty", filename);
            return "Something went wrong during reading file, maybe " + filename + " is empty";
        }

        List<String> queries = new ArrayList<>();
        String query = "";
        logger.log(Level.INFO, "Build every single query");
        for(String line : lines){
            query += line;
            if(line.endsWith(";")) {
                queries.add(query);
                query = "";
            }
        }
        logger.log(Level.INFO, "I found {} query to launch", queries.size());

        try {
            Connection connection = DbConnection.getInstance().getConnection();
            logger.log(Level.INFO, "Starting launch query");
            for(String q : queries){
                PreparedStatement pstm = connection.prepareStatement(q);
                pstm.execute();
                pstm.close();
            }
            connection.close();
            logger.log(Level.INFO, "End launch query");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Cannot execute query", e);
            return "Cannot execute query";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Something went wrong", e);
            return "Something went wrong";
        }

        logger.log(Level.INFO, "DB-Init: End {}", configPhase);
        return "OK: procedure correctly performed on file " + filename;
    }

    private String launchQueryUsingCopyCommand(String configPhase, String copyCommandQuery){
        logger.log(Level.INFO, "DB-Init: Starting {}", configPhase);

        try {
            Connection connection = DbConnection.getInstance().getConnection();
            Statement stm = connection.createStatement();

            logger.log(Level.INFO, "Starting execute query");

            stm.execute(copyCommandQuery);
            stm.close();
            connection.close();

            logger.log(Level.INFO, "Finish execute query");

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Cannot execute query", e);
            return "Cannot execute query";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Something went wrong", e);
            return "Something went wrong";
        }

        logger.log(Level.INFO, "DB-Init: End {}", configPhase);
        return "OK " + configPhase + ": table filled successfully";
    }

}
