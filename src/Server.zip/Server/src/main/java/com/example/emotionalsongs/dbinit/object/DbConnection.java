package com.example.emotionalsongs.dbinit.object;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DbConnection {
    private final static Logger logger = Logger.getLogger("DbConnection");
    private final static String DB_PROPERTIES_FILE = System.getProperty("user.dir") + "\\config\\db.properties";
    private static DbConnection dbConnection = null;
    private Connection connection = null;
    private static Properties properties = null;

    private String dbPort = null;
    private String dbHost = null;
    private String dbName = null;
    private String dbUsername = null;
    private String dbPassword = null;

    private DbConnection() {
        this.dbPort = (String) properties.get("db.port");
        this.dbHost = (String) properties.get("db.host");
        this.dbName = (String) properties.get("db.name");
        this.dbUsername = (String) properties.get("db.username");
        this.dbPassword = (String) properties.get("db.password");
    }

    public static DbConnection getInstance() throws SQLException {
        if (dbConnection == null) {
            dbConnection = new DbConnection();
        }
        return dbConnection;
    }

    public static String saveConnectionInfo(String dbPort, String dbHost, String dbName, String dbUsername, String dbPassword) {
        if(properties == null){
            try {
                FileInputStream propFile = new FileInputStream(DB_PROPERTIES_FILE);
                properties = new Properties();
                properties.load(propFile);
            } catch (FileNotFoundException e) {
                logger.log(Level.SEVERE, "Something went wrong with the file ", e);
                return "Something went wrong with the file";
            } catch (IOException e) {
                logger.log(Level.SEVERE, "Cannot read the file ", e);
                return "Cannot read the file";
            }
        }

        //I check again that the fields are not null to make sure I am saving the data correctly
        if(dbHost != null && !dbHost.isEmpty()) {
            properties.setProperty("db.host", dbHost);
        }

        if(dbPort != null && !dbPort.isEmpty()) {
            properties.setProperty("db.port", dbPort);
        }

        if(dbName != null && !dbName.isEmpty()) {
            properties.setProperty("db.name", dbName);
        }

        if(dbUsername != null && !dbUsername.isEmpty()) {
            properties.setProperty("db.username", dbUsername);
        }

        if(dbPassword != null && !dbPassword.isEmpty()) {
            properties.setProperty("db.password", dbPassword);
        }

        return "DB connection info has been saved correctly!";
    }

    public static void restoreDefaultConnectionInfo(){
        if(properties == null){
            try {
                FileInputStream propFile = new FileInputStream(DB_PROPERTIES_FILE);
                properties = new Properties();
                properties.load(propFile);
            } catch (FileNotFoundException e) {
                logger.log(Level.SEVERE, "Something went wrong with the file ", e);
            } catch (IOException e) {
                logger.log(Level.SEVERE, "Cannot read the file ", e);
            }
        }

        properties.setProperty("db.host", "localhost");
        properties.setProperty("db.port", "5432");
        properties.setProperty("db.name", "postgres");
        properties.setProperty("db.username", "postgres");
        properties.setProperty("db.password", "postgres");
    }

    public Connection getConnection() {
        try {
            String dbUrl = "jdbc:postgresql://" + this.dbHost + ":" + this.dbPort + "/" + this.dbName;
            Class.forName("org.postgresql.Driver");
            this.connection = DriverManager.getConnection(dbUrl, this.dbUsername, this.dbPassword);
        } catch (ClassNotFoundException e) {
            logger.log(Level.SEVERE, "Driver not found ", e);
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Connection failed", e);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Something went wrong", e);
        }

        return connection;
    }

    public Connection testConnection() {
        if(this.connection != null){
            try{
                this.connection.close();
            } catch (SQLException e) {
                logger.log(Level.SEVERE, "Connection failed", e);
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Something went wrong", e);
            }
            this.connection = null; //do this because the properties can be changed
        }

        return getConnection();
    }
}
