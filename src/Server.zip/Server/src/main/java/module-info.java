module com.example.emotionalsongs {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires java.sql;

    opens com.example.emotionalsongs to javafx.fxml;
    exports com.example.emotionalsongs;
    exports com.example.emotionalsongs.dbinit.controller;
    opens com.example.emotionalsongs.dbinit.controller to javafx.fxml;

}