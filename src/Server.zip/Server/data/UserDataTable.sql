INSERT INTO user_data (username, "password", "name", last_name, address, address_no, city, province, postcode) VALUES
    ('mario123', 'bb77d0d3b3f239fa5db73bdf27b8d29a', 'Mario', 'Rossi', 'via Roma', '15', 'Milano', 'mi', '20121'),
    ('laura.b', '34819d7beeabb9260a5c854bc85b3e44', 'Laura', 'Bianchi', 'corso Vittorio Emanuele', '30', 'Torino', 'to', '10121'),
    ('giuseppe87', 'abbc98342b154dc803c905b7f63eb81e', 'Giuseppe', 'Verdi', 'via Garibaldi', '8', 'Firenze', 'fi', '50125'),
    ('francesca.ricci', 'f2225845216c105f88d21c19f63d3d5b', 'Francesca', 'Ricci', 'via dei Mille', '5', 'Genova', 'ge', '16121'),
    ('elena_ferrari', '32250170a0dca92d53ec9624f336ca24', 'Elena', 'Ferrari', 'via Dante', '21', 'Bologna', 'bo', '40126'),
    ('marco_martini', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Marco', 'Martini', 'via Manzoni', '12', 'Roma', 'rm', '00185'),
    ('andrea456', 'bbea34de673713ea1686b453164d9f70', 'Andrea', 'Conti', 'via Garibaldi', '18', 'Napoli', 'na', '80132'),
    ('simona_g', '34b2d133d1f1780cda605e5ffe660bcd', 'Simona', 'Gallo', 'corso Cavour', '7', 'Torino', 'to', '10123'),
    ('luca.marchetti', '426d8166a1cf619f353c16a24972c10c', 'Luca', 'Marchetti', 'via Verdi', '14', 'Milano', 'mi', '20123'),
    ('valentina.mazza', '4df91b163f882d8a6193fe40efdb7a9e', 'Valentina', 'Mazza', 'via Carducci', '23', 'Bologna', 'bo', '40121'),
    ('paolo_moretti', '2f1eb813ddf2a91f0e4f1ebe8b333d94', 'Paolo', 'Moretti', 'via Manin', '9', 'Roma', 'rm', '00185'),
    ('elisa_789', 'c8351110f4bc2a98b4b321ab2cd1803d', 'Elisa', 'De Luca', 'via Napoli', '31', 'Napoli', 'na', '80134'),
    ('giovanni.fiori', '1fe6052ba380fd08da9891084bb9d08e', 'Giovanni', 'Fiori', 'corso Umberto', '20', 'Catania', 'ct', '95129'),
    ('roberta.rinaldi', '5f1bff0e161678f3fc33ebf0639decb5', 'Roberta', 'Rinaldi', 'via Milano', '16', 'Firenze', 'fi', '50123'),
    ('luigi987', 'c1dd7a21bfd80fc388937d1cdd454f5c', 'Luigi', 'Galli', 'via XX Settembre', '3', 'Genova', 'ge', '16121'),
    ('edo', '9003d1df22eb4d3820015070385194c8', 'Edoardo', 'Ballabio', 'via Roma', '15', 'Milano', 'mi', '20121'),
    ('claudio', '9003d1df22eb4d3820015070385194c8', 'Claudio', 'NonSoIlCognome', 'via Roma', '15', 'Milano', 'mi', '20121'),
    ('joele', '9003d1df22eb4d3820015070385194c8', 'Joele', 'Vallone', 'via Roma', '15', 'Milano', 'mi', '20121'),
    ('diana', '9003d1df22eb4d3820015070385194c8', 'Diana', 'Cantaluppi', 'via Dante', '21', 'Bologna', 'bo', '40126');



