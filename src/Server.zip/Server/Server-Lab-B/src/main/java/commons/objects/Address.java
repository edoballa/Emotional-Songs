package commons.objects;

import java.io.Serializable;

/**
 * <p>This class define what is an address</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */
public class Address implements Serializable {
    /**
     * <code>address</code>
     * A String to store the user's address.
     */
    private String address;
    /**
     * <code>addressNumber</code>
     * A String to store the user's addressNumber.
     */
    private String addressNumber;
    /**
     * <code>postcode</code>
     * A String to store the postcode of the user's city.
     */
    private String postcode;
    /**
     * <code>city</code>
     * A String to store the user's city.
     */
    private String city;
    /**
     * <code>province</code>
     * A String to store the user's province.
     */
    private String province;
    /**
     * <code>region</code>
     * A String to store the user's region.
     */
     private String region;
    /**
     * <code>country</code>
     * A String to store the user's country.
     */
     private String country;


    /**
     * <code>valid</code>
     * A boolean to check the validity of the user's address data.
     */
    private boolean valid = false;

    /**
     * Address default constructor.
     */
    public Address() {
    }

    /**
     * Address constructor with all fields as parameters.
     *
     * @param address The user's address.
     * @param addressNumber The user's number of the address.
     * @param postcode The postcode of the user's city.
     * @param city The user's city.
     * @param province The user's province.
     * @param region The user's province.
     * @param country The user's country.
     */
    public Address(String address, String addressNumber, String postcode, String city, String province,
                   String region, String country) {
        this.address = address;
        this.addressNumber = addressNumber;
        this.postcode = postcode;
        this.city = city;
        this.province = province;
        this.region = region;
        this.country = country;
        this.valid = checkAddressData();
    }

    /**
     * This method return the address field.
     * @return String the address.
     */
    public String getAddress() {
        return address;
    }

    /**
     * address setter method.
     * @param address The address to set.
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * This method return the addressNumber field.
     * @return String the addressNumber.
     */
    public String getAddressNumber() {
        return addressNumber;
    }

    /**
     * addressNumber setter method.
     * @param addressNumber The addressNumber to set.
     */
    public void setAddressNumber(String addressNumber) {
        this.addressNumber = addressNumber;
    }

    /**
     * This method return the postcode field.
     * @return String the postcode.
     */
    public String getPostcode() {
        return postcode;
    }

    /**
     * postcode setter method.
     * @param postcode The postcode to set.
     */
    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    /**
     * This method return the city field.
     * @return String the city.
     */
    public String getCity() {
        return city;
    }

    /**
     * city setter method.
     * @param city The city to set.
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * This method return the province field.
     * @return String the province.
     */
    public String getProvince() {
        return province;
    }

    /**
     * province setter method.
     * @param province The province to set.
     */
    public void setProvince(String province) {
        this.province = province;
    }

    /**
     * This method return the region field.
     * @return String the region.
     */
    public String getRegion() {
        return region;
    }

    /**
     * region setter method.
     * @param region The region to set.
     */
    public void setRegion(String region) {
        this.region = region;
    }

    /**
     * This method return the country field.
     * @return String the country.
     */
    public String getCountry() {
        return country;
    }

    /**
     * country setter method.
     * @param country The country to set.
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * This method return the valid field.
     * @return boolean the value of valid.
     */
    public boolean isValid() {
        return this.valid;
    }

    /**
     * This method checks the validity of the fields that compose the user's address.
     * @return boolean a boolean value that depends on the correctness of the user's address data.
     */
    public boolean checkAddressData() {
        if (this.address.isEmpty() || this.address == null) {
            this.valid = false;
            return this.valid;
        }

        if (this.addressNumber.isEmpty() || this.addressNumber == null) {
            this.valid = false;
            return this.valid;
        }

        if (this.postcode.isEmpty() || this.postcode == null || this.postcode.length() > 5) {
            this.valid = false;
            return this.valid;
        }

        if (this.city.isEmpty() || this.city == null) {
            this.valid = false;
            return this.valid;
        }

        if (this.province.isEmpty() || this.province == null || this.province.length() > 2) {
            this.valid = false;
            return this.valid;
        }

        if (this.country.isEmpty() || this.country == null) {
            this.valid = false;
            return this.valid;
        }

        this.valid = true;
        return this.valid;
    }
    /**
     * This method returns a string representation of the address object.
     *
     * @return A string representation of the address object.
     */
    @Override
    public String toString(){
        String addressToString = this.address + ", " + this.addressNumber + ", " + this.postcode + ", " + this.city
                + ", " + this.province + ", " + this.country;

        return addressToString;
    }
}