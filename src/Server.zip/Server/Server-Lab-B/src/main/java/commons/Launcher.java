package commons;

import serverES.ServerES;

public class Launcher {
    public static void main(String[] args) {
        ServerES.main(args);
    }
}
