package serverES.services;

import commons.objects.User;
import serverES.objects.dbconnection.DbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 * <p>This class provides functionality to handle user registration operations. It interacts with the database to verify user existence and register new users.</p>*
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */
public class RegistrationEngine_Service {
    /**
     * <code>SELECT_USER_EXISTS_ALREADY_QUERY</code>
     * SQL query to check if a username already exists in the system.
     */
    private static final String SELECT_USER_EXISTS_ALREADY_QUERY = " select count(username) as user_exists " +
            " from emotional_songs.utenti_registrati where username = ? group by username ";
    /**
     * <code>INSERT_NEW_USER_QUERY</code>
     * SQL query to insert a new user into the database.
     */
    private static final String INSERT_NEW_USER_QUERY = " INSERT INTO emotional_songs.utenti_registrati (username, password, fiscal_code, email, name, last_name, address, " +
            " address_no, city, province, postcode, country) VALUES  (?, md5( ? ),?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";

    /**
     * Default constructor for the RegistrationEngine_Service class.
     */
    public RegistrationEngine_Service(){

    }

    /**
     * Checks if a username already exists in the database.
     *
     * @param username The username to check for existence.
     * @return true if the username does not exist, false otherwise.
     * @throws SQLException If a database access error occurs.
     */
    public boolean canRegister(String username) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(SELECT_USER_EXISTS_ALREADY_QUERY);
        pstm.setString(1, username);
        ResultSet rs = pstm.executeQuery();

        int userExist = 0;
        if(rs.next()) {
            userExist = rs.getInt("user_exists");
        }

        pstm.close();
        connection.close();

        if(userExist > 0){
            return false;
        } else {
            return true;
        }
    }
    /**
     * Registers a new user in the database.
     *
     * @param paramUser The user object containing registration details.
     * @return true if the user is successfully registered, false otherwise.
     * @throws SQLException If a database access error occurs.
     */
    public boolean registrazione(User paramUser) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(INSERT_NEW_USER_QUERY);
        pstm.setString(1, paramUser.getUsername());
        pstm.setString(2, paramUser.getPassword());
        pstm.setString(3, paramUser.getFiscalCode());
        pstm.setString(4, paramUser.getEmail());
        pstm.setString(5, paramUser.getFirstName());
        pstm.setString(6, paramUser.getLastName());
        pstm.setString(7, paramUser.getAddress().getAddress());
        pstm.setString(8, paramUser.getAddress().getAddressNumber());
        pstm.setString(9, paramUser.getAddress().getCity());
        pstm.setString(10, paramUser.getAddress().getProvince());
        pstm.setString(11, paramUser.getAddress().getPostcode());
        pstm.setString(12, paramUser.getAddress().getCountry());

        int res = pstm.executeUpdate();

        pstm.close();
        connection.close();

        if(res > 0){
            return true;
        } else {
            return false;
        }
    }
}
