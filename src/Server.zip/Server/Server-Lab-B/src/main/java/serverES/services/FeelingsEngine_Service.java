package serverES.services;

import commons.objects.Emotions;
import commons.objects.*;
import serverES.objects.dbconnection.DbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 * <p>This class provides methods to interact with emotions and user feedback data in the database.</p>*
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class FeelingsEngine_Service {
    /**
     * <code>SELECT_EMOTIONS_LIST_QUERY</code>
     * SQL query to retrieve a list of emotions from the database.
     */
    private static final String SELECT_EMOTIONS_LIST_QUERY = " select * from emotional_songs.emotion_details e ";
    /**
     * <code>SELECT_FEELING_DETAILS_QUERY</code>
     * SQL query to retrieve details of feelings for a specific song.
     */
    private static final String SELECT_FEELING_DETAILS_QUERY = " select ef.emotion_id, avg(ef.score) as avg_of_ratings, " +
            "   count(ef.user_id) as number_of_ratings, string_agg(ef.note, '###') as notes " +
            " from emotional_songs.emozioni ef  " +
            " where song_id = ? " +
            " group by ef.emotion_id " ;

    /**
     * <code>UPDATE_USER_FEEDBACK_QUERY</code>
     * SQL query to update user feedback for a specific song and emotion.
     */
    private static final String UPDATE_USER_FEEDBACK_QUERY = "UPDATE emotional_songs.emozioni  " +
            " SET score = ?, note = ?, mod_date = current_timestamp, mod_user_id = ?  " +
            " WHERE song_id = ? AND emotion_id = ? AND user_id = ?; ";
    /**
     * <code>INSERT_USER_FEEDBACK_QUERY</code>
     * SQL query to insert user feedback for a specific song and emotion.
     */
    private static final String INSERT_USER_FEEDBACK_QUERY = "INSERT INTO emotional_songs.emozioni " +
            "   (song_id, emotion_id, user_id, score, note, add_date, add_user_id, mod_date, mod_user_id) " +
            " VALUES (?, ?, ?, ?, ?, current_timestamp, ?, current_timestamp, ?);";
    /**
     * <code>DELETE_USER_FEEDBACK_QUERY</code>
     * SQL query to delete user feedback for a specific song and emotion.
     */
    private static final String DELETE_USER_FEEDBACK_QUERY = "DELETE FROM emotional_songs.emozioni  " +
            " WHERE song_id = ? AND emotion_id = ? AND user_id = ?; ";
    /**
     * <code>SELECT_EXIST_FEEDBACK_FOR_SONG_QUERY</code>
     * SQL query to check if feedback exists for a specific song and user.
     */
    private static final String SELECT_EXIST_FEEDBACK_FOR_SONG_QUERY = " select count(ef.*) as exists_feedback_for_song " +
            " from emotional_songs.emozioni ef " +
            " where ef.user_id = ? and ef.song_id = ? " +
            " group by ef.user_id, ef.song_id ";

    /**
     * Constructs a new instance of FeelingsEngine_Service.
     */
    public FeelingsEngine_Service(){

    }
    /**
     * This method loads the emotions from the database and maps them to their respective IDs.
     *
     * @return A map containing emotions mapped to their IDs.
     * @throws SQLException If a database access error occurs.
     */
    public Map<Long, Emotion> loadEmotionMap() throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(SELECT_EMOTIONS_LIST_QUERY);
        ResultSet rs = pstm.executeQuery();

        Map<Long, Emotion> emotionMap = new HashMap<>();
        while(rs.next()){
            Emotion emotion = fillEmotion(rs);
            emotionMap.put(emotion.getEmotionId(), emotion);
        }

        pstm.close();
        connection.close();

        return emotionMap;
    }
    /**
     * This method retrieves the emotion feedback statistics for a given song ID.
     *
     * @param songId The ID of the song for which to retrieve emotion feedback statistics.
     * @return A list of EmotionFeedbackStatistics objects containing the statistics for each emotion related to the song.
     * @throws SQLException If a database access error occurs.
     */
    public List<EmotionFeedbackStatistics> getFeelingsBySongId(Long songId) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(SELECT_FEELING_DETAILS_QUERY);
        pstm.setLong(1, songId);
        ResultSet rs = pstm.executeQuery();

        List<EmotionFeedbackStatistics> feelingDetails = new ArrayList<>();
        while(rs.next()){
            EmotionFeedbackStatistics efd = fillEmotionFeltDetails(rs);
            feelingDetails.add(efd);
        }

        pstm.close();
        connection.close();

        return feelingDetails;
    }
    /**
     * This method updates the user feedback for a specific song and emotion.
     *
     * @param userFeedback The UserFeedback object containing the updated feedback data.
     * @return true if the user feedback is successfully updated, false otherwise.
     * @throws SQLException If a database access error occurs.
     */
    public boolean updateUserFeedback(UserFeedback userFeedback) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(UPDATE_USER_FEEDBACK_QUERY);
        pstm.setInt(1, userFeedback.getScore());
        pstm.setString(2, userFeedback.getNote());
        pstm.setString(3, "" + userFeedback.getUserId());
        pstm.setLong(4, userFeedback.getSong().getSongId());
        pstm.setLong(5, userFeedback.getEmotion().getEmotionId());
        pstm.setLong(6, userFeedback.getUserId());

        int updatedLine = pstm.executeUpdate();

        pstm.close();
        connection.close();

        if(updatedLine > 0){
            return true;
        } else {
            return false;
        }
    }
    /**
     * This method inserts the user's emotional feedback for a song into the database.
     *
     * @param userFeedback The UserFeedback object containing the emotional feedback data.
     * @return true if the emotional feedback is successfully inserted, false otherwise.
     * @throws SQLException If a database access error occurs.
     */
    public boolean inserisciEmozioniBrano(UserFeedback userFeedback) throws SQLException {
        if(checkIfAlreadyExistFeedbackForSong(userFeedback.getSong().getSongId(), userFeedback.getUserId())){
            return false;
        }

        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(INSERT_USER_FEEDBACK_QUERY);
        pstm.setLong(1, userFeedback.getSong().getSongId());
        pstm.setLong(2, userFeedback.getEmotion().getEmotionId());
        pstm.setLong(3, userFeedback.getUserId());
        pstm.setInt(4, userFeedback.getScore());
        pstm.setString(5, userFeedback.getNote());
        pstm.setString(6, "" + userFeedback.getUserId());
        pstm.setString(7, "" + userFeedback.getUserId());

        int insertTotal = pstm.executeUpdate();

        pstm.close();
        connection.close();

        if(insertTotal > 0){
            return true;
        } else {
            return false;
        }
    }
    /**
     * This method checks if there is already feedback for a song provided by a specific user.
     *
     * @param songId The ID of the song.
     * @param userId The ID of the user.
     * @return true if there is already feedback for the song provided by the user, false otherwise.
     * @throws SQLException If a database access error occurs.
     */
    private boolean checkIfAlreadyExistFeedbackForSong(Long songId, Long userId) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(SELECT_EXIST_FEEDBACK_FOR_SONG_QUERY);
        pstm.setLong(1, userId);
        pstm.setLong(2, songId);
        ResultSet rs = pstm.executeQuery();

        int existSong = 0;
        if(rs.next()){
            existSong = rs.getInt("exists_feedback_for_song");
        }

        pstm.close();
        connection.close();

        if(existSong > 0){
            return true;
        } else {
            return false;
        }
    }
    /**
     * This method deletes the feedback provided by a user for a specific song.
     *
     * @param userFeedback The UserFeedback object containing information about the feedback to be deleted.
     * @return true if the feedback is successfully deleted, false otherwise.
     * @throws SQLException If a database access error occurs.
     */
    public boolean deleteUserFeedback(UserFeedback userFeedback) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(DELETE_USER_FEEDBACK_QUERY);
        pstm.setLong(1, userFeedback.getSong().getSongId());
        pstm.setLong(2, userFeedback.getEmotion().getEmotionId());
        pstm.setLong(3, userFeedback.getUserId());

        int deleteTotal = pstm.executeUpdate();

        pstm.close();
        connection.close();

        if(deleteTotal > 0){
            return true;
        } else {
            return false;
        }
    }
    /**
     * This method fills an Emotion object with data retrieved from a ResultSet.
     *
     * @param rs The ResultSet containing emotion data.
     * @return An Emotion object filled with data from the ResultSet.
     * @throws SQLException If a database access error occurs.
     */
    private Emotion fillEmotion(ResultSet rs) throws SQLException {
        Emotion emotion = new Emotion();
        emotion.setEmotionId(rs.getLong("emotion_id"));
        emotion.setName(rs.getString("name"));
        emotion.setDescription(rs.getString("description"));
        return emotion;
    }
    /**
     * This method fills an EmotionFeedbackStatistics object with data retrieved from a ResultSet.
     *
     * @param rs The ResultSet containing emotion feedback statistics data.
     * @return An EmotionFeedbackStatistics object filled with data from the ResultSet.
     * @throws SQLException If a database access error occurs.
     */
    private EmotionFeedbackStatistics fillEmotionFeltDetails(ResultSet rs) throws SQLException {
        EmotionFeedbackStatistics efd = new EmotionFeedbackStatistics();

        Long emotionId = rs.getLong("emotion_id");
        efd.setEmotion(Emotions.getEmotionMap().get(emotionId));
        efd.setAverageOfRatings(rs.getDouble("avg_of_ratings"));
        efd.setNumberOfRatings(rs.getInt("number_of_ratings"));

        String commentsAgg = rs.getString("notes");
        List<String> commentsList = new ArrayList<>();
        if(commentsAgg != null && !commentsAgg.isEmpty()) {
            String[] comments = commentsAgg.split("###");
            for (int i = 0; i < comments.length; i++) {
                commentsList.add(comments[i]);
            }
        }

        efd.setComments(commentsList);
        return efd;
    }
}
