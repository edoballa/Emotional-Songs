package serverES.objects.dbconnection;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 * <p>This class manages the database connection to PostgreSQL.</p>*
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class DbConnection {
    /**
     * <code>logger</code>
     * The logger instance for the DbConnection class.
     */
    private final static Logger logger = Logger.getLogger("DbConnection");
    /**
     * <code>DB_PROPERTIES_FILE</code>
     * The file path of the database properties file.
     */
    private final static String DB_PROPERTIES_FILE = System.getProperty("user.dir") + "\\config\\db.properties";
    /**
     * <code>dbConnection</code>
     * A DbConnection object that it will be returned by the getIstance method.
     * This is the only DbConnecction object which is instanced.
     */
    private static DbConnection dbConnection = null;
    /**
     * <code>connection</code>
     * A Connection object representing the database connection.
     */
    private Connection connection = null;
    /**
     * <code>properties</code>
     * A Properties that contains the attributes to estabilish the connection to the database.
     */
    private static Properties properties = null;
    /**
     * <code>DB_NAME</code>
     * The name of the database.
     */
    private static final String DB_NAME = "dbes";
    /**
     * <code>dbPort</code>
     * The port number for the database connection.
     */
    private String dbPort;

    /**
     * <code>dbHost</code>
     * The host address of the database.
     */
    private String dbHost;

    /**
     * <code>dbUsername</code>
     * The username for accessing the database.
     */
    private String dbUsername;

    /**
     * <code>dbPassword</code>
     * The password for accessing the database.
     */
    private String dbPassword;

    /**
     * Constructs a new DbConnection object.
     * Initializes the connection properties from the database properties file.
     */
    private DbConnection() {
        this.dbPort = (String) properties.get("db.port");
        this.dbHost = (String) properties.get("db.host");
        this.dbUsername = (String) properties.get("db.username");
        this.dbPassword = (String) properties.get("db.password");
    }
    /**
     * This method retrieves the singleton instance of the DbConnection class.
     * If the instance is not yet created, a new instance is created and returned.
     *
     * @return The DbConnection singleton instance.
     * @throws SQLException If an SQL exception occurs while creating the instance.
     */
    public static DbConnection getInstance() throws SQLException {
        if (dbConnection == null) {
            dbConnection = new DbConnection();
        }
        return dbConnection;
    }

    /**
     * This method saves the database connection information to the properties file.
     *
     * @param dbPort The port of the database.
     * @param dbHost The host address of the database.
     * @param dbUsername The username for accessing the database.
     * @param dbPassword The password for accessing the database.
     * @return A message indicating the success or failure of the operation.
     */
    public static String saveConnectionInfo(String dbPort, String dbHost, String dbUsername, String dbPassword){

        try {
            FileInputStream propFile = new FileInputStream(DB_PROPERTIES_FILE);
            properties = new Properties();
            properties.load(propFile);
        } catch (FileNotFoundException e) {
            logger.log(Level.SEVERE, "Something went wrong with the file ", e);
            return "Something went wrong with the file";
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Cannot read the file ", e);
            return "Cannot read the file";
        }

        //I check again that the fields are not null to make sure I am saving the data correctly
        if (dbHost != null && !dbHost.isEmpty()) {
            properties.setProperty("db.host", dbHost);
        }

        if (dbPort != null && !dbPort.isEmpty()) {
            properties.setProperty("db.port", dbPort);
        }

        properties.setProperty("db.name", DB_NAME);

        if (dbUsername != null && !dbUsername.isEmpty()) {
            properties.setProperty("db.username", dbUsername);
        }

        if (dbPassword != null && !dbPassword.isEmpty()) {
            properties.setProperty("db.password", dbPassword);
        }

        try {
            properties.store(new FileOutputStream(DB_PROPERTIES_FILE), null);
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Failed to save properties to file", e);
            return "Failed to save properties to file";
        }
        return "DB connection info has been saved correctly!";

    }

    /**
     * This method restores the default database connection information and saves it to the properties file.
     */
    public static void restoreDefaultConnectionInfo() {
        if (properties == null) {
            try {
                FileInputStream propFile = new FileInputStream(DB_PROPERTIES_FILE);
                properties = new Properties();
                properties.load(propFile);
            } catch (FileNotFoundException e) {
                logger.log(Level.SEVERE, "Something went wrong with the file ", e);
            } catch (IOException e) {
                logger.log(Level.SEVERE, "Cannot read the file ", e);
            }
        }

        properties.setProperty("db.host", "localhost");
        properties.setProperty("db.port", "5432");
        properties.setProperty("db.name", DB_NAME);
        properties.setProperty("db.username", "postgres");
        properties.setProperty("db.password", "postgres");

        try {
            properties.store(new FileOutputStream(DB_PROPERTIES_FILE), null);
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Failed to save properties to file", e);
        }
    }

    /**
     * This method establishes a connection to the database using the stored connection parameters.
     *
     * @return A Connection object representing the established database connection.
     */
    public Connection getConnection() {
        try {
            String dbUrl = "jdbc:postgresql://" + this.dbHost + ":" + this.dbPort + "/" + DB_NAME;
            Class.forName("org.postgresql.Driver");
            this.connection = DriverManager.getConnection(dbUrl, this.dbUsername, this.dbPassword);
        } catch (ClassNotFoundException e) {
            logger.log(Level.SEVERE, "Driver not found ", e);
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Connection failed", e);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Something went wrong", e);
        }

        return connection;
    }

    /**
     * This method tests the connection to the database by executing a query.
     *
     * @return A message indicating the success or failure of the test.
     */
    public String testConnection(){
        try {
            logger.log(Level.INFO, "Test-Connection: start get connection");
            Connection connection = this.getConnection();

            //if connection still null return error message
            if(connection == null) {
                logger.log(Level.SEVERE, "Test-Connection: Connection error, please retry");
                return "Test-Connection: Connection error, please retry";
            } else {
                String testQuery = "select 1 as res";
                logger.log(Level.INFO, "Test-Connection: connection request end successfully, try to launch query {}", testQuery);
                PreparedStatement pstm = connection.prepareStatement(testQuery);
                ResultSet rs = pstm.executeQuery();
                logger.log(Level.INFO, "Test-Connection: query executed successfully");

                boolean isResultOk = false;
                if(rs.next()){
                    logger.log(Level.INFO, "Test-Connection: try to get query result");
                    if(rs.getInt("res") > 0){
                        isResultOk = true;
                        logger.log(Level.INFO, "Test-Connection: result set successfully");
                    }
                }

                pstm.close();
                connection.close();

                if(isResultOk) {
                    logger.log(Level.INFO, "Test-Connection: procedure end successfully");
                    return "Test-Connection: procedure end successfully";
                } else {
                    logger.log(Level.SEVERE, "Test-Connection: procedure end not successfully");
                    return "Test-Connection: procedure end not successfully, please retry!";
                }
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Cannot execute query", e);
            return "Cannot execute query";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Something went wrong", e);
            return "Something went wrong";
        }
    }
}

