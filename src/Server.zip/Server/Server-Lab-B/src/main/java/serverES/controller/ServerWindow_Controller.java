package serverES.controller;

import commons.objects.Emotion;
import commons.objects.Emotions;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import serverES.ServerES;
import serverES.rmi.ServerService;
import serverES.services.FeelingsEngine_Service;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
/**
 * <p>This class defines a controller for the server window.</p>*
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class ServerWindow_Controller {
    /**
     * <code>application</code>
     * A ServerES object representing the main application.
     */
    @FXML
    private ServerES application;
    /**
     * <code>startServerButton</code>
     * A Button used for starting the server.
     */
    @FXML
    private Button startServerButton;
    /**
     * <code>serverThread</code>
     * A Thread used for running the server.
     */
    private Thread serverThread;
    /**
     * <code>canStopServer</code>
     * A boolean indicating whether the server can be stopped.
     */
    private static boolean canStopServer = false;
    /**
     * <code>isServerRunning</code>
     * A boolean indicating whether the server is currently running.
     */
    private static boolean isServerRunning = false;

    /**
     * This method sets the ServerES application instance.
     *
     * @param application The ServerES object representing the main application.
     */
    public void setApplication(ServerES application) {
        this.application = application;
    }

    /**
     * This method handles the action triggered by clicking the "Start Server" button.
     * It starts the server if it is not already running and initializes necessary services.
     *
     * @param actionEvent The ActionEvent triggered by clicking the "Start Server" button.
     */
    @FXML
    public void startServerButton(ActionEvent actionEvent) {
        if(!isServerRunning) {
            startServerButton.setVisible(false);

            FeelingsEngine_Service feelingsEngineService = new FeelingsEngine_Service();
            Map<Long, Emotion> emotionMap = new HashMap<>();
            try {
                emotionMap = feelingsEngineService.loadEmotionMap();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            Emotions.setEmotionMap(emotionMap);

            serverThread = new Thread(() -> {
                try {
                    isServerRunning = true;
                    Registry registry = LocateRegistry.createRegistry(5099);
                    registry.rebind("ServerService", new ServerService());

                    System.out.println("ServerES is listening...");

                    // Keep the server running
                    while (true) {
                        if (canStopServer) { // do this to stop the server when tìsomeone close the window
                            System.out.println("Stop server");
                            break;
                        }

                        System.out.println("Still listening!");
                        serverThread.sleep(5000); // do this to prevent an excessively fast loop
                    }
                } catch (Exception e) {
                    if (isServerRunning && !canStopServer) {
                        System.err.println("Error starting the server.");
                        e.printStackTrace();
                    }
                }
            });

            serverThread.start();
        }
    }

    /**
     * This method stops the server if it is running.
     */
    public void stopServer() {
        if(isServerRunning) {
            isServerRunning = false;
            canStopServer = true;
            serverThread.interrupt();

            while(!serverThread.isInterrupted()){
                serverThread.interrupt();
            }
        }
    }
}
