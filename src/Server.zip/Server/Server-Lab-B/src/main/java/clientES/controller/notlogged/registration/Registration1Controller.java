package clientES.controller.notlogged.registration;

import clientES.ClientES;
import clientES.services.Registration_Service;
import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
/**
 * <p>This class represents the controller for the first step of the registration process.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */
public class Registration1Controller {
    /**
     * <code>backButton</code>
     * A Button used for navigating back to the previous screen or view..
     */
    @FXML private Button backButton;
    /**
     * <code>imageViewBack</code>
     * An ImageView object used for displaying an image, such as an arrow icon indicating navigation direction.
     */
    @FXML private ImageView imageViewBack;
    /**
     * The image representing the left arrow icon.
     * <code>imageLeftArrow</code>
     */
    @FXML private Image imageLeftArrow;
    /**
     * The text field for entering the username.
     * <code>usernameField</code>
     */
    @FXML protected TextField usernameField;
    /**
     * The text field for entering the password, visible to the user.
     * <code>passwordVisible</code>
     */
    @FXML protected TextField passwordVisible;
    /**
     * The password field for entering the password, masked.
     * <code>passwordField</code>
     */
    @FXML protected PasswordField passwordField;
    /**
     * <code>strengthBar</code>
     * Represents a ProgressBar used for visualizing the strength of the password entered by the user.
     */
    @FXML private ProgressBar strengthBar;
    /**
     * <code>strengthLabel</code>
     * Represents a Label used for displaying the strength of the password entered by the user.
     */
    @FXML private Label strengthLabel;
    /**
     * <code>requirementLabel</code>
     * Represents a Label used for displaying the password strength requirements to the user.
     */
    @FXML private Label requirementLabel;
    /**
     * <code>imageViewToggle</code>
     * Represents an ImageView used for displaying an icon indicating whether the password visibility is enabled or disabled.
     */
    @FXML private ToggleButton visibilityButton;
    /**
     * <code>imageViewToggle</code>
     * Represents an ImageView used for displaying an icon indicating whether the password visibility is enabled or disabled.
     */
    @FXML private ImageView imageViewToggle;
    /**
     * <code>imageVisibility</code>
     * Represents an Image object for the visibility icon when the password is visible.
     */
    @FXML private Image imageVisibility;
    /**
     * <code>imageNotVisibility</code>
     * Represents an Image object for the visibility icon when the password is not visible.
     */
    @FXML private Image imageNotVisibility;
    /**
     * <code>nextButton</code>
     * Represents a Button used for navigating to the next step of the registration process.
     */
    @FXML private Button nextButton;
    /**
     * <code>dismissErrorButton</code>
     * A Button used for dismissing error messages or notifications.
     */
    @FXML private Button dismissErrorButton;
    /**
     * <code>errorLabel</code>
     * A Label used for displaying error messages to the user.
     */
    @FXML private Label errorLabel;
    /**
     * <code>errorRectangle</code>
     * Represents a Rectangle used for displaying error messages or notifications.
     */
    @FXML private Rectangle errorRectangle;
    /**
     * <code>application</code>
     * Represents an instance of the ClientES application.
     */
    @FXML private ClientES application;

    /**
     * <code>registrationService</code>
     * Represents a service for handling registration operations.
     */
    private Registration_Service registrationService;
    /**
     * This method initializes the Registration1Controller after its root element has been completely processed.
     * It checks if the registration service is null and initializes it if necessary.
     */
    public void initialize() {
        if (registrationService == null) {
            registrationService = new Registration_Service();
        }

        imageLeftArrow = new Image(getClass().getResource("/clientES/images/leftArrow.png").toExternalForm());
        imageViewBack.setImage(imageLeftArrow);
        imageViewBack.setFitHeight(20);
        imageViewBack.setFitWidth(20);

        backButton.setGraphic(imageViewBack);
        backButton.setOnMouseEntered(event -> {
            backButton.setTooltip(new Tooltip("Torna indietro"));
        });
        backButton.setOnMouseExited(event -> {
            backButton.setTooltip(null);
        });

        imageVisibility = new Image(getClass().getResource("/clientES/images/visibility.png").toExternalForm());
        imageNotVisibility = new Image(getClass().getResource("/clientES/images/notVisibility.png").toExternalForm());
        imageViewToggle.setImage(imageVisibility);
        imageViewToggle.setFitHeight(20);
        imageViewToggle.setFitWidth(20);

        visibilityButton.setGraphic(imageViewToggle);

        Font defaultFont = new Font(20.0);

        nextButton.setOnMouseEntered(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                nextButton.setFont(new Font(19.0));
            }
        });
        nextButton.setOnMouseExited(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                nextButton.setFont(defaultFont);
            }
        });

        passwordField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue.isEmpty()) {
                strengthBar.setVisible(false);
                strengthLabel.setVisible(true);
            } else {
                strengthBar.setVisible(true);
                strengthLabel.setVisible(false);
            }
        });

        strengthBar.progressProperty().bind(Bindings.createDoubleBinding(() -> calculatePasswordStrength(passwordField.getText()), passwordField.textProperty()));
        strengthBar.styleProperty().bind(Bindings.createStringBinding(() -> {
            double strength = calculatePasswordStrength(passwordField.getText());
            if (strength < 0.25) {
                return "-fx-accent: red;";
            } else if (strength < 0.5) {
                return "-fx-accent: orange;";
            } else if (strength < 0.75) {
                return "-fx-accent: lightgreen;";
            } else {
                return "-fx-accent: green;";
            }
        }, passwordField.textProperty()));
        strengthLabel.styleProperty().bind(Bindings.createStringBinding(() -> {
            double strength = calculatePasswordStrength(passwordField.getText());
            if (strength < 0.25) {
                return "-fx-text-fill: red; -fx-font-family: 'Calibri'; -fx-font-size: 20px;";
            } else if (strength < 0.5) {
                return "-fx-text-fill: orange; -fx-font-family: 'Calibri'; -fx-font-size: 20px;";
            } else if (strength < 0.75) {
                return "-fx-text-fill: lightgreen; -fx-font-family: 'Calibri'; -fx-font-size: 20px;";
            } else {
                return "-fx-text-fill: green; -fx-font-family: 'Calibri'; -fx-font-size: 20px;";
            }
        }, passwordField.textProperty()));
    }
    /**
     * This method calculates the strength of a password.
     *
     * @param password The password to calculate the strength for.
     * @return A value representing the strength of the password (between 0.0 and 1.0).
     */
    private double calculatePasswordStrength(String password) {
        int length = password.length();
        if (length == 0) {
            strengthLabel.setText("");
            return 0.0;
        } else if (length >= 1 && length < 6) {
            strengthLabel.setText("Molto debole");
            return 0.2;
        } else if (length >= 6 && length < 8) {
            strengthLabel.setText("Debole");
            return 0.2;
        } else if (length >= 8 && length < 9) {
            strengthLabel.setText("Media");
            return 0.4;
        } else if (length >= 9 && length < 11) {
            strengthLabel.setText("Buona");
            return 0.7;
        } else {
            strengthLabel.setText("Forte");
            return 0.8;
        }
    }
    /**
     * This method sets the application instance for this controller.
     * @param application The ClientES instance representing the application.
     */
    public void setApplication(ClientES application) {
        this.application = application;
    }
    /**
     * This method handles the action event triggered when the back button is clicked.
     * It switches the application view to the home screen.
     *
     * @param event The action event triggered by clicking the back button.
     */
    @FXML
    protected void onBackButtonClick(ActionEvent event) {
        if (application != null) {
            application.switchToHome();
        }
    }
    /**
     * This method toggles the visibility of the password field.
     * When the visibility button is clicked, it switches between showing the password as plain text and hiding it.
     *
     * @param event The action event triggered by clicking the visibility button.
     */
    @FXML
    protected void togglePasswordVisibility(ActionEvent event) {
        if (imageViewToggle.getImage() == imageVisibility) {
            imageViewToggle.setImage(imageNotVisibility);
            passwordVisible.setVisible(true);
            passwordField.setVisible(false);

            if(!passwordVisible.getText().equals(passwordField.getText())){
                passwordVisible.setText(passwordField.getText());
            }
        } else {
            imageViewToggle.setImage(imageVisibility);
            passwordVisible.setVisible(false);
            passwordField.setVisible(true);

            if(!passwordVisible.getText().equals(passwordField.getText())){
                passwordField.setText(passwordVisible.getText());
            }
        }
    }
    /**
     * This method handles the action when the next button is clicked during the registration process.
     * It checks the validity of the entered username and password, then proceeds to the next registration step if conditions are met.
     * If the username is available and the password meets the requirements, it navigates to the next registration step.
     * Otherwise, it displays appropriate error messages.
     *
     * @param event The action event triggered by clicking the next button.
     */
    @FXML
    protected void onNextButtonClick(ActionEvent event) {
        String username = usernameField.getText();
        String password = "";

        if(!passwordVisible.isVisible()){
            password = passwordField.getText();
        } else {
            password = passwordVisible.getText();
        }

        if (!registrationService.firstUsernameCheck(username)) {
            errorLabel.setText("Compilare il campo username.");
            errorLabel.setVisible(true);
            errorRectangle.setVisible(true);
            dismissErrorButton.setVisible(true);
            return;
        }

        if (!registrationService.checkPassword(password)) {
            errorLabel.setText("La password inserita non rispetta i requisiti minimi");
            errorLabel.setVisible(true);
            errorRectangle.setVisible(true);
            dismissErrorButton.setVisible(true);
            return;
        }

        boolean canRegister = registrationService.canRegister(username);

        if (application != null && canRegister) {
            passwordVisible.setVisible(false);
            passwordField.setVisible(true);
            application.switchToRegistration2(username, password);
        } else {
            errorLabel.setText("Lo username scelto non è disponibile, si prega di riprovare");
            errorLabel.setVisible(true);
            errorRectangle.setVisible(true);
            dismissErrorButton.setVisible(true);
            return;
        }
    }
    /**
     * This method handles the action when the user clicks the button to navigate to the login page.
     * It switches the application view to the login page.
     *
     * @param event The action event triggered by clicking the button.
     */
    @FXML
    public void goToLoginPageButton(ActionEvent event) {
        if (application != null) {
            application.switchToLogin();
        }
    }
    /**
     * This method handles the action when the user clicks the button to dismiss error messages.
     * It hides the error message label and the error rectangle from the view.
     *
     * @param event The action event triggered by clicking the button.
     */
    @FXML
    protected void onDismissErrorButtonClick(ActionEvent event) {
        dismissErrorButton.setVisible(false);
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }
    /**
     * This method resets the previous error messages by hiding the error message label and the error rectangle from the view.
     */
    public void resetPreviusError() {
        dismissErrorButton.setVisible(false);
        errorLabel.setText("");
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }
    /**
     * This method clears the text fields for username and password.
     */
    public void cleanField() {
        usernameField.clear();
        passwordField.clear();
        passwordVisible.clear();
    }
}
