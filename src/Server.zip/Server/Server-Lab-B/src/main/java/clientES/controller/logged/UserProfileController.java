package clientES.controller.logged;

import clientES.ClientES;
import clientES.services.UserInfo_Service;
import commons.objects.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;

import java.io.IOException;
import java.rmi.NotBoundException;
import java.sql.SQLException;
/**
 * <p>This class is responsible for managing user profile-related functionalities..
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */
public class UserProfileController {
    /**
     * <code>application</code>
     * A reference to the main application instance, responsible for managing navigation between screens and user interactions.
     */
    @FXML
    private ClientES application;
    /**
     * <code>backButton</code>
     * A Button used for navigating back to the previous screen or view..
     */
    @FXML
    private Button backButton;
    /**
     * <code>imageView</code>
     * An ImageView object used for displaying an image, such as an arrow icon indicating navigation direction.
     */
    @FXML
    private ImageView imageView;
    /**
     * <code>imageLeftArrow</code>
     * An Image object representing the left arrow icon used for navigation.
     */
    private Image imageLeftArrow;
    /**
     * <code>saveDataButton</code>
     * The button used to save user data.
     */
    @FXML
    private Button saveDataButton;
    /**
     * <code>usernameField</code>
     * The text field for entering or displaying the username.
     */
    @FXML
    private TextField usernameField;
    /**
     * <code>fiscalCodeField</code>
     * The text field for entering or displaying the fiscal code.
     */
    @FXML
    private TextField fiscalCodeField;
    /**
     * <code>emailField</code>
     * The text field for entering or displaying the email address.
     */
    @FXML
    private TextField emailField;
    /**
     * <code>firstnameField</code>
     * The text field for entering or displaying the first name.
     */
    @FXML
    private TextField firstnameField;
    /**
     * <code>lastnameField</code>
     * The text field for entering or displaying the last name.
     */
    @FXML
    private TextField lastnameField;
    /**
     * <code>addressField</code>
     * The text field for entering or displaying the address.
     */
    @FXML
    private TextField addressField;
    /**
     * <code>dismissErrorButton</code>
     * The button used to dismiss error messages.
     */
    @FXML
    private Button dismissErrorButton;
    /**
     * <code>reservedAreaChoiceBox</code>
     * The choice box for selecting options in the reserved area.
     */
    @FXML
    private ChoiceBox<String> reservedAreaChoiceBox;

    /**
     * <code>errorLabel</code>
     * The label for displaying error messages.
     */
    @FXML
    private Label errorLabel;
    /**
     * <code>errorRectangle</code>
     * The rectangle used for styling error messages.
     */
    @FXML
    private Rectangle errorRectangle;
    /**
     * <code>userInfoService</code>
     * Service class for managing user information.
     */
    private UserInfo_Service userInfoService;
    /**
     * Initializes the UserProfileController.
     * This method initializes various components and sets up event listeners.
     */
    public void initialize() {
        if(userInfoService == null){
            userInfoService =  new UserInfo_Service();
        }

        imageLeftArrow = new Image(getClass().getResource("/clientES/images/leftArrow.png").toExternalForm());
        if(imageView == null){
            imageView = new ImageView();
        }
        imageView.setImage(imageLeftArrow);
        imageView.setFitHeight(20);
        imageView.setFitWidth(20);

        backButton.setGraphic(imageView);
        backButton.setOnMouseEntered(event -> {
            backButton.setTooltip(new Tooltip("Torna indietro"));
        });
        backButton.setOnMouseExited(event -> {
            backButton.setTooltip(null);
        });
    }
    /**
     * This method sets the application instance for this controller.
     * @param application The ClientES instance representing the application.
     */
    public void setApplication(ClientES application) {
        this.application = application;
    }
    /**
     * This method handles the action event when the back button is clicked.
     * It navigates the user to the home page.
     * @param event The ActionEvent triggered by clicking the back button.
     */
    @FXML
    protected void onBackButtonClick(ActionEvent event) {
        if(application != null) {
            application.switchToHomeLogged();
        }
    }
    /**
     * This method handles the action event when the save data button is clicked.
     * It attempts to save the user's data after validation.
     * @param event The ActionEvent triggered by clicking the save data button.
     * @throws SQLException if there is an error while accessing the database.
     * @throws NotBoundException if a remote object lookup fails.
     * @throws IOException if an I/O error occurs.
     */
    @FXML
    protected void saveData(ActionEvent event) throws SQLException, NotBoundException, IOException {
        String fiscalCode = fiscalCodeField.getText();
        String email = emailField.getText();
        String firstName = firstnameField.getText();
        String lastName = lastnameField.getText();
        String address = addressField.getText();

        String updateError = userInfoService.checkUserInfo(fiscalCode, email, firstName, lastName, address);
        Paint rectangleColor = Paint.valueOf("#ff9393");
        Paint dismissButtonColor = Paint.valueOf("#cc0000");

        if(updateError == null){
            boolean isUserUpdated = userInfoService.updateUser(application.getUser(), fiscalCode, email, firstName, lastName, address);

            if(isUserUpdated){
                User updatedUser = userInfoService.loadUser(this.application.getUser().getUserId());
                this.application.setUser(updatedUser);

                rectangleColor = Paint.valueOf("#80FF7C");
                dismissButtonColor = Paint.valueOf("#2ECC1C");
                errorLabel.setText("Aggiornamento dei dati avvenuto con successo!");
            } else {
                errorLabel.setText("C'è stato un errore durante l'aggiornamento, riprova.");
            }
        } else {
            errorLabel.setText(updateError);
        }

        errorRectangle.setFill(rectangleColor);
        dismissErrorButton.setTextFill(dismissButtonColor);

        errorLabel.setVisible(true);
        dismissErrorButton.setVisible(true);
        errorRectangle.setVisible(true);
    }
    /**
     * Loads user data into the corresponding fields.
     * This method populates the text fields with the user's data.
     */
    public void loadUserData(){
        fiscalCodeField.setText(this.application.getUser().getFiscalCode());
        emailField.setText(this.application.getUser().getEmail());
        firstnameField.setText(this.application.getUser().getFirstName());
        lastnameField.setText(this.application.getUser().getLastName());
        usernameField.setText(this.application.getUser().getUsername());

        String address = this.application.getUser().getAddress().toString();
        addressField.setText(address);
    }
    /**
     * Clears the selection of the reserved area choice box.
     * This method deselects any currently selected option.
     */
    public void clearChoiceBoxSelection() {
        if (reservedAreaChoiceBox != null) {
            reservedAreaChoiceBox.getSelectionModel().clearSelection();
        }
    }
    /**
     * Handles the selection of options in the reserved area choice box.
     * This method performs different actions based on the selected option.
     * @param event The ActionEvent triggered by selecting an option in the choice box.
     */
    @FXML
    protected void reservedAreaOptions(ActionEvent event) {
        String selectedOption = reservedAreaChoiceBox.getValue();
        clearChoiceBoxSelection();
        
        if(selectedOption == null){
            return;
        } else if(application != null && selectedOption.equals("Il mio profilo")){
            application.switchToUserProfile();
        } else if(application != null && selectedOption.equals("Modifica password")){
            application.switchToChangePassword();
        } else if(application != null && selectedOption.equals("Le mie playlist")){
            application.switchToUserPlaylist();
        } else if(application != null && selectedOption.equals("Le mie valutazioni")){
            application.switchToUserFeedback();
        } else if(application != null && selectedOption.equals("Logout")){
            application.logout();
        }
    }
    /**
     * Handles the action event when the dismiss error button is clicked.
     * This method hides the error message.
     * @param event The ActionEvent triggered by clicking the dismiss error button.
     */
    @FXML
    protected void onDismissErrorButtonClick(ActionEvent event) {
        dismissErrorButton.setVisible(false);
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }
    /**
     * Resets the initial configuration of the error message display.
     * This method hides the error message and resets the error message color.
     */
    public void resetInitConfiguration(){
        errorRectangle.setFill(Paint.valueOf("#ff9393"));
        dismissErrorButton.setTextFill(Paint.valueOf("#cc0000"));

        dismissErrorButton.setVisible(false);
        errorLabel.setText("");
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }

}
