package clientES.services;

import commons.objects.Song;

import java.util.ArrayList;
import java.util.List;
/**
 * <p>This class provides services for searching songs.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */
public class Search_Service {
    /**
     * <code>clientHandler</code>
     * An instance of ClientHandler used for communication with the server.
     */
    private ClientHandler clientHandler;
    /**
     * Constructs a new Search_Service and initializes the client handler.
     */
    public Search_Service(){
        try {
            clientHandler = ClientHandler.getInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    /**
     * Searches for musical tracks based on the provided query and search type.
     *
     * @param q          The query string.
     * @param searchType The type of search to perform.
     * @return A list of Song objects matching the search criteria.
     */
    public List<Song> cercaBranoMusicale(String q, String searchType){
        List<Song> searchResult = new ArrayList<>();

        try {
            searchResult = clientHandler.cercaBranoMusicale(q, searchType);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return searchResult;
    }

}
