package clientES.controller.logged;

import clientES.ClientES;
import commons.objects.Emotions;
import clientES.services.UserInfo_Service;
import commons.objects.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;

import java.io.IOException;
import java.net.URL;
import java.rmi.NotBoundException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.function.UnaryOperator;
import java.util.regex.Pattern;
/**
 * <p>This class manages the feedback list view, allowing users to view, update, and remove their feedback entries.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class FeedbackListController implements Initializable {
    /**
     * <code>application</code>
     * A reference to the main application instance, responsible for managing navigation between screens and user interactions.
     */
    @FXML
    private ClientES application;
    /**
     * <code>reservedAreaChoiceBox</code>
     * A ChoiceBox used for selecting options related to the user's reserved area.
     */
    @FXML private ChoiceBox<String> reservedAreaChoiceBox;
    /**
     * <code>usernameLabel</code>
     * A Label used for displaying the username of the currently logged-in user.
     */
    @FXML private Label usernameLabel;
    /**
     * <code>backButton</code>
     * A Button used for navigating back to the previous screen or view..
     */
    @FXML private Button backButton;
    /**
     * <code>imageView</code>
     * An ImageView object used for displaying an image, such as an arrow icon indicating navigation direction.
     */
    @FXML private ImageView imageView;
    /**
     * <code>imageLeftArrow</code>
     * An Image object representing the left arrow icon used in the user interface.
     */
    @FXML private Image imageLeftArrow;

    /**
     * <code>updateFeedback</code>
     * A Button used for updating user feedback information.
     */
    @FXML private Button updateFeedback;

    /**
     * <code>removeFeedback</code>
     * A Button used for removing user feedback.
     */
    @FXML private Button removeFeedback;

    /**
     * <code>feedbackDetails</code>
     * A Label used for displaying detailed information about user feedback.
     */
    @FXML private Label feedbackDetails;

    /**
     * <code>songLabel</code>
     * A Label used for displaying the label "Song" in the user interface.
     */
    @FXML private Label songLabel;

    /**
     * <code>scoreLabel</code>
     * A Label used for displaying the label "Score" in the user interface.
     */
    @FXML private Label scoreLabel;

    /**
     * <code>emotionListLabel</code>
     * A Label used for displaying the label "Emotion List" in the user interface.
     */
    @FXML private Label emotionListLabel;

    /**
     * <code>noteLabel</code>
     * A Label used for displaying the label "Note" in the user interface.
     */
    @FXML private Label noteLabel;

    /**
     * <code>songField</code>
     * A TextField used for displaying and entering information about the song related to the user feedback.
     */
    @FXML private TextField songField;

    /**
     * <code>scoreField</code>
     * A TextField used for displaying and entering the score of the user feedback.
     */
    @FXML private TextField scoreField;

    /**
     * <code>noteField</code>
     * A TextArea used for displaying and entering additional notes related to the user feedback.
     */
    @FXML private TextArea noteField;

    /**
     * <code>emotionListChoiceBox</code>
     * A ChoiceBox used for selecting the emotion associated with the user feedback.
     */
    @FXML private ChoiceBox<String> emotionListChoiceBox;

    /**
     * <code>feedbackTable</code>
     * A TableView used for displaying a list of user feedback entries.
     */
    @FXML public TableView<UserFeedback> feedbackTable;

    /**
     * <code>dismissErrorButton</code>
     * A Button used for dismissing error messages or notifications.
     */
    @FXML private Button dismissErrorButton;
    /**
     * <code>errorLabel</code>
     * A Label used for displaying error messages to the user.
     */
    @FXML private Label errorLabel;
    /**
     * <code>errorRectangle</code>
     * A Rectangle used for displaying error messages or notifications in the user interface.
     */
    @FXML private Rectangle errorRectangle;

    /**
     * <code>selectedUserFeedback</code>
     * A reference to the currently selected user feedback entry in the feedback table.
     */
    private UserFeedback selectedUserFeedback;

    /**
     * <code>userInfoService</code>
     * An instance of the UserInfo_Service class used for performing operations related to user information and feedback.
     */
    private UserInfo_Service userInfoService;
    /**
     * Initializes the FeedbackListController.
     * It sets up the initial configuration of the user interface components and populates the feedback table with data.
     *
     * @param location  The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param rb        The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL location, ResourceBundle rb) {
        if(userInfoService == null){
            userInfoService = new UserInfo_Service();
        }

        imageLeftArrow = new Image(getClass().getResource("/clientES/images/leftArrow.png").toExternalForm());
        imageView.setImage(imageLeftArrow);
        imageView.setFitHeight(20);
        imageView.setFitWidth(20);

        backButton.setGraphic(imageView);
        backButton.setOnMouseEntered(event -> {
            backButton.setTooltip(new Tooltip("Torna indietro"));
        });
        backButton.setOnMouseExited(event -> {
            backButton.setTooltip(null);
        });

        if(application != null && application.getUser() != null) {
            usernameLabel.setText(application.getUser().getUsername());
        }

        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (newText.isEmpty()) {
                return change;
            }
            if (Pattern.matches("\\d*", newText)) {
                return change;
            }
            return null; // Rejected
        };

        // Applica il filtro al TextFormatter
        TextFormatter<String> textFormatter = new TextFormatter<>(filter);
        scoreField.setTextFormatter(textFormatter);

        configureTableColumns();
        refreshTableData(true);
        configureTableEvents();
        setFeedbackDetailsVisibility(false);
        resetMessageInitConfig();
    }
    /**
     * This method configures the columns of the feedback table.
     * It sets up the columns for the feedback table, specifying their headers, cell value factories,
     * and preferred widths.
     */
    private void configureTableColumns() {
        TableColumn<UserFeedback, String> songCol = new TableColumn<>("CANZONE");
        TableColumn<UserFeedback, String> scoreCol = new TableColumn<>("VALUTAZIONE");
        TableColumn<UserFeedback, String> emotionCol = new TableColumn<>("EMOZIONE");
        TableColumn<UserFeedback, String> noteCol = new TableColumn<>("NOTE");

        songCol.setCellValueFactory(cellData -> new SimpleStringProperty(
                cellData.getValue().getSong().getTitle() + "(" + cellData.getValue().getSong().getAuthor()  + ")"
        ));
        scoreCol.setCellValueFactory(cellData -> new SimpleStringProperty("" + cellData.getValue().getScore()));
        emotionCol.setCellValueFactory(cellData -> new SimpleStringProperty(
                cellData.getValue().getEmotion() == null ? "" : cellData.getValue().getEmotion().getName()
        ));
        noteCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getNote()));

        songCol.setPrefWidth(200);
        scoreCol.setPrefWidth(125);
        emotionCol.setPrefWidth(100);
        noteCol.setPrefWidth(250);

        feedbackTable.getColumns().addAll(songCol, scoreCol, emotionCol, noteCol);
    }
    /**
     * This method refreshes the data displayed in the feedback table.
     * It retrieves the user feedback data from the application and updates the table accordingly.
     *
     * @param tableNeedReload A boolean indicating whether the table needs to be reloaded with fresh data.
     */
    public void refreshTableData(boolean tableNeedReload) {
        List<UserFeedback> feedbackList = new ArrayList<>();

        if(this.application != null && this.application.getUser() != null && tableNeedReload) {
            try {
                userInfoService.loadUserFeedback(this.application.getUser());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

            feedbackList = this.application.getUser().getUserFeedback();
        }

        ObservableList<UserFeedback> resultsData = FXCollections.observableArrayList(feedbackList);
        feedbackTable.setItems(resultsData);
    }
    /**
     * This method configures event handling for the feedback table.
     * It sets up an event handler to detect double clicks on table rows.
     */
    private void configureTableEvents() {
        feedbackTable.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2 && feedbackTable.getSelectionModel().getSelectedItem() != null) {
                handleTableDoubleClick(feedbackTable.getSelectionModel().getSelectedItem());
            }
        });
    }
    /**
     * This method handles double-click events on table rows.
     * It is called when a double-click event occurs on a row in the feedback table.
     * It retrieves the selected feedback item and displays its details.
     *
     * @param selectedFeedback The UserFeedback object corresponding to the selected table row.
     */
    private void handleTableDoubleClick(UserFeedback selectedFeedback) {
        if (application != null) {
            try {
                feelFeedbackDetailsInfo(selectedFeedback);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
    /**
     * This method displays details of the selected feedback.
     * It populates the UI components with information about the selected feedback item.
     *
     * @param selectedFeedback The UserFeedback object representing the selected feedback.
     */
    private void feelFeedbackDetailsInfo(UserFeedback selectedFeedback){
        selectedUserFeedback = selectedFeedback;

        songField.setText(
                selectedFeedback.getSong().getTitle() + "(" + selectedFeedback.getSong().getAuthor()  + ")"
        );

        scoreField.setText("" + selectedFeedback.getScore());
        noteField.setText(selectedFeedback.getNote());

        ObservableList<String> emotionList = FXCollections.observableArrayList();
        for(Emotion emotion : Emotions.getEmotionMap().values()){
            String eName = emotion.getEmotionId() + " - " + emotion.getName()
                    + "(" + emotion.getDescription() + ")";
            emotionList.add(eName);
        }
        emotionListChoiceBox.setItems(emotionList);

        String selectedFeedbackName = selectedFeedback.getEmotion().getEmotionId() + " - "
                + selectedFeedback.getEmotion().getName()
                + "(" + selectedFeedback.getEmotion().getDescription() + ")";
        emotionListChoiceBox.setValue(selectedFeedbackName);

        setFeedbackDetailsVisibility(true);
    }
    /**
     * This method sets the visibility of the feedback details section in the UI.
     * It controls the visibility of labels, text fields, and buttons related to feedback details.
     *
     * @param visibility A boolean value indicating whether to make the feedback details section visible.
     */
    public void setFeedbackDetailsVisibility(boolean visibility){
        feedbackDetails.setVisible(visibility);
        songLabel.setVisible(visibility);
        scoreLabel.setVisible(visibility);
        emotionListLabel.setVisible(visibility);
        noteLabel.setVisible(visibility);
        songField.setVisible(visibility);
        scoreField.setVisible(visibility);
        noteField.setVisible(visibility);
        emotionListChoiceBox.setVisible(visibility);
        removeFeedback.setVisible(visibility);
        updateFeedback.setVisible(visibility);
    }
    /**
     * This method handles the action event triggered when the back button is clicked.
     * It navigates back to the home screen of the application.
     *
     * @param event The ActionEvent triggered by clicking the back button.
     */
    @FXML
    protected void onBackButtonClick(ActionEvent event) {
        if(application != null) {
            application.switchToHomeLogged();
        }
    }
    /**
     * This method sets the ClientES application instance for the controller.
     *
     * @param application The ClientES object representing the application instance.
     */

    public void setApplication(ClientES application) {
        this.application = application;
    }
    /**
     * This method sets the text of the username label in the UI.
     * It updates the label with the specified text.
     *
     * @param text The text to be set as the username label's text.
     */
    public void setUsernameLabelText(String text){
        if(usernameLabel == null){
            usernameLabel = new Label();
        }
        usernameLabel.setText(text);
    }
    /**
     * This method handles the selection of options in the reserved area choice box.
     * It switches to different views based on the selected option.
     *
     * @param event The ActionEvent triggered by selecting an option in the choice box.
     */
    @FXML
    protected void reservedAreaOptions(ActionEvent event) {
        String selectedOption = reservedAreaChoiceBox.getValue();
        clearChoiceBoxSelection();
        
        if(selectedOption == null){
            return;
        } else if(application != null && selectedOption.equals("Il mio profilo")){
            application.switchToUserProfile();
        } else if(application != null && selectedOption.equals("Modifica password")){
            application.switchToChangePassword();
        } else if(application != null && selectedOption.equals("Le mie playlist")){
            application.switchToUserPlaylist();
        } else if(application != null && selectedOption.equals("Le mie valutazioni")){
            application.switchToUserFeedback();
        } else if(application != null && selectedOption.equals("Logout")){
            application.logout();
        }
    }
    /**
     * This method handles the action event triggered when the remove feedback button is clicked.
     * It removes the selected feedback item from the user's feedback list.
     *
     * @throws SQLException       If an SQL error occurs while accessing the database.
     * @throws NotBoundException  If a remote object is not bound to the specified name in the registry.
     * @throws IOException        If an I/O error occurs while performing the operation.
     */
    @FXML
    public void removeFeedback() throws SQLException, NotBoundException, IOException {
        boolean isDeleted = userInfoService.deleteUserFeedback(selectedUserFeedback);
        if(isDeleted) {
            errorRectangle.setFill(Paint.valueOf("#80FF7C"));
            dismissErrorButton.setTextFill(Paint.valueOf("#2ECC1C"));
            errorLabel.setText("Cancellazione dei dati avvenuto con successo!");

            refreshTableData(true);
            selectedUserFeedback = new UserFeedback();
            setFeedbackDetailsVisibility(false);
        } else {
            errorLabel.setText("Qualcosa è andato storto, riprovare.");
        }

        errorLabel.setVisible(true);
        dismissErrorButton.setVisible(true);
        errorRectangle.setVisible(true);
    }
    /**
     * This method handles the action event triggered when the update feedback button is clicked.
     * It updates the details of the selected feedback item with the values entered in the UI components.
     *
     * @throws SQLException       If an SQL error occurs while accessing the database.
     * @throws NotBoundException  If a remote object is not bound to the specified name in the registry.
     * @throws IOException        If an I/O error occurs while performing the operation.
     */

    @FXML
    public void updateFeedback() throws SQLException, NotBoundException, IOException {
        boolean needUpdate = false;
        if (Integer.valueOf(scoreField.getText()) < 1 ||  Integer.valueOf(scoreField.getText()) > 5) {
            errorLabel.setText("La valutazione deve essere un valore compreso tra 0 e 5 ");
            errorLabel.setVisible(true);
            dismissErrorButton.setVisible(true);
            errorRectangle.setVisible(true);
            return;
        } else if (!Integer.valueOf(scoreField.getText()).equals(Integer.valueOf(selectedUserFeedback.getScore()))) {
            selectedUserFeedback.setScore(Integer.valueOf(scoreField.getText()));
            needUpdate = true;
        }

        String emLabel = selectedUserFeedback.getEmotion().getEmotionId() + " - "
                + selectedUserFeedback.getEmotion().getName()
                + "(" + selectedUserFeedback.getEmotion().getDescription() + ")";

        if (!emLabel.equals(emotionListChoiceBox.getValue())) {
            Long newEmotionId = Long.valueOf(emotionListChoiceBox.getValue().split(" - ")[0]);
            Emotion newEmotion = Emotions.getEmotionMap().get(newEmotionId);
            selectedUserFeedback.setEmotion(newEmotion);
            needUpdate = true;
        }

        if (noteField.getText() != null && selectedUserFeedback.getNote() != null
                && !noteField.getText().equals(selectedUserFeedback.getNote())){
            String note = noteField.getText();
            if(noteField.getText().length() > 256){
                note = note.substring(0, 255);
            }
            selectedUserFeedback.setNote(note);
            needUpdate = true;
        }

        if(needUpdate) {
            boolean isUpdated = userInfoService.updateUserFeedback(selectedUserFeedback);
            if (isUpdated) {
                errorRectangle.setFill(Paint.valueOf("#80FF7C"));
                dismissErrorButton.setTextFill(Paint.valueOf("#2ECC1C"));
                errorLabel.setText("Aggiornamento dei dati avvenuto con successo!");
                refreshTableData(true);
                feelFeedbackDetailsInfo(selectedUserFeedback);
            } else {
                errorLabel.setText("Qualcosa è andato storto, riprovare.");
            }
        } else {
            errorRectangle.setFill(Paint.valueOf("#FFE32F"));
            dismissErrorButton.setTextFill(Paint.valueOf("#FFB704"));
            errorLabel.setText("Non è necessario nessun aggiornamento!");
        }

        errorLabel.setVisible(true);
        dismissErrorButton.setVisible(true);
        errorRectangle.setVisible(true);
    }
    /**
     * This method handles the action event triggered when the dismiss error button is clicked.
     * It resets the error message display to its initial configuration, hiding the error message and button.
     *
     * @param event The ActionEvent triggered by clicking the dismiss error button.
     */
    @FXML
    protected void onDismissErrorButtonClick(ActionEvent event) {
        resetMessageInitConfig();
    }
    /**
     * This method resets the initial configuration of the error message display.
     * It hides the error message label, dismiss button, and error rectangle.
     */
    public void resetMessageInitConfig() {
        errorRectangle.setFill(Paint.valueOf("#ff9393"));
        dismissErrorButton.setTextFill(Paint.valueOf("#cc0000"));

        dismissErrorButton.setVisible(false);
        errorLabel.setText("");
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }
    /**
     * This method clears the selection of the choice box for reserved area options.
     * It deselects any currently selected option in the choice box.
     */
    public void clearChoiceBoxSelection() {
        if (reservedAreaChoiceBox != null) {
            reservedAreaChoiceBox.getSelectionModel().clearSelection();
        }
    }
}
