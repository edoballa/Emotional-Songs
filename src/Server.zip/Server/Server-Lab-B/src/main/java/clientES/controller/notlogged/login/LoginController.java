package clientES.controller.notlogged.login;

import clientES.ClientES;
import clientES.services.Login_Service;
import commons.objects.User;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;

import java.io.IOException;
import java.rmi.NotBoundException;
import java.sql.SQLException;
/**
 * <p>This class is responsible for managing the login functionality.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class LoginController {
    /**
     * The text field for entering the username.
     * <code>usernameField</code>
     */
    @FXML private TextField usernameField;

    /**
     * The text field for entering the password, visible to the user.
     * <code>passwordVisible</code>
     */
    @FXML private TextField passwordVisible;

    /**
     * The password field for entering the password, masked.
     * <code>passwordField</code>
     */
    @FXML private PasswordField passwordField;

    /**
     * The toggle button to switch password visibility.
     * <code>visibilityButton</code>
     */
    @FXML private ToggleButton visibilityButton;

    /**
     * The image view for displaying the toggle button icon.
     * <code>imageViewToggle</code>
     */
    @FXML private ImageView imageViewToggle;

    /**
     * The image representing the visibility icon.
     * <code>imageVisibility</code>
     */
    @FXML private Image imageVisibility;

    /**
     * The image representing the non-visibility icon.
     * <code>imageNotVisibility</code>
     */
    @FXML private Image imageNotVisibility;

    /**
     * The button used for initiating the login process.
     * <code>loginButton</code>
     */
    @FXML private Button loginButton;
    /**
     * <code>backButton</code>
     * A Button used for navigating back to the previous screen or view..
     */
    @FXML private Button backButton;
    /**
     * <code>dismissErrorButton</code>
     * A Button used for dismissing error messages or notifications.
     */
    @FXML private Button dismissErrorButton;
    /**
     * <code>errorLabel</code>
     * A Label used for displaying error messages to the user.
     */
    @FXML private Label errorLabel;
    /**
     * The rectangle used for displaying error messages.
     * <code>errorRectangle</code>
     */
    @FXML private Rectangle errorRectangle;
     /**
     * <code>imageView</code>
     * An ImageView object used for displaying an image, such as an arrow icon indicating navigation direction.
     */
    /**
     * The image view used for displaying an image, such as an arrow icon indicating navigation direction.
     * <code>imageView</code>
     */
    @FXML private ImageView imageView;

    /**
     * The image representing the left arrow icon.
     * <code>imageLeftArrow</code>
     */
    @FXML private Image imageLeftArrow;

    /**
     * The instance of the ClientES application.
     * <code>application</code>
     */
    @FXML private ClientES application;

    /**
     * The service for handling login operations.
     * <code>loginService</code>
     */
    private Login_Service loginService = null;
    /**
     * This method sets the application instance for this controller.
     * @param application The ClientES instance representing the application.
     */
    public void setApplication(ClientES application) {
        this.application = application;
    }
    /**
     * Initializes the login controller.
     * This method sets up initial configurations and event handlers.
     */
    public void initialize() {
        if(loginService == null){
            loginService =  new Login_Service();
        }

        Font defaultFont = new Font(18.0);

        imageLeftArrow = new Image(getClass().getResource("/clientES/images/leftArrow.png").toExternalForm());
        if(imageView == null){
            imageView = new ImageView();
        }
        imageView.setImage(imageLeftArrow);
        imageView.setFitHeight(20);
        imageView.setFitWidth(20);

        backButton.setGraphic(imageView);
        backButton.setOnMouseEntered(event -> {
            backButton.setTooltip(new Tooltip("Torna indietro"));
        });
        backButton.setOnMouseExited(event -> {
            backButton.setTooltip(null);
        });

        loginButton.setOnMouseEntered(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                loginButton.setFont(new Font(19.0));
            }
        });

        loginButton.setOnMouseExited(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                loginButton.setFont(defaultFont);
            }
        });

        dismissErrorButton.setVisible(false);
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);

        imageVisibility = new Image(getClass().getResource("/clientES/images/visibility.png").toExternalForm());
        imageNotVisibility = new Image(getClass().getResource("/clientES/images/notVisibility.png").toExternalForm());
        imageViewToggle.setImage(imageVisibility);
        imageViewToggle.setFitHeight(20);
        imageViewToggle.setFitWidth(20);
        visibilityButton.setGraphic(imageViewToggle);

        passwordVisible.setVisible(false);
        passwordField.setVisible(true);
    }
    /**
     * This method handles the action event when the back button is clicked.
     * It navigates the user to the home page.
     * @param event The ActionEvent triggered by clicking the back button.
     */
    @FXML
    protected void onBackButtonClick(ActionEvent event) {
        if(application != null) {
            application.switchToHome();
        }
    }
    /**
     * This method toggles the visibility of the password field.
     * It switches between displaying the password as plain text or masking it.
     * @param event The action event triggered by clicking the visibility toggle button.
     */
    @FXML
    protected void togglePasswordVisibility(ActionEvent event) {
        if (imageViewToggle.getImage() == imageVisibility) {
            imageViewToggle.setImage(imageNotVisibility);
            passwordVisible.setVisible(true);
            passwordField.setVisible(false);

            if(!passwordVisible.getText().equals(passwordField.getText())){
                passwordVisible.setText(passwordField.getText());
            }
        } else {
            imageViewToggle.setImage(imageVisibility);
            passwordVisible.setVisible(false);
            passwordField.setVisible(true);

            if(!passwordVisible.getText().equals(passwordField.getText())){
                passwordField.setText(passwordVisible.getText());
            }
        }
    }
    /**
     * This method handles the login button click event.
     * It retrieves the username and password entered by the user,
     * attempts to authenticate the user, and switches to the home screen if successful.
     * Otherwise, it displays an error message.
     * @param event The action event triggered by clicking the login button.
     * @throws SQLException if there is an SQL exception while accessing the database.
     * @throws NotBoundException if the login service is not bound properly.
     * @throws IOException if an I/O exception occurs while switching screens.
     */
    @FXML
    protected void onLoginButtonClick(ActionEvent event) throws SQLException, NotBoundException, IOException {
        String username = usernameField.getText();
        String password = "";

        if(!passwordVisible.isVisible()){
            password = passwordField.getText();
        } else {
            password = passwordVisible.getText();
        }

        //reset init config
        usernameField.clear();
        passwordField.clear();
        passwordVisible.clear();
        passwordVisible.setVisible(false);
        passwordField.setVisible(true);

        User user = loginService.login(username, password);

        if(user != null && user.getFirstName() != null && !user.getFirstName().isEmpty()){
            application.setUser(user);
            application.switchToHomeLogged();
        } else {
            errorLabel.setText("Username o Password errati");
            errorLabel.setVisible(true);
            dismissErrorButton.setVisible(true);
            errorRectangle.setVisible(true);
        }
    }
    /**
     * This method switches to the registration page.
     * @param event The action event triggered by clicking the registration button.
     */
    @FXML
    protected void goToRegistrationPage(ActionEvent event) {
        if(application != null) {
            application.switchToRegistration1();
        }
    }

    /**
     * This method handles the dismiss error button click event.
     * It hides the error message and notification rectangle.
     * @param event The action event triggered by clicking the dismiss error button.
     */
    @FXML
    protected void onDismissErrorButtonClick(ActionEvent event) {
        dismissErrorButton.setVisible(false);
        errorLabel.setText("");
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }
}
