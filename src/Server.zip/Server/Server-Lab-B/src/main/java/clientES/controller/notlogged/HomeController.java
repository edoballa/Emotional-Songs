package clientES.controller.notlogged;

import clientES.ClientES;
import clientES.services.Search_Service;
import commons.objects.Song;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;

import java.io.IOException;
import java.rmi.NotBoundException;
import java.util.List;
/**
 * <p>This class represents the controller for the home screen of the application.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */
public class HomeController {
    /**
     * <code>application</code>
     * A reference to the main application instance, responsible for managing navigation between screens and user interactions.
     */
    @FXML
    private ClientES application;
    /**
     * <code>subscribeButton</code>
     * A Button used for initiating the registration process.
     */
    @FXML
    private Button subscribeButton;
    /**
     * <code>loginButton</code>
     * A Button used for navigating to the login page.
     */
    @FXML
    private Button loginButton;
    /**
     * <code>searchField</code>
     * Represents a TextField used for entering search queries.
     */
    @FXML
    private TextField searchField;
    /**
     * <code>clearButton</code>
     * Represents a Button used to clear the text in the search field.
     */
    @FXML
    private Button clearButton;
    /**
     * <code>searchButton</code>
     * Represents a Button used to initiate the search operation.
     */
    @FXML
    private Button searchButton;
    /**
     * <code>imageClearView</code>
     * Represents an ImageView used to display an icon for clearing the search field.
     */
    @FXML
    private ImageView imageClearView;
    /**
     * <code>imageSearchView</code>
     * Represents an ImageView used to display an icon for initiating the search operation.
     */
    @FXML
    private ImageView imageSearchView;
    /**
     * <code>imageClear</code>
     * Represents an Image object used for the icon displayed in the clearButton.
     */
    private Image imageClear;
    /**
     * <code>imageSearch</code>
     * Represents an Image object used for the icon displayed in the searchButton.
     */
    private Image imageSearch;
    /**
     * <code>searchChoiceBox</code>
     * Represents a ChoiceBox used for selecting the type of search (e.g., by title, artist).
     */
    @FXML
    private ChoiceBox<String> searchChoiceBox;
    /**
     * <code>dismissErrorButton</code>
     * Represents a Button used to dismiss error messages or notifications.
     */
    @FXML
    private Button dismissErrorButton;
    /**
     * <code>errorLabel</code>
     * Represents a Label used for displaying error messages to the user.
     */
    @FXML
    private Label errorLabel;
    /**
     * <code>errorRectangle</code>
     * Represents a Rectangle used as a visual indicator for error messages or notifications.
     */
    @FXML
    private Rectangle errorRectangle;
    /**
     * <code>searchService</code>
     * Represents an instance of the Search_Service class responsible for handling search operations.
     */
    private Search_Service searchService;
    /**
     * This method initializes the controller by setting up event handlers and initializing UI components.
     */
    public void initialize() {
        Font defaultFont = new Font(22.0);

        if(searchService == null){
            searchService = new Search_Service();
        }

        subscribeButton.setOnMouseEntered(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                subscribeButton.setTextFill(Color.WHITE);
                subscribeButton.setFont(new Font(23.0));
                subscribeButton.setPrefHeight(43.0);
                subscribeButton.setPrefWidth(97.0);
            }
        });

        loginButton.setOnMouseEntered(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                loginButton.setFont(new Font(23.0));
                loginButton.setPrefHeight(43.0);
                loginButton.setPrefWidth(97.0);
            }
        });

        subscribeButton.setOnMouseExited(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                subscribeButton.setTextFill(Color.web("#d2d2d2"));
                subscribeButton.setFont(defaultFont);
                subscribeButton.setPrefHeight(41.0);
                subscribeButton.setPrefWidth(95.0);
            }
        });

        loginButton.setOnMouseExited(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                loginButton.setFont(defaultFont);
                loginButton.setPrefHeight(41.0);
                loginButton.setPrefWidth(95.0);
            }
        });

        imageClear = new Image(getClass().getResource("/clientES/images/clear.png").toExternalForm());
        if(imageClearView == null){
            imageClearView = new ImageView();
        }
        imageClearView.setImage(imageClear);
        imageClearView.setFitHeight(20);
        imageClearView.setFitWidth(20);

        clearButton.setGraphic(imageClearView);

        imageSearch = new Image(getClass().getResource("/clientES/images/search.png").toExternalForm());
        if(imageSearchView == null){
            imageSearchView = new ImageView();
        }
        imageSearchView.setImage(imageSearch);
        imageSearchView.setFitHeight(20);
        imageSearchView.setFitWidth(20);

        searchButton.setGraphic(imageSearchView);
        searchChoiceBox.setValue("Titolo");
    }
    /**
     * <code>searchField</code>
     * Clears the text in the search field.
     */
    @FXML
    private void clearTextField() {
        searchField.clear();
    }
    /**
     * <code>onSubscribeButtonClick</code>
     * Handles the action event when the user clicks on the subscribe button.
     *
     * @param event The action event triggered by the button click.
     */
    @FXML
    protected void onSubscribeButtonClick(ActionEvent event) {
        if(application != null) {
            application.switchToRegistration1();
        }
    }
    /**
     * <code>onLoginButtonClick</code>
     * Handles the action event when the user clicks on the login button.
     *
     * @param event The action event triggered by the button click.
     * @throws NotBoundException If the ClientES application is not bound.
     * @throws IOException      If an I/O error occurs.
     */
    @FXML
    protected void onLoginButtonClick(ActionEvent event) throws NotBoundException, IOException {
        if(application != null) {
            application.switchToLogin();
        }
    }
    /**
     * <code>cercaBranoMusicale</code>
     * Handles the action event when the user clicks on the search button to search for music.
     * Validates the search query and search type before initiating the search process.
     * Displays error messages if the search query or search type is invalid.
     *
     * @param event The action event triggered by clicking the search button.
     * @throws NotBoundException If the ClientES application is not bound.
     * @throws IOException      If an I/O error occurs.
     */
    @FXML
    protected void cercaBranoMusicale(ActionEvent event) throws NotBoundException, IOException {
        String q = searchField.getText();
        String searchType = searchChoiceBox.getValue();

        if(q.length() < 3) {
            errorLabel.setText("ERRORE! Inserisci almeno 3 caratteri nella barra di ricerca");
            errorLabel.setVisible(true);
            dismissErrorButton.setVisible(true);
            errorRectangle.setVisible(true);
            return;
        } else if(searchType == null || searchType.isEmpty()) {
            errorLabel.setText("ERRORE! Seleziona una tipologia di ricerca");
            errorLabel.setVisible(true);
            dismissErrorButton.setVisible(true);
            errorRectangle.setVisible(true);
            return;
        } else if(q.split(",").length != searchType.split(",").length) {
            errorLabel.setText("ERRORE! La barra di ricerca deve contenere una ricerca della tipologia selezionata");
            errorLabel.setVisible(true);
            dismissErrorButton.setVisible(true);
            errorRectangle.setVisible(true);
            return;
        } else if(q.split(",").length > 1) {
            for (String s : q.split(",")){
                if(s.length() < 3){
                    errorLabel.setText("ERRORE! Inserisci almeno 3 caratteri per settore di ricerca nella barra");
                    errorLabel.setVisible(true);
                    dismissErrorButton.setVisible(true);
                    errorRectangle.setVisible(true);
                    return;
                }
            }
        }

        List<Song> searchResult = searchService.cercaBranoMusicale(q, searchType);
        application.switchToSearchResults(searchResult, q);
    }
    /**
     * This method sets the main application instance.
     *
     * @param application The main application instance.
     */
    public void setApplication(ClientES application) {
        this.application = application;
    }
    /**
     * This method handles the action event when the dismiss error button is clicked.
     * It hides the error message and error rectangle from the user interface.
     *
     * @param event The action event triggered by clicking the dismiss error button.
     */
    @FXML
    protected void onDismissErrorButtonClick(ActionEvent event) {
        dismissErrorButton.setVisible(false);
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }
    /**
     * This method resets the previous error state by hiding the error message, dismiss error button,
     * and error rectangle from the user interface.
     */
    public void resetPreviusError(){
        dismissErrorButton.setVisible(false);
        errorLabel.setText("");
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }
}
