package clientES.controller.logged;

import clientES.ClientES;
import clientES.services.Search_Service;
import commons.objects.Song;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Rectangle;

import java.io.IOException;
import java.rmi.NotBoundException;
import java.util.List;
/**
 * <p>This class is responsible for handling the home screen for logged-in users.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class HomeLoggedController {
    /**
     * <code>usernameLabel</code>
     * A Label used for displaying the username of the currently logged-in user.
     */
    @FXML
    private Label usernameLabel;
    /**
     * <code>application</code>
     * A reference to the main application instance, responsible for managing navigation between screens and user interactions.
     */
    @FXML
    private ClientES application;
    /**
     * <code>searchField</code>
     * The text field used for entering search queries.
     */
    @FXML
    private TextField searchField;

    /**
     * <code>clearButton</code>
     * A Button used to clear the contents of the search field.
     */
    @FXML
    private Button clearButton;
    /**
     * <code>searchButton</code>
     * A Button used to initiate a search operation.
     */
    @FXML
    private Button searchButton;
    /**
     * <code>reservedAreaOptionsButton</code>
     * A Button used to access reserved area options.
     */
    @FXML
    private Button reservedAreaOptionsButton;
    /**
     * <code>imageClearView</code>
     * An ImageView displaying the clear icon for the search field.
     */
    @FXML
    private ImageView imageClearView;
    /**
     * <code>imageSearchView</code>
     * An ImageView displaying the search icon for initiating search operations.
     */
    @FXML
    private ImageView imageSearchView;
    /**
     * <code>reservedAreaChoiceBox</code>
     * A ChoiceBox for selecting options related to the user's reserved area.
     */
    @FXML
    private ChoiceBox<String> reservedAreaChoiceBox;
    /**
     * <code>searchChoiceBox</code>
     * A ChoiceBox for selecting the type of search.
     */
    @FXML
    private ChoiceBox<String> searchChoiceBox;
    /**
     * <code>imageClear</code>
     * The clear icon image.
     */
    private Image imageClear;
    /**
     * <code>imageSearch</code>
     * The search icon image.
     */
    private Image imageSearch;
    /**
     * <code>dismissErrorButton</code>
     * A Button used to dismiss error messages.
     */
    @FXML
    private Button dismissErrorButton;
    /**
     * <code>errorLabel</code>
     * A Label used for displaying error messages to the user.
     */
    @FXML
    private Label errorLabel;
    /**
     * <code>errorRectangle</code>
     * A Rectangle used for displaying error messages or notifications in the user interface.
     */
    @FXML
    private Rectangle errorRectangle;
    /**
     * <code>searchService</code>
     * The service used for searching songs.
     */
    private Search_Service searchService;

    /**
     * Initializes the controller.
     * This method is automatically called after the FXML file has been loaded.
     */
    public void initialize() {
        if(searchService == null){
            searchService = new Search_Service();
        }

        imageClear = new Image(getClass().getResource("/clientES/images/clear.png").toExternalForm());
        if(imageClearView == null){
            imageClearView = new ImageView();
        }
        imageClearView.setImage(imageClear);
        imageClearView.setFitHeight(20);
        imageClearView.setFitWidth(20);

        clearButton.setGraphic(imageClearView);

        imageSearch = new Image(getClass().getResource("/clientES/images/search.png").toExternalForm());
        if(imageSearchView == null){
            imageSearchView = new ImageView();
        }
        imageSearchView.setImage(imageSearch);
        imageSearchView.setFitHeight(20);
        imageSearchView.setFitWidth(20);

        searchButton.setGraphic(imageSearchView);
        searchChoiceBox.setValue("Titolo");
    }
    /**
     * Clears the selection of the choice box.
     * This method is triggered when the choice box selection needs to be cleared.
     */
    public void clearChoiceBoxSelection() {
        if (reservedAreaChoiceBox != null) {
            reservedAreaChoiceBox.getSelectionModel().clearSelection();
        }
    }
    /**
     * Clears the text in the search field.
     * This method is triggered when the clear button is clicked.
     */
    @FXML
    private void clearTextField() {
        searchField.clear();
    }
    /**
     * This method searches for a musical track based on the input in the search field.
     * It handles the action event triggered by clicking the search button.
     *
     * @param event The action event
     * @throws NotBoundException If a remote object is not bound to the specified name in the registry
     * @throws IOException If an I/O error occurs
     *
     */
    @FXML
    protected void cercaBranoMusicale(ActionEvent event) throws NotBoundException, IOException {
        String q = searchField.getText();
        String searchType = searchChoiceBox.getValue();

        if(q.length() < 3) {
            errorLabel.setText("ERRORE! Inserisci almeno 3 caratteri nella barra di ricerca");
            errorLabel.setVisible(true);
            dismissErrorButton.setVisible(true);
            errorRectangle.setVisible(true);
            return;
        } else if(searchType == null || searchType.isEmpty()) {
            errorLabel.setText("ERRORE! Seleziona una tipologia di ricerca");
            errorLabel.setVisible(true);
            dismissErrorButton.setVisible(true);
            errorRectangle.setVisible(true);
            return;
        } else if(q.split(",").length != searchType.split(",").length) {
            errorLabel.setText("ERRORE! La barra di ricerca deve contenere una ricerca della tipologia selezionata");
            errorLabel.setVisible(true);
            dismissErrorButton.setVisible(true);
            errorRectangle.setVisible(true);
            return;
        }

        List<Song> searchResult = searchService.cercaBranoMusicale(q, searchType);
        application.switchToSearchResultsLogged(searchResult, q);
    }
    /**
     * This method sets the ClientES application instance for this controller.
     *
     * @param application The ClientES application instance.
     */
    public void setApplication(ClientES application) {
        this.application = application;
    }
    /**
     * This method updates the text of the username label with the specified username.
     *
     * @param username The username to be displayed
     */
    public void setUsernameLabelText(String username) {
        if(usernameLabel == null){
            usernameLabel = new Label();
        }
        usernameLabel.setText(username);
    }
    /**
     * This method handles the action event when an option is selected from the reserved area choice box.
     * It switches to different screens based on the selected option.
     *
     * @param event The ActionEvent representing the selection event.
     */
    @FXML
    protected void reservedAreaOptions(ActionEvent event) {
        String selectedOption = reservedAreaChoiceBox.getValue();
        clearChoiceBoxSelection();
        
        if(selectedOption == null){
            return;
        } else if(application != null && selectedOption.equals("Il mio profilo")){
            application.switchToUserProfile();
        } else if(application != null && selectedOption.equals("Modifica password")){
            application.switchToChangePassword();
        } else if(application != null && selectedOption.equals("Le mie playlist")){
            application.switchToUserPlaylist();
        } else if(application != null && selectedOption.equals("Le mie valutazioni")){
            application.switchToUserFeedback();
        } else if(application != null && selectedOption.equals("Logout")){
            application.logout();
        }
    }
    /**
     * This method hides the error message, dismiss button, and error rectangle.
     */
    @FXML
    protected void onDismissErrorButtonClick(ActionEvent event) {
        dismissErrorButton.setVisible(false);
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }
    /**
     * This method hides the dismiss button, clears the error message label, and hides the error rectangle.
     */
    public void resetPreviusError(){
        dismissErrorButton.setVisible(false);
        errorLabel.setText("");
        errorLabel.setVisible(false);
        errorRectangle.setVisible(false);
    }

}
