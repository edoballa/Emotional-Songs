package clientES.services;

import clientES.objects.Address_Calculator;
import clientES.objects.UserInfo_Validator;
import commons.objects.Address;
import commons.objects.User;
/**
 * <p>This class provides services related to user registration.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class Registration_Service {
    /**
     * <code>clientHandler</code>
     * An instance of ClientHandler used for communication with the server.
     */
    private ClientHandler clientHandler;
    /**
     * <code>addressCalculator</code>
     * An instance of Address_Calculator used for address validation.
     */

    private Address_Calculator addressCalculator;
    /**
     * <code>userInfoValidator</code>
     * An instance of UserInfo_Validator used for user information validation.
     */

    private UserInfo_Validator userInfoValidator;

    /**
     * Constructs a new Registration_Service and initializes the UserInfo_Validator, Address_Calculator,
     * and ClientHandler instances.
     */
    public Registration_Service(){
        userInfoValidator = new UserInfo_Validator();
        addressCalculator = new Address_Calculator();

        try {
            clientHandler = ClientHandler.getInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * This method checks if a given username can be registered.
     *
     * @param username The username to be checked for registration.
     * @return True if the username can be registered, false otherwise.
     */

    public boolean canRegister(String username){
        try {
            return clientHandler.canRegister(username);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * This method validates the password according to predefined criteria.
     *
     * @param password The password to be validated.
     * @return True if the password is valid, false otherwise.
     */

    public boolean checkPassword(String password){
        return userInfoValidator.isPasswordValid(password);
    }

    /**
     * This method checks if the username meets the initial criteria for registration.
     *
     * @param username The username to be checked.
     * @return True if the username meets the criteria, false otherwise.
     */

    public boolean firstUsernameCheck(String username) {
        return userInfoValidator.isFieldValid(username, false, username.length());
    }

    /**
     * This method validates the user information entered during registration.
     *
     * @param fiscalCode The fiscal code of the user.
     * @param email The email address of the user.
     * @param firstName The first name of the user.
     * @param lastName The last name of the user.
     * @param address The address of the user.
     * @return A string containing an error message if validation fails, null otherwise.
     */

    public String validateUserInfo(String fiscalCode, String email, String firstName, String lastName, String address) {
        return userInfoValidator.validateUserInfo(fiscalCode, email, firstName, lastName, address);
    }

    /**
     * This method registers a new user with the provided information.
     *
     * @param username The username of the user.
     * @param password The password of the user.
     * @param fiscalCode The fiscal code of the user.
     * @param email The email address of the user.
     * @param firstName The first name of the user.
     * @param lastName The last name of the user.
     * @param address The address of the user.
     * @return True if the registration is successful, false otherwise.
     */

    public boolean registrazione(String username, String password, String fiscalCode, String email, String firstName, String lastName, String address){
        try {
            Address userAddress = addressCalculator.fillAddress(address);
            User paramUser = new User(username, password, email, firstName, lastName, fiscalCode, userAddress);

            return clientHandler.registrazione(paramUser);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
