package clientES;

import clientES.controller.logged.*;
import clientES.controller.notlogged.HomeController;
import clientES.controller.notlogged.SearchResultsController;
import clientES.controller.notlogged.SelectedResultController;
import clientES.controller.logged.playlist.PlaylistListController;
import clientES.controller.logged.playlist.PlaylistDetailsController;
import clientES.controller.notlogged.login.LoginController;
import clientES.controller.notlogged.registration.Registration1Controller;
import clientES.controller.notlogged.registration.Registration2Controller;
import clientES.services.SongDetail_Service;
import commons.objects.EmotionFeedbackStatistics;
import commons.objects.Playlist;
import commons.objects.Song;
import commons.objects.User;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.List;
/**
 * <p>This class represents the main application class for the EmotionalSongs client.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class ClientES extends Application {
    /**
     * <code>primaryStage</code>
     * An instance of the primary stage for the JavaFX application.
     */
    private Stage primaryStage;
    /**
     * <code>homeScene</code>
     * An instance of the scene representing the home screen of the application.
     */
    private Scene homeScene;

    /**
     * <code>homeLoggedScene</code>
     * An instance of the scene representing the logged-in home screen of the application.
     */
    private Scene homeLoggedScene;

    /**
     * <code>registration1Scene</code>
     * An instance of the scene representing the registration form 1.
     */
    private Scene registration1Scene;

    /**
     * <code>registration2Scene</code>
     * An instance of the scene representing the registration form 2.
     */
    private Scene registration2Scene;

    /**
     * <code>loginScene</code>
     * An instance of the scene representing the login form.
     */
    private Scene loginScene;

    /**
     * <code>playlistScene</code>
     * An instance of the scene representing the playlist management screen.
     */
    private Scene playlistScene;

    /**
     * <code>userPlaylistDetailsScene</code>
     * An instance of the scene representing the details of a user playlist.
     */
    private Scene userPlaylistDetailsScene;

    /**
     * <code>searchResultsScene</code>
     * An instance of the scene representing the search results screen.
     */
    private Scene searchResultsScene;

    /**
     * <code>selectedResultScene</code>
     * An instance of the scene representing the details of a selected search result.
     */
    private Scene selectedResultScene;

    /**
     * <code>searchResultsLoggedScene</code>
     * An instance of the scene representing the search results screen for logged-in users.
     */
    private Scene searchResultsLoggedScene;

    /**
     * <code>selectedResultLoggedScene</code>
     * An instance of the scene representing the details of a selected search result for logged-in users.
     */
    private Scene selectedResultLoggedScene;

    /**
     * <code>userProfileScene</code>
     * An instance of the scene representing the user profile screen.
     */
    private Scene userProfileScene;

    /**
     * <code>changePasswordScene</code>
     * An instance of the scene representing the change password screen.
     */
    private Scene changePasswordScene;

    /**
     * <code>feedbackListScene</code>
     * An instance of the scene representing the user feedback list screen.
     */
    private Scene feedbackListScene;

    /**
     * <code>feedbackNewScene</code>
     * An instance of the scene representing the form for adding new feedback.
     */
    private Scene feedbackNewScene;

    /**
     * <code>homeController</code>
     * An instance of the controller for the home screen.
     */
    private HomeController homeController;

    /**
     * <code>homeLoggedController</code>
     * An instance of the controller for the home screen when logged in.
     */
    private HomeLoggedController homeLoggedController;

    /**
     * <code>registration1Controller</code>
     * An instance of the controller for the first registration form.
     */
    private Registration1Controller registration1Controller;

    /**
     * <code>registration2Controller</code>
     * An instance of the controller for the second registration form.
     */
    private Registration2Controller registration2Controller;

    /**
     * <code>loginController</code>
     * An instance of the controller for the login screen.
     */
    private LoginController loginController;

    /**
     * <code>playlistListController</code>
     * An instance of the controller for the playlist management screen.
     */
    private PlaylistListController playlistListController;

    /**
     * <code>playlisDetailsController</code>
     * An instance of the controller for the details of a user playlist.
     */
    private PlaylistDetailsController playlisDetailsController;

    /**
     * <code>searchResultsController</code>
     * An instance of the controller for the search results screen.
     */
    private SearchResultsController searchResultsController;

    /**
     * <code>selectedResultController</code>
     * An instance of the controller for the details of a selected search result.
     */
    private SelectedResultController selectedResultController;

    /**
     * <code>searchResultsLoggedController</code>
     * An instance of the controller for the search results screen for logged-in users.
     */
    private SearchResultsLoggedController searchResultsLoggedController;

    /**
     * <code>selectedResultLoggedController</code>
     * An instance of the controller for the details of a selected search result for logged-in users.
     */
    private SelectedResultLoggedController selectedResultLoggedController;

    /**
     * <code>userProfileController</code>
     * An instance of the controller for the user profile screen.
     */
    private UserProfileController userProfileController;

    /**
     * <code>changePasswordController</code>
     * An instance of the controller for the change password screen.
     */
    private ChangePasswordController changePasswordController;

    /**
     * <code>feedbackListController</code>
     * An instance of the controller for the user feedback list screen.
     */
    private FeedbackListController feedbackListController;

    /**
     * <code>feedbackNewController</code>
     * An instance of the controller for the form for adding new feedback.
     */
    private FeedbackNewController feedbackNewController;

    /**
     * An instance representing the current user.
     */
    private User user;

    /**
     * An instance of SongDetail_Service used for handling song details and interactions.
     */
    private SongDetail_Service songDetailService;


    /**
     * This method initializes the primary stage and loads the various scenes for the application.
     * Sets up controllers and scenes for different UI views.
     *
     * @param primaryStage The primary stage of the application.
     * @throws IOException       If an error occurs while loading the FXML files.
     * @throws NotBoundException If an error occurs during the binding process.
     */
    @Override
    public void start(Stage primaryStage) throws IOException, NotBoundException {
        this.primaryStage = primaryStage;

        //Carica il form della home iniziale
        FXMLLoader homeLoader = new FXMLLoader(ClientES.class.getResource("home.fxml"));
        Parent homeRoot = homeLoader.load();
        homeController = homeLoader.getController();
        homeController.setApplication(this);
        homeScene = new Scene(homeRoot, 1000, 500);
        primaryStage.setScene(homeScene);
        primaryStage.setResizable(false);

        //Carica il form della home da loggato
        FXMLLoader homeLoggedLoader = new FXMLLoader(ClientES.class.getResource("homeLogged.fxml"));
        Parent homeLoggedRoot = homeLoggedLoader.load();
        homeLoggedController = homeLoggedLoader.getController();
        homeLoggedController.setApplication(this);
        homeLoggedScene = new Scene(homeLoggedRoot, 1000, 500);
        primaryStage.setScene(homeLoggedScene);
        primaryStage.setResizable(false);

        // Carica il primo form di registration
        FXMLLoader registration1Loader = new FXMLLoader(ClientES.class.getResource("registration1.fxml"));
        Parent registration1Root = registration1Loader.load();
        registration1Controller = registration1Loader.getController();
        registration1Controller.setApplication(this);
        registration1Scene = new Scene(registration1Root, 900, 500);
        primaryStage.setScene(registration1Scene);
        primaryStage.setResizable(false);

        // Carica il secondo form di registration
        FXMLLoader registration2Loader = new FXMLLoader(ClientES.class.getResource("registration2.fxml"));
        Parent registration2Root = registration2Loader.load();
        registration2Controller = registration2Loader.getController();
        registration2Controller.setApplication(this);
        registration2Scene = new Scene(registration2Root, 900, 528);
        primaryStage.setScene(registration2Scene);
        primaryStage.setResizable(false);

        // Carica il form di login
        FXMLLoader loginLoader = new FXMLLoader(ClientES.class.getResource("login.fxml"));
        Parent loginRoot = loginLoader.load();
        loginController = loginLoader.getController();
        loginController.setApplication(this);
        loginScene = new Scene(loginRoot, 900, 500);
        primaryStage.setScene(loginScene);
        primaryStage.setResizable(false);

        // Carica il form di gestione delle playlist
        FXMLLoader playlistLoader = new FXMLLoader(ClientES.class.getResource("playlistList.fxml"));
        Parent playlistRoot = playlistLoader.load();
        playlistListController = playlistLoader.getController();
        playlistListController.setApplication(this);
        playlistScene = new Scene(playlistRoot, 1000, 700);
        primaryStage.setScene(playlistScene);
        primaryStage.setResizable(false);

        //Carica il form del risultato selezionato dalla ricerca da loggato
        FXMLLoader userPlaylistDetailsLoader = new FXMLLoader(ClientES.class.getResource("playlistDetails.fxml"));
        Parent userPlaylistDetailsRoot = userPlaylistDetailsLoader.load();
        playlisDetailsController = userPlaylistDetailsLoader.getController();
        playlisDetailsController.setApplication(this);
        userPlaylistDetailsScene = new Scene(userPlaylistDetailsRoot, 900, 700);
        primaryStage.setScene(userPlaylistDetailsScene);
        primaryStage.setResizable(false);

        //Carica il form dei risultati trovati dalla ricerca dell'utente
        FXMLLoader searchResultsLoader = new FXMLLoader(ClientES.class.getResource("searchResults.fxml"));
        Parent searchResultsRoot = searchResultsLoader.load();
        searchResultsController = searchResultsLoader.getController();
        searchResultsController.setApplication(this);
        searchResultsScene = new Scene(searchResultsRoot, 900, 550);
        primaryStage.setScene(searchResultsScene);
        primaryStage.setResizable(false);

        //Carica il form del risultato selezionato dalla ricerca
        FXMLLoader selectedResultLoader = new FXMLLoader(ClientES.class.getResource("selectedResult.fxml"));
        Parent selectedResultRoot = selectedResultLoader.load();
        selectedResultController = selectedResultLoader.getController();
        selectedResultController.setApplication(this);
        selectedResultScene = new Scene(selectedResultRoot, 900, 650);
        primaryStage.setScene(selectedResultScene);
        primaryStage.setResizable(false);

        //Carica il form di risultati trovati dalla ricerca dell'utente da loggato
        FXMLLoader searchResultsLoggedLoader = new FXMLLoader(ClientES.class.getResource("searchResultsLogged.fxml"));
        Parent searchResultsLoggedRoot = searchResultsLoggedLoader.load();
        searchResultsLoggedController = searchResultsLoggedLoader.getController();
        searchResultsLoggedController.setApplication(this);
        searchResultsLoggedScene = new Scene(searchResultsLoggedRoot, 900, 550);
        primaryStage.setScene(searchResultsLoggedScene);
        primaryStage.setResizable(false);

        //Carica il form del risultato selezionato dalla ricerca da loggato
        FXMLLoader selectedResultLoggedLoader = new FXMLLoader(ClientES.class.getResource("selectedResultLogged.fxml"));
        Parent selectedResultLoggedRoot = selectedResultLoggedLoader.load();
        selectedResultLoggedController = selectedResultLoggedLoader.getController();
        selectedResultLoggedController.setApplication(this);
        selectedResultLoggedScene = new Scene(selectedResultLoggedRoot, 900, 713);
        primaryStage.setScene(selectedResultLoggedScene);
        primaryStage.setResizable(false);

        //userProfileScene userProfileController prefHeight="573.0" prefWidth="900.0"
        FXMLLoader userProfileLoader = new FXMLLoader(ClientES.class.getResource("userProfile.fxml"));
        Parent userProfileRoot = userProfileLoader.load();
        userProfileController = userProfileLoader.getController();
        userProfileController.setApplication(this);
        userProfileScene = new Scene(userProfileRoot, 900, 573);
        primaryStage.setScene(userProfileScene);
        primaryStage.setResizable(false);

        //userProfileScene userProfileController prefHeight="644.0" prefWidth="900.0"
        FXMLLoader userFeedbackLoader = new FXMLLoader(ClientES.class.getResource("feedbackList.fxml"));
        Parent userFeedbackRoot = userFeedbackLoader.load();
        feedbackListController = userFeedbackLoader.getController();
        feedbackListController.setApplication(this);
        feedbackListScene = new Scene(userFeedbackRoot, 900, 644);
        primaryStage.setScene(feedbackListScene);
        primaryStage.setResizable(false);

        //feedbackNewScene feedbackNewController prefHeight="404.0" prefWidth="900.0"
        FXMLLoader feedbackNewLoader = new FXMLLoader(ClientES.class.getResource("feedbackNew.fxml"));
        Parent feedbackNewRoot = feedbackNewLoader.load();
        feedbackNewController = feedbackNewLoader.getController();
        feedbackNewController.setApplication(this);
        feedbackNewScene = new Scene(feedbackNewRoot, 900, 423);
        primaryStage.setScene(feedbackNewScene);
        primaryStage.setResizable(false);

        //userProfileScene userProfileController prefHeight="573.0" prefWidth="900.0" //prefHeight="429.0" prefWidth="900.0"
        FXMLLoader changePasswordLoader = new FXMLLoader(ClientES.class.getResource("changePassword.fxml"));
        Parent changePasswordRoot = changePasswordLoader.load();
        changePasswordController = changePasswordLoader.getController();
        changePasswordController.setApplication(this);
        changePasswordScene = new Scene(changePasswordRoot, 900, 429);
        primaryStage.setScene(userProfileScene);
        primaryStage.setResizable(false);

        primaryStage.setTitle("Home - EmotionalSongs");
        primaryStage.setScene(homeScene);//modificato
        primaryStage.show();
    }

    /**
     * This method logs out the current user and switches to the home scene.
     */
    public void logout(){
        user = null;
        switchToHome();
    }

    /**
     * This method Switches to the home scene.
     */
    public void switchToHome() {
        homeController.resetPreviusError();
        primaryStage.setScene(homeScene);
        primaryStage.setTitle("Home - EmotionalSongs");
    }

    /**
     * This method switches to the logged home scene.
     */
    public void switchToHomeLogged() {
        homeLoggedController.resetPreviusError();
        homeLoggedController.clearChoiceBoxSelection();
        homeLoggedController.setUsernameLabelText(this.user.getUsername());

        primaryStage.setScene(homeLoggedScene);
        primaryStage.setTitle("Home - EmotionalSongs");
    }

    /**
     * This method switches to the user profile scene.
     */
    public void switchToUserProfile() {
        userProfileController.loadUserData();
        userProfileController.clearChoiceBoxSelection();

        primaryStage.setScene(userProfileScene);
        primaryStage.setTitle("Il mio profilo - EmotionalSongs");
    }

    /**
     * This method switches to the user feedback scene.
     */
    public void switchToUserFeedback() {
        feedbackListController.refreshTableData(true);
        feedbackListController.clearChoiceBoxSelection();
        feedbackListController.setFeedbackDetailsVisibility(false);

        primaryStage.setScene(feedbackListScene);
        primaryStage.setTitle("I miei Feedback - EmotionalSongs");
    }

    /**
     * This method switches to the scene for creating a new user feedback.
     * @param selectedSong The selected song for which the feedback will be created.
     * @param previusPage The previous page from which the method was called.
     */
    public void switchToNewUserFeedback(Song selectedSong, String previusPage) {
        feedbackNewController.setSelectedSong(selectedSong);
        feedbackNewController.setPreviusPage(previusPage);
        feedbackNewController.clearChoiceBoxSelection();

        primaryStage.setScene(feedbackNewScene);
        primaryStage.setTitle("Nuovo Feedback - EmotionalSongs");
    }

    /**
     * This method switches to the scene for changing the password.
     */
    public void switchToChangePassword() {
        changePasswordController.clearChoiceBoxSelection();
        changePasswordController.resetInitConfiguration();

        primaryStage.setScene(changePasswordScene);
        primaryStage.setTitle("Modifica password - EmotionalSongs");
    }

    /**
     * This method switches to the first step of the registration process.
     */

    public void switchToRegistration1() {
        registration1Controller.resetPreviusError();

        primaryStage.setScene(registration1Scene);
        primaryStage.setTitle("Iscriviti - EmotionalSongs");
    }
    /**
     * This method switches to the second step of the registration process.
     */

    public void switchToRegistration2(String username, String password) {
        registration2Controller.resetInitConfiguration();
        registration2Controller.setUsername(username);
        registration2Controller.setPassword(password);

        primaryStage.setScene(registration2Scene);
    }
    /**
     * This method switches to the login scene.
     */

    public void switchToLogin() {
        primaryStage.setScene(loginScene);
        primaryStage.setTitle("Accedi - EmotionalSongs");
    }
    /**
     * This method switches to the user playlist scene.
     */

    public void switchToUserPlaylist() {
        playlistListController.refreshTableData();
        playlistListController.setUsernameLabelText(user.getUsername());
        playlistListController.clearChoiceBoxSelection();

        primaryStage.setScene(playlistScene);
        primaryStage.setTitle("Playlist - EmotionalSongs");
        clearChoiceBoxSelection();
    }

    /**
     * This method switches to the user playlist details scene.
     */

    public void switchToUserPlaylistDetails(Playlist playlist) {
        playlisDetailsController.setPlaylist(playlist);
        playlisDetailsController.setUsernameLabelText(user.getUsername());

        primaryStage.setScene(userPlaylistDetailsScene);
        primaryStage.setTitle("Playlist - EmotionalSongs");
        clearChoiceBoxSelection();
    }

    /**
     * This method switches to the user playlist details scene.
     */

    public void switchToUserPlaylistDetails() {
        primaryStage.setScene(userPlaylistDetailsScene);
        primaryStage.setTitle("Playlist - EmotionalSongs");
        clearChoiceBoxSelection();
    }

    /**
     * This method switches to the search results scene.
     */

    public void switchToSearchResults(List<Song> searchResult, String searchTerm) {
        searchResultsController.setSearchTerm(searchTerm);
        searchResultsController.setSearchResult(searchResult);

        primaryStage.setScene(searchResultsScene);
        primaryStage.setTitle("Risultati ricerca - EmotionalSongs");
    }
    /**
     * This method switches to the search results scene.
     */


    public void switchToSearchResults() {
        searchResultsController.refreshTableData();

        primaryStage.setScene(searchResultsScene);
        primaryStage.setTitle("Risultati ricerca - EmotionalSongs");
    }

    /**
     * This method displays the emotion details for a song.
     *
     * @param song The song for which to display emotion details.
     * @throws SQLException      If a SQL exception occurs.
     * @throws RemoteException   If a remote exception occurs.
     */

    public void visualizzaEmozioneBrano(Song song) throws SQLException, RemoteException {
        if(songDetailService == null){
            songDetailService = new SongDetail_Service();
        }

        List<EmotionFeedbackStatistics> emotionsFeltDetails = songDetailService.loadSongFeelingsBySongId(song.getSongId());
        song.setEmotionList(emotionsFeltDetails);
        selectedResultController.setSong(song);

        primaryStage.setScene(selectedResultScene);
        primaryStage.setTitle("Dettagli canzone - EmotionalSongs");
    }

    /**
     * This method switches to the search results scene for a logged-in user.
     *
     * @param searchResult The list of songs found in the search.
     * @param searchTerm   The search term used.
     */

    public void switchToSearchResultsLogged(List<Song> searchResult, String searchTerm) {
        searchResultsLoggedController.setSearchTerm(searchTerm);
        searchResultsLoggedController.setSearchResult(searchResult);
        searchResultsLoggedController.setUsernameLabelText(user.getUsername());

        primaryStage.setScene(searchResultsLoggedScene);
        primaryStage.setTitle("Risultati ricerca - EmotionalSongs");
    }

    /**
     * This method switches to the search results scene for a logged-in user.
     */

    public void switchToSearchResultsLogged() {
        searchResultsLoggedController.refreshTableData();

        primaryStage.setScene(searchResultsLoggedScene);
        primaryStage.setTitle("Risultati ricerca - EmotionalSongs");
    }

    /**
     * This method displays the emotion details for a song.
     */

    public void visualizzaEmozioneBrano(Song song, String previusPage) throws Exception {
        if(songDetailService == null){
            songDetailService = new SongDetail_Service();
        }

        List<EmotionFeedbackStatistics> emotionsFeltDetails = songDetailService.loadSongFeelingsBySongId(song.getSongId());
        song.setEmotionList(emotionsFeltDetails);
        selectedResultLoggedController.setSong(song);
        selectedResultLoggedController.setUsernameLabelText(user.getUsername());
        selectedResultLoggedController.clearChoiceBoxSelection();
        selectedResultLoggedController.setPreviusPage(previusPage);

        primaryStage.setScene(selectedResultLoggedScene);
        primaryStage.setTitle("Dettagli canzone - EmotionalSongs");
    }

    /**
     * This method clears the selection in choice boxes.
     */

    private void clearChoiceBoxSelection() {
        if (homeLoggedController != null) {
            homeLoggedController.clearChoiceBoxSelection();
        }
    }

    /**
     * This method clears the fields in the registration form.
     */

    public void cleanRegistration1Field(){
        registration1Controller.cleanField();
    }

    /**
     * This method retrieves the current user.
     *
     * @return The current user.
     */

    public User getUser() {
        return user;
    }

    /**
     * This method sets the current user.
     *
     * @param user The user to set as current.
     */

    public void setUser(User user) {
        this.user = user;
    }

    /**
     * This method is the entry point of the application.
     *
     * @param args The command-line arguments passed to the application.
     */
    public static void main(String[] args) {
        launch();
    }
}