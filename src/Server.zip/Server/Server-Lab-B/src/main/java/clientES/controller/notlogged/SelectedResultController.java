package clientES.controller.notlogged;

import clientES.ClientES;
import commons.objects.EmotionFeedbackStatistics;
import commons.objects.Song;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import java.net.URL;
import java.util.ResourceBundle;
/**
 * <p> This class represents the controller for displaying details of a selected song result. It implements the Initializable interface to initialize the controller.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class SelectedResultController implements Initializable {
    /**
     * <code>application</code>
     * A reference to the main application instance, responsible for managing navigation between screens and user interactions.
     */
    @FXML
    private ClientES application;
    /**
     * <code>subscribeButton</code>
     * A Button used for initiating the registration process.
     */
    @FXML
    private Button subscribeButton;
    /**
     * <code>loginButton</code>
     * A Button used for navigating to the login page.
     */
    @FXML
    private Button loginButton;
    /**
     * Represents a Button used for navigating back to the previous screen.
     * <code>backButton</code>
     */
    @FXML
    private Button backButton;
    /**
     * Represents an ImageView used for displaying an image, such as an arrow icon indicating navigation direction.
     * <code>imageView</code>
     */
    @FXML
    private ImageView imageView;
    /**
     * Represents an Image object representing the left arrow icon used for navigation.
     * <code>imageLeftArrow</code>
     */
    private Image imageLeftArrow;
    /**
     * Represents a Label for displaying the title of the selected song.
     * <code>songTitleLabel</code>
     */
    @FXML
    private Label songTitleLabel;
    /**
     * Represents a Label for displaying the author of the selected song.
     * <code>songAuthorLabel</code>
     */
    @FXML
    private Label songAuthorLabel;
    /**
     * Represents a Label for displaying the album of the selected song.
     * <code>songAlbumLabel</code>
     */
    @FXML
    private Label songAlbumLabel;
    /**
     * Represents a Label for displaying the year of the selected song.
     * <code>songYearLabel</code>
     */
    @FXML
    private Label songYearLabel;
    /**
     * Represents a Label for displaying the duration of the selected song.
     * <code>songDurationLabel</code>
     */
    @FXML
    private Label songDurationLabel;
    /**
     * Represents a TableView for displaying the statistics of the selected song.
     * <code>statisticsTable</code>
     */
    @FXML
    private TableView<EmotionFeedbackStatistics> statisticsTable;
    /**
     * Represents a TableView for displaying comments of the selected song.
     * <code>commentsTable</code>
     */
    @FXML
    private TableView<CommentLineData> commentsTable;
    /**
     * The selected song.
     * <code>song</code>
     */
    private Song song;
    /**
     * Represents data for a single line in the comments table.
     */
    private class CommentLineData {
        public String emotionName;
        public String comment;
    }
    /**
     * Initializes the controller with the specified URL and ResourceBundle.
     *
     * @param location The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param rb       The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL location, ResourceBundle rb) {
        Font defaultFont = new Font(22.0);

        subscribeButton.setOnMouseEntered(event -> {
            subscribeButton.setTextFill(Color.WHITE);
            subscribeButton.setFont(new Font(23.0));
            subscribeButton.setPrefHeight(43.0);
            subscribeButton.setPrefWidth(97.0);
        });

        loginButton.setOnMouseEntered(event -> {
            loginButton.setFont(new Font(23.0));
            loginButton.setPrefHeight(43.0);
            loginButton.setPrefWidth(97.0);
        });

        subscribeButton.setOnMouseExited(event -> {
            subscribeButton.setTextFill(Color.web("#d2d2d2"));
            subscribeButton.setFont(defaultFont);
            subscribeButton.setPrefHeight(41.0);
            subscribeButton.setPrefWidth(95.0);
        });

        loginButton.setOnMouseExited(event -> {
            loginButton.setFont(defaultFont);
            loginButton.setPrefHeight(41.0);
            loginButton.setPrefWidth(95.0);
        });

        imageLeftArrow = new Image(getClass().getResource("/clientES/images/leftArrow.png").toExternalForm());
        imageView.setImage(imageLeftArrow);

        imageView.setFitHeight(20);
        imageView.setFitWidth(20);

        backButton.setGraphic(imageView);

        backButton.setOnMouseEntered(event -> {
            backButton.setTooltip(new Tooltip("Torna indietro"));
        });

        backButton.setOnMouseExited(event -> {
            backButton.setTooltip(null);
        });

        if(song == null){
            song = new Song();
        }

        setLabelsValue();
        configureTablesColumns();
    }
    /**
     * Configures the columns of the results table.
     * This method creates and sets up the columns for the song title, author, year, album, and duration.
     */
    private void configureTablesColumns() {
        // Populate statisticsTable
        TableColumn<EmotionFeedbackStatistics, String> emotionCol = new TableColumn<>("EMOZIONE");
        TableColumn<EmotionFeedbackStatistics, String> averageScoreCol = new TableColumn<>("MEDIA PUNTEGGIO");
        TableColumn<EmotionFeedbackStatistics, String> numberOfVotesCol = new TableColumn<>("NUMERO DI VOTI");

        emotionCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getEmotion().getName()));
        averageScoreCol.setCellValueFactory(cellData -> new SimpleStringProperty("" + cellData.getValue().getAverageOfRatings().doubleValue()));
        numberOfVotesCol.setCellValueFactory(cellData -> new SimpleStringProperty("" + cellData.getValue().getNumberOfRatings()));

        emotionCol.setPrefWidth(200);
        averageScoreCol.setPrefWidth(200);
        numberOfVotesCol.setPrefWidth(200);

        statisticsTable.getColumns().addAll(emotionCol, averageScoreCol, numberOfVotesCol);
        refreshStatisticsTable();

        // Populate commentsTable
        TableColumn<CommentLineData, String> emotionCommentCol = new TableColumn<>("EMOZIONE");
        TableColumn<CommentLineData, String> commentCol = new TableColumn<>("COMMENTO");

        emotionCommentCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().emotionName));
        commentCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().comment));

        emotionCommentCol.setPrefWidth(150);
        commentCol.setPrefWidth(450);

        commentsTable.getColumns().addAll(emotionCommentCol, commentCol);
        refreshCommentsTable();
    }
    /**
     * This method sets the values for the song-related labels based on the current song.
     */
    public void setLabelsValue(){
        // Set values for labels
        songTitleLabel.setText(song.getTitle());
        songAuthorLabel.setText(song.getAuthor());
        songAlbumLabel.setText(song.getAlbum());
        songYearLabel.setText(song.getYear());
        songDurationLabel.setText(song.getDuration() + "");
    }
    /**
     * This method refreshes the statistics table with the latest data from the song's emotion feedback statistics.
     */
    public void refreshStatisticsTable() {
        statisticsTable.getItems().clear();
        ObservableList<EmotionFeedbackStatistics> statisticsData = FXCollections.observableArrayList();
        statisticsData.addAll(song.getEmotionList());
        statisticsTable.setItems(statisticsData);
    }
    /**
     * This method refreshes the comments table with the latest comments associated with each emotion in the song's emotion feedback statistics.
     */
    public void refreshCommentsTable() {
        commentsTable.getItems().clear();
        ObservableList<CommentLineData> commentData = FXCollections.observableArrayList();
        for (EmotionFeedbackStatistics efd : song.getEmotionList()) {
            String emotionName = efd.getEmotion().getName();

            for (String comment : efd.getComments()) {
                CommentLineData lineData = new CommentLineData();
                lineData.emotionName = emotionName;
                lineData.comment = comment;
                commentData.add(lineData);
            }

        }

        commentsTable.setItems(commentData);
    }
    /**
     * This method handles the action event when the user clicks on the subscribe button.
     * @param event The action event triggered by clicking the subscribe button.
     */
    @FXML
    protected void onSubscribeButtonClick(ActionEvent event) {
        if (application != null) {
            application.switchToRegistration1();
        }
    }
    /**
     * This method handles the action event when the user clicks on the login button.
     * @param event The action event triggered by clicking the login button.
     */
    @FXML
    protected void onLoginButtonClick(ActionEvent event) {
        if (application != null) {
            application.switchToLogin();
        }
    }
    /**
     * This method handles the action event when the user clicks on the back button.
     * @param event The action event triggered by clicking the back button.
     */
    @FXML
    protected void onBackButtonClick(ActionEvent event) {
        if (application != null) {
            application.switchToSearchResults();
        }
    }
    /**
     * This method sets the application instance for this controller.
     * @param application The application instance to be set.
     */
    public void setApplication(ClientES application) {
        this.application = application;
    }
    /**
     * This method retrieves the currently selected song.
     * @return The currently selected song.
     */
    public Song getSong() {
        return song;
    }
    /**
     * This method sets the currently selected song.
     * @param song The song to be set as currently selected.
     */
    public void setSong(Song song) {
        this.song = song;
        setLabelsValue();
        refreshStatisticsTable();
        refreshCommentsTable();
    }
}
