package clientES.controller.logged;

import clientES.ClientES;
import commons.objects.Song;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
/**
 * <p>This class is responsible for handling search results view when the user is logged in.
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class SearchResultsLoggedController implements Initializable {
    /**
     * <code>application</code>
     * A reference to the main application instance, responsible for managing navigation between screens and user interactions.
     */
    @FXML private ClientES application;
    /**
     * <code>reservedAreaChoiceBox</code>
     * A ChoiceBox used for selecting options related to the user's reserved area.
     */
    @FXML private ChoiceBox<String> reservedAreaChoiceBox;
    /**
     * <code>backButton</code>
     * A Button used for navigating back to the previous screen or view..
     */
    @FXML private Button backButton;
     /**
     * <code>imageView</code>
     * An ImageView object used for displaying an image, such as an arrow icon indicating navigation direction.
     */
    @FXML private ImageView imageView;
    /**
     * <code>imageLeftArrow</code>
     * An Image object representing the left arrow icon used for navigation.
     */
    @FXML private Image imageLeftArrow;
    /**
     * <code>choiceBox</code>
     * A ChoiceBox used for selecting different options related to the search results.
     */
    @FXML private ChoiceBox<String> choiceBox;
    /**
     * <code>resultsTable</code>
     * A TableView displaying the search results.
     */
    @FXML public TableView<Song> resultsTable;
    /**
     * <code>lastSearchLabel</code>
     * A Label displaying the term of the last search performed.
     */
    @FXML private Label lastSearchLabel;
    /**
     * <code>usernameLabel</code>
     * A Label used for displaying the username of the currently logged-in user.
     */
    @FXML private Label usernameLabel;
    /**
     * <code>searchTerm</code>
     * The term used for the last search performed.
     */
    private static String searchTerm = "";
    /**
     * <code>searchResult</code>
     * The list of songs resulting from the last search.
     */
    private static List<Song> searchResult = null;
    /**
     * Initializes the controller after its root element has been completely processed.
     * This method is called once all FXML elements have been loaded and their associated controllers initialized.
     *
     * @param location The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param rb The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL location, ResourceBundle rb) {
        imageLeftArrow = new Image(getClass().getResource("/clientES/images/leftArrow.png").toExternalForm());
        imageView.setImage(imageLeftArrow);
        imageView.setFitHeight(20);
        imageView.setFitWidth(20);

        backButton.setGraphic(imageView);
        backButton.setOnMouseEntered(event -> backButton.setTooltip(new Tooltip("Torna indietro")));
        backButton.setOnMouseExited(event -> backButton.setTooltip(null));

        if(application != null && application.getUser() != null) {
            usernameLabel.setText(application.getUser().getUsername());
        }
        configureTableColumns();
        refreshTableData();
        configureTableEvents();
    }
    /**
     * This method handles the action event when an option is selected from the reserved area choice box.
     * It switches to different screens based on the selected option.
     *
     * @param event The ActionEvent representing the selection event.
     */
    @FXML
    protected void reservedAreaOptions(ActionEvent event) {
        String selectedOption = reservedAreaChoiceBox.getValue();
        clearChoiceBoxSelection();
        
        if(selectedOption == null){
            return;
        } else if(application != null && selectedOption.equals("Il mio profilo")){
            application.switchToUserProfile();
        } else if(application != null && selectedOption.equals("Modifica password")){
            application.switchToChangePassword();
        } else if(application != null && selectedOption.equals("Le mie playlist")){
            application.switchToUserPlaylist();
        } else if(application != null && selectedOption.equals("Le mie valutazioni")){
            application.switchToUserFeedback();
        } else if(application != null && selectedOption.equals("Logout")){
            application.logout();
        }
    }
    /**
     * This method configures the columns of the table view to display song information.
     */
    private void configureTableColumns() {
        TableColumn<Song, String> titleCol = new TableColumn<>("TITOLO");
        TableColumn<Song, String> authorCol = new TableColumn<>("AUTORE");
        TableColumn<Song, String> yearCol = new TableColumn<>("ANNO");
        TableColumn<Song, String> albumCol = new TableColumn<>("ALBUM");
        TableColumn<Song, String> timeCol = new TableColumn<>("DURATA");

        titleCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getTitle()));
        authorCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getAuthor()));
        yearCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getYear()));
        albumCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getAlbum()));
        timeCol.setCellValueFactory(cellData -> new SimpleStringProperty("" + cellData.getValue().getDuration()));

        titleCol.setPrefWidth(200);
        authorCol.setPrefWidth(200);
        yearCol.setPrefWidth(50);
        albumCol.setPrefWidth(200);
        timeCol.setPrefWidth(75);

        resultsTable.getColumns().addAll(titleCol, authorCol, yearCol, albumCol, timeCol);
    }
    /**
     * This method refreshes the data displayed in the table view with the updated search results.
     */
    public void refreshTableData() {
        if(searchResult == null){
            searchResult = new ArrayList<>();
        }

        ObservableList<Song> resultsData = FXCollections.observableArrayList(searchResult);
        resultsTable.setItems(resultsData);
    }
    /**
     * This method configures the table view to handle mouse click events, specifically double-click events.
     * When a row in the table view is double-clicked, it triggers the handleTableDoubleClick method.
     */
    private void configureTableEvents() {
        resultsTable.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2 && resultsTable.getSelectionModel().getSelectedItem() != null) {
                handleTableDoubleClick(resultsTable.getSelectionModel().getSelectedItem());
            }
        });
    }
    /**
     * This method handles the action to be taken when a row in the table view is double-clicked.
     * It is responsible for displaying the emotion details for the selected song.
     *
     * @param selectedSong The song selected in the table view.
     */
    private void handleTableDoubleClick(Song selectedSong) {
        if (application != null) {
            try {
                application.visualizzaEmozioneBrano(selectedSong, "SEARCH");
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
    /**
     * This method handles the action to be taken when the back button is clicked.
     * It navigates the user back to the home screen.
     *
     * @param event The action event triggered by clicking the back button.
     */
    @FXML
    protected void onBackButtonClick(ActionEvent event) {
        if (application != null) {
            application.switchToHomeLogged();
        }
    }
    /**
     * This method sets the main application instance for this controller.
     *
     * @param application The main application instance.
     */
    public void setApplication(ClientES application) {
        this.application = application;
    }
    /**
     * This method sets the search results obtained from the search operation.
     *
     * @param searchResult The list of songs resulting from the search operation.
     */
    public void setSearchResult(List<Song> searchResult) {
        this.searchResult = searchResult;
        refreshTableData();
    }
    /**
     * This method retrieves the search results obtained from the search operation.
     *
     * @return The list of songs resulting from the search operation.
     */
    public List<Song> getSearchResult() {
        return this.searchResult;
    }
    /**
     * This method retrieves the search term used in the search operation.
     *
     * @return The search term.
     */
    public String getSearchTerm() {
        return searchTerm;
    }
    /**
     * This method sets the search term used in the search operation.
     *
     * @param searchTerm The search term to be set.
     */

    public void setSearchTerm(String searchTerm) {
        this.searchTerm = searchTerm;
        lastSearchLabel.setText(searchTerm);
    }
    /**
     * This method clears the selection of the choice box used for reserved area options.
     */
    public void clearChoiceBoxSelection() {
        if (reservedAreaChoiceBox != null) {
            reservedAreaChoiceBox.getSelectionModel().clearSelection();
        }
    }
    /**
     * This method sets the text of the username label.
     *
     * @param text The text to be set in the username label.
     */
    public void setUsernameLabelText(String text){
        usernameLabel.setText(text);
    }


}
