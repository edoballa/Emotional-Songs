package clientES.services;

import clientES.objects.Address_Calculator;
import clientES.objects.UserInfo_Validator;
import commons.objects.*;

import java.io.IOException;
import java.rmi.NotBoundException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 * <p>This class provides services related to user information management.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class UserInfo_Service {
    /**
     * <code>clientHandler</code>
     * An instance of ClientHandler used for communication with the server.
     */
    private ClientHandler clientHandler;
    /**
     * <code>addressCalculator</code>
     * An instance of Address_Calculator used for address validation.
     */
    private Address_Calculator addressCalculator;
    /**
     * <code>userInfoValidator</code>
     * An instance of UserInfo_Validator used for validating user information.
     */
    private UserInfo_Validator userInfoValidator;

    /**
     * Constructs a new UserInfo_Service instance and initializes the required dependencies.
     */
    public UserInfo_Service(){
        try {
            clientHandler = ClientHandler.getInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        userInfoValidator = new UserInfo_Validator();
        addressCalculator = new Address_Calculator();
    }

    /**
     * This method checks the validity of user information.
     *
     * @param fiscalCode The fiscal code of the user.
     * @param email      The email address of the user.
     * @param firstName  The first name of the user.
     * @param lastName   The last name of the user.
     * @param address    The address of the user.
     * @return A string indicating any validation errors, or null if all information is valid.
     */

    public String checkUserInfo(String fiscalCode, String email, String firstName, String lastName, String address) {
        return userInfoValidator.validateUserInfo(fiscalCode, email, firstName, lastName, address);
    }
    /**
     * This method updates user information.
     *
     * @param user       The user object to update.
     * @param fiscalCode The new fiscal code of the user.
     * @param email      The new email address of the user.
     * @param firstName  The new first name of the user.
     * @param lastName   The new last name of the user.
     * @param address    The new address of the user.
     * @return True if the user information was successfully updated, false otherwise.
     */

    public boolean updateUser(User user, String fiscalCode, String email, String firstName, String lastName, String address){
        try {
            Address userAddress = addressCalculator.fillAddress(address);
            return clientHandler.actionUpdateUser(user, userAddress, firstName, lastName, fiscalCode, email);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * This method loads user information based on the provided user ID.
     *
     * @param userId The ID of the user to load.
     * @return The user object if found, null otherwise.
     */

    public User loadUser(Long userId) {
        try {
            return clientHandler.loadUser(userId);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * This method changes the password for the user with the specified user ID.
     *
     * @param userId      The ID of the user whose password needs to be changed.
     * @param oldPassword The old password to verify the user's identity.
     * @param newPassword The new password to set for the user.
     * @return True if the password was successfully changed, false otherwise.
     * @throws SQLException      If a database access error occurs.
     * @throws NotBoundException If the object with the specified name is not bound in the registry.
     * @throws IOException       If an I/O error occurs.
     */

    public boolean changePassword(Long userId, String oldPassword, String newPassword) throws SQLException, NotBoundException, IOException {
        return clientHandler.changePassword(userId, oldPassword, newPassword);
    }

    /**
     * This method checks if the provided old password matches the password of the user with the specified user ID.
     *
     * @param userId    The ID of the user whose password needs to be checked.
     * @param password  The old password to verify.
     * @return True if the old password is correct, false otherwise.
     * @throws SQLException      If a database access error occurs.
     * @throws NotBoundException If the object with the specified name is not bound in the registry.
     * @throws IOException       If an I/O error occurs.
     */

    public boolean isPasswordOldCorrect(Long userId, String password) throws SQLException, NotBoundException, IOException {
        return clientHandler.checkPassword(userId, password);
    }

    /**
     * This method checks if the new password and the confirmed password are equal.
     *
     * @param newPassword        The new password.
     * @param confirmedPassword The confirmed password.
     * @return True if the new password and the confirmed password are equal, false otherwise.
     */

    public boolean areNewPasswordsEquals(String newPassword, String confirmedPassword) {
        return newPassword.equals(confirmedPassword);
    }

    /**
     * This method checks if the new password is equal to the old password.
     *
     * @param userId     The user ID.
     * @param newPassword The new password.
     * @return True if the new password is equal to the old password, false otherwise.
     * @throws SQLException      If a database access error occurs.
     * @throws NotBoundException If the object with the specified name is not bound in the registry.
     * @throws IOException       If an I/O error occurs.
     */

    public boolean areNewAndOldPasswordsEquals(Long userId, String newPassword) throws SQLException, NotBoundException, IOException {
        return clientHandler.checkPassword(userId, newPassword);
    }

    /**
     * This method checks if the new password meets the validity criteria.
     *
     * @param newPassword The new password to validate.
     * @return True if the new password meets the validity criteria, false otherwise.
     */

    public boolean isNewPasswordValid(String newPassword){
        return userInfoValidator.isPasswordValid(newPassword);
    }

    /**
     * This method loads the playlists associated with the specified user and sets them to the user object.
     *
     * @param user The user for whom to load playlists.
     * @throws Exception If an error occurs while loading user playlists.
     */

    public void loadUserPlaylist(User user) throws Exception{
        List<Playlist> userPlaylist = new ArrayList<>();
        userPlaylist = clientHandler.loadUserPlaylist(user.getUserId());
        user.setPlaylists(userPlaylist);
    }

    /**
     * This method loads the feedback provided by the specified user and sets them to the user object.
     *
     * @param user The user for whom to load feedback.
     * @throws Exception If an error occurs while loading user feedback.
     */

    public void loadUserFeedback(User user) throws Exception {
        List<UserFeedback> userFeedbacks = new ArrayList<>();
        userFeedbacks = clientHandler.loadUserFeedback(user.getUserId());
        user.setUserFeedback(userFeedbacks);
    }

    /**
     * This method updates the specified user feedback.
     *
     * @param userFeedback The user feedback to be updated.
     * @return True if the user feedback is successfully updated, false otherwise.
     * @throws IOException        If an I/O error occurs.
     * @throws NotBoundException  If the object with the specified name is not bound in the registry.
     * @throws SQLException       If a database access error occurs.
     */

    public boolean updateUserFeedback(UserFeedback userFeedback) throws IOException, NotBoundException, SQLException{
        return clientHandler.updateUserFeedback(userFeedback);
    }

    /**
     * This method deletes the specified user feedback.
     *
     * @param userFeedback The user feedback to be deleted.
     * @return True if the user feedback is successfully deleted, false otherwise.
     * @throws IOException        If an I/O error occurs.
     * @throws NotBoundException  If the object with the specified name is not bound in the registry.
     * @throws SQLException       If a database access error occurs.
     */

    public boolean deleteUserFeedback(UserFeedback userFeedback) throws IOException, NotBoundException, SQLException{
        return clientHandler.deleteUserFeedback(userFeedback);
    }

    /**
     * This method inserts emotions feedback for a song given by a user.
     *
     * @param song   The song for which emotions feedback is provided.
     * @param userId The ID of the user providing the feedback.
     * @param emotion The emotion associated with the feedback.
     * @param score  The score assigned to the feedback.
     * @param note   Additional notes or comments provided by the user.
     * @return True if the emotions feedback is successfully inserted, false otherwise.
     * @throws IOException        If an I/O error occurs.
     * @throws NotBoundException  If the object with the specified name is not bound in the registry.
     * @throws SQLException       If a database access error occurs.
     */

    public boolean inserisciEmozioniBrano(Song song, Long userId, Emotion emotion, int score, String note) throws IOException, NotBoundException, SQLException {
        UserFeedback userFeedback = new UserFeedback(song, userId, emotion, note, score);
        return clientHandler.inserisciEmozioniBrano(userFeedback);
    }

}
