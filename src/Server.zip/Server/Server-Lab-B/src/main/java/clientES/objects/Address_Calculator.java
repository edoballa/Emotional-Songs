package clientES.objects;

import commons.objects.Address;
/**
 * <p>This class is a utility class for validating and processing address information.</p>
 *
 * @author Diana Cantaluppi, Matr. 744457 Sede Como.
 * @author Edoardo Ballabio, Matr. 745115 Sede Como.
 * @author Joele Vallone, Matr. 744775 Sede Como.
 * @author Claudio Della Motta, Matr. 750667 Sede Como.
 */

public class Address_Calculator {

    /**
     * This Constructs a new Address_Calculator object.
     */
    public Address_Calculator(){

    }

    /**
     * This method validates the given address string by checking its format and data integrity.</p>
     *
     * @param address the address string to validate
     * @return true if the address is valid, false otherwise
     */
    public boolean isValidAddress(String address){
        if (address.split(",").length != 6){
            return false;
        }

        Address addressInfo = fillAddress(address);
        if(!addressInfo.checkAddressData()){
            return false;
        }

        return true;
    }

    /**
     * This method parses the given address string and fills an Address object with its components.</p>
     *
     * @param addressStr the address string to parse
     * @return an Address object filled with the address components
     */
    public Address fillAddress(String addressStr){
        String[] addressField = addressStr.split(",");
        Address address = new Address();
        address.setAddress(addressField[0]);

        String addressNo = addressField[1];
        if(addressNo.startsWith(" ")){
            addressNo = addressNo.substring(1, addressNo.length());
        }
        address.setAddressNumber(addressNo);

        String postcode = addressField[2];
        if(postcode.startsWith(" ")){
            postcode = postcode.substring(1, postcode.length());
        }
        address.setPostcode(postcode);

        String city = addressField[3];
        if(city.startsWith(" ")){
            city = city.substring(1, city.length());
        }
        address.setCity(city);

        String province = addressField[4];
        if(province.startsWith(" ")){
            province = province.substring(1, province.length());
        }
        address.setProvince(province);

        String country = addressField[5];
        if(country.startsWith(" ")){
            country = country.substring(1, country.length());
        }
        address.setCountry(country);

        return address;
    }
}
