drop schema if exists emotional_songs cascade;
create schema emotional_songs;

create sequence emotional_songs.seq_user_data;
CREATE TABLE emotional_songs.user_data (
    user_id numeric(38) NOT NULL DEFAULT nextval('emotional_songs.seq_user_data'::regclass),
    username varchar(255) NOT NULL,
    "password" varchar NOT NULL,
    fiscal_code varchar(255) NULL,
    email varchar(255) NULL,
    "name" varchar(255) NULL,
    last_name varchar(255) NULL,
    address varchar(255) NULL,
    address_no varchar(255) NULL,
    city varchar(255) NULL,
    province varchar(255) NULL,
    postcode varchar(255) NULL,
    country varchar(255) NULL,
    CONSTRAINT user_data_pk PRIMARY KEY (user_id)
);
CREATE INDEX user_data_username_idx ON emotional_songs.user_data (username);

create sequence emotional_songs.seq_song;
CREATE TABLE emotional_songs.song (
    song_id numeric(38) NOT NULL DEFAULT nextval('emotional_songs.seq_song'::regclass),
    title varchar(255) NOT NULL,
    author varchar(255) NULL,
    "year" varchar(16) NULL,
    album varchar(255) NULL,
    duration numeric(24,3) NULL,
    CONSTRAINT song_pk PRIMARY KEY (song_id)
);
CREATE INDEX song_title_idx ON emotional_songs.song (title);
CREATE INDEX song_author_idx ON emotional_songs.song (author);
CREATE INDEX song_year_idx ON emotional_songs.song ("year");
CREATE INDEX song_album_idx ON emotional_songs.song (album);


CREATE TABLE emotional_songs.emotion (
    emotion_id numeric(38) NOT NULL,
    "name" varchar(255) NULL,
    description varchar(255) NULL,
    CONSTRAINT emotion_pk PRIMARY KEY (emotion_id)
);

INSERT INTO emotional_songs.emotion (emotion_id, "name", description) VALUES (1, 'stupore', 'Sensazione di meraviglia o felicità');
INSERT INTO emotional_songs.emotion (emotion_id, "name", description) VALUES(3, 'tenerezza', 'Sensualità, affetto, sentimento d amore');
INSERT INTO emotional_songs.emotion (emotion_id, "name", description) VALUES(4, 'nostalgia ', 'Sensazioni sognanti, malinconiche, sentimentali');
INSERT INTO emotional_songs.emotion (emotion_id, "name", description) VALUES(5, 'calma', 'Relax, serenità, meditazione');
INSERT INTO emotional_songs.emotion (emotion_id, "name", description) VALUES(6, 'potenza', 'Sentirsi forte, eroico, trionfante, energico');
INSERT INTO emotional_songs.emotion (emotion_id, "name", description) VALUES(7, 'gioia', 'Voglia di ballare, sentirsi animato, divertito, vivo');
INSERT INTO emotional_songs.emotion (emotion_id, "name", description) VALUES(8, 'tensione', 'Sentirsi nervosi, impazienti, irritati');
INSERT INTO emotional_songs.emotion (emotion_id, "name", description) VALUES(9, 'tristezza', 'Sentirsi depresso, addolorato');
INSERT INTO emotional_songs.emotion (emotion_id, "name", description) VALUES(2, 'solennità', 'Sensazione di trascendenza, ispirazione.');

create sequence emotional_songs.seq_playlist;
CREATE TABLE emotional_songs.playlist (
    playlist_id numeric(38) NOT NULL DEFAULT nextval('emotional_songs.seq_playlist'::regclass),
    "name" varchar(255) NOT NULL,
    user_id numeric(38) NOT NULL,
    add_date timestamp NULL,
    description varchar(255) NULL,
    CONSTRAINT playlist_pk PRIMARY KEY (playlist_id),
    CONSTRAINT playlist_user_id_fk FOREIGN KEY (user_id) REFERENCES emotional_songs.user_data(user_id)
);
CREATE INDEX playlist_user_id_idx ON emotional_songs.playlist (user_id);
CREATE INDEX playlist_name_idx ON emotional_songs.playlist ("name");

CREATE TABLE emotional_songs.playlist_song (
    playlist_id numeric(38) NOT NULL,
    song_id numeric(38) NOT NULL,
    add_date timestamp NULL DEFAULT current_timestamp,
    mod_date timestamp NULL DEFAULT current_timestamp,
    CONSTRAINT playlist_song_pk PRIMARY KEY (playlist_id, song_id),
    CONSTRAINT playlist_song_playlist_id_fk FOREIGN KEY (playlist_id) REFERENCES emotional_songs.playlist(playlist_id),
    CONSTRAINT playlist_song_song_id_fk FOREIGN KEY (song_id) REFERENCES emotional_songs.song(song_id)
);
CREATE INDEX playlist_song_playlist_id_idx ON emotional_songs.playlist_song (playlist_id);

CREATE TABLE emotional_songs.emotion_felt (
    song_id numeric(38) NOT NULL,
    emotion_id numeric(38) NOT NULL,
    user_id numeric(38) NOT NULL,
    score numeric(1) NULL,
    note varchar(255) NULL,
    add_date timestamp NULL DEFAULT current_timestamp,
    mod_date timestamp NULL DEFAULT current_timestamp,
    CONSTRAINT emotion_felt_pk PRIMARY KEY (song_id, emotion_id, user_id),
    CONSTRAINT emotion_felt_song_id_fk FOREIGN KEY (song_id) REFERENCES emotional_songs.song(song_id),
    CONSTRAINT emotion_feel_emotion_id_fk FOREIGN KEY (emotion_id) REFERENCES emotional_songs.emotion(emotion_id),
    CONSTRAINT emotion_feel_user_id_fk FOREIGN KEY (user_id) REFERENCES emotional_songs.user_data(user_id)
);
CREATE INDEX emotion_felt_song_id_idx ON emotional_songs.emotion_felt (song_id);
CREATE INDEX emotion_felt_emotion_id_idx ON emotional_songs.emotion_felt (emotion_id);
CREATE INDEX emotion_felt_user_id_idx ON emotional_songs.emotion_felt (user_id);
